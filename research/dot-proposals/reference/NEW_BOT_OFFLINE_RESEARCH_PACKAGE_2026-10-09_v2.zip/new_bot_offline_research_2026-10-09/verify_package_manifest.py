#!/usr/bin/env python3
"""Verify untouched package bytes before reproduction; fail closed on any difference."""
import hashlib,json
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'MANIFEST_SHA256.json').read_text())
expected={x['path']:x for x in manifest['files']}
assert len(expected)==len(manifest['files']),'duplicate path'
actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()}
assert actual==set(expected)|{'MANIFEST_SHA256.json'},'missing or unexpected files'
for name,row in expected.items():
 p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts
 f=ROOT/name;assert not f.is_symlink()
 assert f.stat().st_size==row['bytes'],name
 assert hashlib.sha256(f.read_bytes()).hexdigest()==row['sha256'],name
print(json.dumps({'passed':True,'verified_files':len(expected),'market_observations_added':0,'purpose':'packaging_integrity_only'}))
