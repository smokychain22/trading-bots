"""Invented fixtures only. No historical market values or observed dealer holdings."""
from datetime import datetime, timedelta, timezone
from dataclasses import replace
from gamma_research import *

OPEN=datetime(2026,10,9,13,30,tzinfo=timezone.utc)
def iso(x): return x.isoformat()

def session():
    return Session('SPY',iso(OPEN),iso(OPEN+timedelta(hours=6,minutes=30)),
                   'INVENTED_REGULAR_CALENDAR_V1',iso(OPEN-timedelta(days=1)),
                   'VERIFIED_CLEAR',iso(OPEN-timedelta(minutes=1)),iso(OPEN+timedelta(hours=7)),False,
                   calendar_source='synthetic_fixture',event_source='synthetic_fixture')

def bars(kind='mr', direction=1):
    prices=[100 + (.01 if i%2 else -.01) for i in range(30)]
    if kind=='mr':
        prices += [99.98-.04*i+(.003 if i%2 else -.003) for i in range(30)]
        prices += [prices[-1]+.03]
    else:
        prices += [100.10,100.18,100.27,100.34]
    if direction == -1:
        prices=[200-p for p in prices]
    result=[]
    for i,p in enumerate(prices):
        start=OPEN+timedelta(minutes=i); end=start+timedelta(minutes=1)
        o=prices[i-1] if i else p
        result.append(Bar('SPY',iso(start),iso(end),iso(end+timedelta(seconds=1)),
                          iso(end+timedelta(seconds=1)),0,o,max(o,p)+.005,min(o,p)-.005,p,
                          1000,1000*(o+p)/2,'synthetic_trade_tape','SYNTHETIC',True))
    return result

def decision_time(bs): return iso(stamp(bs[-1].end)+timedelta(seconds=2))

def gamma(bs,sign=1):
    at=decision_time(bs); spot=bs[-1].close; w=bs[-2].close
    rows=(PositionRow('INVENTED_NEAR_CALL',w,'call',iso(OPEN+timedelta(days=3)),100,.03,10000,
                      6000*sign if sign>0 else -8000,8000*sign if sign>0 else -6000),)
    return GammaInput('SPY',spot,iso(stamp(at)-timedelta(seconds=1)),at,at,'INVENTED_SCENARIO_V1',
        'EXPLICIT_INVENTORY_SCENARIOS','synthetic_fixture',digest({'fixture':'gamma','sign':sign}),
        'SYNTHETIC',True,'SPY_STANDARD_OPTIONS_0_7_CALENDAR_DTE',True,rows,
        tuple([100_000_000.]*20),iso(OPEN-timedelta(days=1)),iso(OPEN-timedelta(hours=17)),
        'synthetic_daily_turnover','INVENTED_FIXED_GAMMA','Hypothetical signed holdings, not inferred from OI.',
        calculation_status='COMPUTED',
        prior20_session_ends=tuple(iso(OPEN-timedelta(hours=17,days=i)) for i in range(19,-1,-1)),
        scale_calendar_complete=True)

def quote(at,direction=1,contract_id=None,bid=1.94,ask=2.00):
    typ='call' if direction==1 else 'put'
    return OptionQuote(contract_id or 'INVENTED_SPY_10D_'+typ,'SPY',typ,100.,
          iso(OPEN+timedelta(days=10,hours=8)),iso(OPEN+timedelta(days=10,hours=6,minutes=45)),
          'AMERICAN','PHYSICAL',100,True,iso(OPEN-timedelta(days=30)),at,at,at,
          bid,ask,100,100,.5*direction,at,'INVENTED_DELTA','synthetic_fixture','SYNTHETIC','SYNTHETIC_BBO',True)
