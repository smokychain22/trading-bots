import unittest
from dataclasses import replace, asdict
from datetime import timedelta
from random import Random
from gamma_research import *
from synthetic_fixture import *

class GammaTests(unittest.TestCase):
    def setUp(self):
        self.bs=bars(); self.at=decision_time(self.bs); self.s=session(); self.g=gamma(self.bs)
    def decision(self,arm='gamma_mr',g='default',mode='synthetic',bs=None):
        return decide(arm,bs or self.bs,self.s,self.at,self.g if g=='default' else g,mode)
    def opened(self,arm='gamma_mr'):
        d=self.decision(arm); p=plan_option(d,[quote(self.at)],RiskState(100000),'synthetic')
        t=iso(stamp(self.at)+timedelta(seconds=1))
        return simulate_entry(p,quote(t),self.s,t,'synthetic')
    def test_all_routes_both_directions(self):
        for kind in ('mr','bo'):
            for side in (-1,1):
                bs=bars(kind,side); at=decision_time(bs); g=gamma(bs,1 if kind=='mr' else -1)
                for arm in ('price_'+kind,'gamma_'+kind):
                    with self.subTest(arm=arm,side=side):
                        d=decide(arm,bs,self.s,at,g,'synthetic')
                        self.assertEqual(d.status,'RESEARCH_CANDIDATE');self.assertEqual(d.direction,side)
    def test_missing_gamma_price_benchmark_survives(self):
        self.assertEqual(self.decision(g=None).status,'NO_SIGNAL')
        self.assertEqual(self.decision('price_mr',g=None).status,'RESEARCH_CANDIDATE')
    def test_synthetic_cannot_be_market(self):
        self.assertEqual(self.decision(mode='market_shadow').reason,'SYNTHETIC_NOT_MARKET')
    def test_no_oi_sign_shortcut(self):
        for method in ('CALL_POSITIVE_PUT_NEGATIVE','OI_ONLY','UNKNOWN'):
            self.assertEqual(self.decision(g=replace(self.g,sign_method=method)).reason,'DEALER_SIGN_UNIDENTIFIED')
    def test_same_oi_three_dealer_scenarios(self):
        vals=[]
        for lo,hi in [(6000,8000),(-8000,-6000),(0,0)]:
            row=replace(self.g.rows[0],modeled_dealer_contracts_low=lo,modeled_dealer_contracts_high=hi)
            gf,bad=gamma_features(replace(self.g,rows=(row,)),self.s,self.at,self.bs[-1].close,'synthetic')
            self.assertIsNone(bad); vals.append(gf['regime'])
        self.assertEqual(vals,['POSITIVE','NEGATIVE','NEUTRAL_OR_AMBIGUOUS'])
    def test_gamma_units_and_put_gamma(self):
        row=PositionRow('TEST',100,'put',iso(OPEN+timedelta(days=3)),100,.02,100,100,100)
        g=replace(self.g,spot_reference=100,rows=(row,))
        f,bad=gamma_features(g,self.s,self.at,100,'synthetic')
        self.assertIsNone(bad);self.assertAlmostEqual(f['g_low_usd_per_1pct'],20000.)
    def test_ambiguous_interval_abstains(self):
        row=replace(self.g.rows[0],modeled_dealer_contracts_low=-8000,modeled_dealer_contracts_high=8000)
        d=self.decision(g=replace(self.g,rows=(row,)))
        self.assertEqual(d.reason,'MODELED_GAMMA_REGIME_MISMATCH')
    def test_zero_uncomputed_abstains(self):
        self.assertEqual(self.decision(g=replace(self.g,calculation_status='UNVERIFIED')).reason,'GAMMA_NOT_VERIFIED_COMPUTED')
        self.assertEqual(provider_field_admission('total_gex',{'total_gex':0},'REGIME')['reason'],'ZERO_MAY_MEAN_EXPOSURES_NOT_COMPUTED')
    def test_provider_historical_regime_rejected(self):
        self.assertEqual(provider_field_admission('quote.regime',{'date':'2020-01-01'},'BACKTEST')['status'],'REJECT')
        self.assertEqual(self.decision(g=replace(self.g,historical_safe=False)).reason,'CURRENT_REGIME_NOT_HISTORICAL_PIT')
    def test_provider_expected_move_horizon_rejected(self):
        self.assertEqual(provider_field_admission('expected_move_pct',{'front_expiry_dte':1},'FORECAST',30)['reason'],'FRONT_EXPIRY_HORIZON_MISMATCH_OR_UNKNOWN')
    def test_provider_quote_cannot_fill(self):
        q=replace(quote(self.at),quote_class='SESSION_RECORDED')
        self.assertEqual(quote_reject(q,self.at,'synthetic'),'SESSION_ANALYTICS_NOT_EXECUTION_QUOTE')
    def test_gamma_stale_future(self):
        for kw in ({'observed_at':iso(stamp(self.at)-timedelta(seconds=61))},{'first_seen_at':iso(stamp(self.at)+timedelta(seconds=1))}):
            self.assertEqual(self.decision(g=replace(self.g,**kw)).reason,'GAMMA_STALE_OR_FUTURE')
    def test_spot_reference_stale(self):
        self.assertEqual(self.decision(g=replace(self.g,spot_reference=1000)).reason,'GAMMA_SPOT_REFERENCE_STALE')
    def test_scope_missing(self):
        self.assertEqual(self.decision(g=replace(self.g,complete_scope=False)).reason,'GAMMA_SCOPE_UNKNOWN')
    def test_gamma_nonfinite_extreme(self):
        for value in (float('nan'),float('inf'),-1):
            row=replace(self.g.rows[0],long_gamma=value)
            self.assertEqual(self.decision(g=replace(self.g,rows=(row,))).reason,'GAMMA_ROW_INVALID')
        row=replace(self.g.rows[0],long_gamma=1e308)
        self.assertEqual(self.decision(g=replace(self.g,rows=(row,))).reason,'GAMMA_AGGREGATE_NONFINITE')
    def test_gamma_inventory_bound(self):
        row=replace(self.g.rows[0],modeled_dealer_contracts_high=10001)
        self.assertEqual(self.decision(g=replace(self.g,rows=(row,))).reason,'GAMMA_ROW_INVALID')
    def test_gamma_duplicate_contract(self):
        self.assertEqual(self.decision(g=replace(self.g,rows=self.g.rows*2)).reason,'GAMMA_ROWS_MISSING_OR_DUPLICATE')
    def test_scale_calendar_not_compressed(self):
        self.assertEqual(self.decision(g=replace(self.g,prior20_session_ends=self.g.prior20_session_ends[:-1])).reason,'GAMMA_SCALE_CALENDAR_INVALID')
    def test_row_order_invariance(self):
        r=replace(self.g.rows[0],contract_id='SECOND',strike=100)
        a=self.decision(g=replace(self.g,rows=(self.g.rows[0],r)))
        b=self.decision(g=replace(self.g,rows=(r,self.g.rows[0])))
        self.assertEqual(a.evidence_hash,b.evidence_hash)
    def test_future_revision_does_not_change_earlier_decision(self):
        old=self.decision()
        revision=replace(self.bs[-1],revision=1,close=self.bs[-1].close+.001,published_at=iso(stamp(self.at)+timedelta(seconds=10)),first_seen_at=iso(stamp(self.at)+timedelta(seconds=10)))
        new=self.decision(bs=self.bs+[revision])
        self.assertEqual(asdict(old),asdict(new))
    def test_current_revision_changes_hash_without_retroactive_mutation(self):
        old=self.decision()
        b=self.bs[-1]; revision=replace(b,revision=1,close=b.close+.001)
        new=self.decision(bs=self.bs+[revision])
        self.assertNotEqual(old.evidence_hash,new.evidence_hash)
        self.assertEqual(old.evidence_hash,self.decision().evidence_hash)
    def test_conflicting_revision_rejected(self):
        self.assertEqual(self.decision(bs=self.bs+[replace(self.bs[-1],close=self.bs[-1].close+.001)]).reason,'BAR_REVISION_CONFLICT')
    def test_bar_reordering_is_invariant(self):
        shuffled=self.bs[:];Random(73).shuffle(shuffled)
        self.assertEqual(asdict(self.decision()),asdict(self.decision(bs=shuffled)))
    def test_missing_bar_rejected(self):
        self.assertEqual(self.decision(bs=self.bs[:10]+self.bs[11:]).reason,'BAR_GAP_OR_LATE')
    def test_nonfinite_bar_rejected(self):
        bs=self.bs[:];bs[-1]=replace(bs[-1],close=float('nan'))
        self.assertEqual(self.decision(bs=bs).reason,'BAR_NONFINITE')
    def test_session_event_and_exdiv_unknown(self):
        for s,reason in [(replace(self.s,event_state='UNKNOWN'),'EVENT_UNKNOWN_OR_BLACKOUT'),
                         (replace(self.s,ex_dividend_before_next_session=None),'EX_DIVIDEND_UNKNOWN_OR_IMMINENT'),
                         (replace(self.s,halted=True),'HALTED')]:
            self.assertEqual(decide('price_mr',self.bs,s,self.at,mode='synthetic').reason,reason)
    def test_early_close_not_assumed_regular(self):
        self.assertEqual(decide('price_mr',self.bs,replace(self.s,standard_full_session=False),self.at,mode='synthetic').reason,'UNSUPPORTED_SESSION')
    def test_wall_ablation(self):
        row=replace(self.g.rows[0],strike=90)
        self.assertEqual(self.decision(g=replace(self.g,rows=(row,))).reason,'MODELED_WALL_NOT_CONFIRMED')
        self.assertEqual(self.decision('gamma_mr_no_wall',g=replace(self.g,rows=(row,))).status,'RESEARCH_CANDIDATE')
    def test_sign_intervention_does_not_change_price_benchmark(self):
        gminus=gamma(self.bs,-1)
        self.assertEqual(asdict(self.decision('price_mr')),asdict(self.decision('price_mr',g=gminus)))
        self.assertEqual(self.decision(g=gminus).reason,'MODELED_GAMMA_REGIME_MISMATCH')
    def test_no_quote_no_option_plan(self):
        self.assertEqual(plan_option(self.decision(),[],RiskState(100000),'synthetic')['reason'],'NO_ELIGIBLE_CONTRACT')
    def test_selection_deterministic(self):
        q=quote(self.at); q2=replace(q,contract_id='SECOND',delta=.52)
        a=plan_option(self.decision(),[q,q2],RiskState(100000),'synthetic')
        b=plan_option(self.decision(),[q2,q],RiskState(100000),'synthetic')
        self.assertEqual(a['selected_quote'],b['selected_quote'])
    def test_no_dte_zero(self):
        q=replace(quote(self.at),expiry=iso(OPEN+timedelta(hours=8)))
        self.assertEqual(plan_option(self.decision(),[q],RiskState(100000),'synthetic')['status'],'NO_TRADE')
    def test_quote_constraints(self):
        q=quote(self.at)
        for kw,reason in [({'bid':3},'QUOTE_INVALID'),({'ask':float('nan')},'QUOTE_INVALID'),
                          ({'ask':2.4},'QUOTE_TOO_WIDE'),({'delta':-.5},'DELTA_SIGN_INVALID'),
                          ({'standard_deliverable':False},'CONTRACT_UNSUPPORTED')]:
            self.assertEqual(quote_reject(replace(q,**kw),self.at,'synthetic'),reason)
    def test_risk_limits(self):
        for risk in (RiskState(100000,1),RiskState(100000,0,2),RiskState(100000,0,0,-500),RiskState(float('nan'))):
            self.assertEqual(plan_option(self.decision(),[quote(self.at)],risk,'synthetic')['reason'],'RISK_LIMIT')
    def test_entry_strictly_after_decision(self):
        p=plan_option(self.decision(),[quote(self.at)],RiskState(100000),'synthetic')
        self.assertEqual(simulate_entry(p,quote(self.at),self.s,self.at,'synthetic')['reason'],'NO_CAUSAL_NEXT_QUOTE_WITHIN_5S')
    def test_entry_contract_locked(self):
        p=plan_option(self.decision(),[quote(self.at)],RiskState(100000),'synthetic');t=iso(stamp(self.at)+timedelta(seconds=1))
        self.assertEqual(simulate_entry(p,replace(quote(t),strike=101),self.s,t,'synthetic')['reason'],'LOCKED_CONTRACT_MISMATCH')
    def test_entry_size_and_loss_budget(self):
        pos=self.opened();self.assertEqual(pos['status'],'SIMULATED_OPEN')
        self.assertEqual(pos['quantity'],1);self.assertLessEqual(pos['max_loss_budget_usd'],250)
        self.assertFalse(pos['orders_enabled'])
    def test_roundtrip_unchanged_option_loses_spread_and_cost(self):
        p=self.opened();t=iso(stamp(p['entry_at'])+timedelta(seconds=1))
        x=exit_step(p,t,p['target_underlying'],t,quote(t),gamma_regime='POSITIVE',mode='synthetic')
        self.assertEqual(x['status'],'SIMULATED_CLOSED');self.assertAlmostEqual(x['pnl_usd'],-9.4)
    def test_underlying_profitable_does_not_imply_option_profit(self):
        p=self.opened();t=iso(stamp(p['entry_at'])+timedelta(minutes=1));target=p['target_underlying']
        x=exit_step(p,t,target,t,quote(t,bid=1.7,ask=1.76),gamma_regime='POSITIVE',mode='synthetic')
        self.assertGreater(underlying_benchmark(1,p['decision']['features']['close'],target)['gross_log_return'],0)
        self.assertLess(x['pnl_usd'],0)
    def test_missing_exit_never_free_fill(self):
        p=self.opened();t=p['deadline']
        pending=exit_step(p,t,p['target_underlying'],t,None,gamma_regime='POSITIVE',mode='synthetic')
        self.assertEqual(pending['status'],'EXIT_PENDING')
        final=censor_unclosed(pending);self.assertIsNone(final['pnl_usd']);self.assertLess(final['worst_case_premium_loss_usd'],0)
    def test_exit_retry_preserves_trigger(self):
        p=self.opened();t=p['deadline'];pending=exit_step(p,t,p['target_underlying'],t,None,gamma_regime='POSITIVE',mode='synthetic')
        t2=iso(stamp(t)+timedelta(seconds=1))
        closed=exit_step(pending,t2,100,t2,quote(t2),gamma_regime='POSITIVE',mode='synthetic')
        self.assertEqual(closed['status'],'SIMULATED_CLOSED');self.assertEqual(closed['exit_trigger'],'MAX_HOLD_OR_SESSION_CUTOFF')
    def test_exit_does_not_require_fresh_delta_or_tight_market(self):
        p=self.opened();t=p['deadline'];q=replace(quote(t),delta_known_at=self.at,bid=.5,ask=1.)
        closed=exit_step(p,t,p['target_underlying'],t,q,gamma_regime='POSITIVE',mode='synthetic')
        self.assertEqual(closed['status'],'SIMULATED_CLOSED')
    def test_gamma_loss_triggers_exit(self):
        p=self.opened();p['exit_policy']='GAMMA_EXIT_CHALLENGER';t=iso(stamp(p['entry_at'])+timedelta(seconds=1))
        x=exit_step(p,t,p['decision']['features']['close'],t,quote(t),gamma_regime=None,mode='synthetic')
        self.assertEqual(x['exit_trigger'],'MODELED_GAMMA_LOST_OR_FLIPPED')
    def test_purged_walk_forward(self):
        rows=[]
        for i in range(6):
            t=OPEN+timedelta(days=i)
            rows.append({'id':str(i),'session':t.date().isoformat(),'decision_at':iso(t),'label_end':iso(t+timedelta(hours=1)),
                         'label_available_at':iso(t+timedelta(hours=2))})
        rows[1]['label_available_at']=iso(OPEN+timedelta(days=5))
        folds=expanding_walk_forward(rows,3,2)
        self.assertEqual(folds[0]['train_ids'],['0','2']);self.assertEqual(folds[0]['test_ids'],['3','4'])
    def test_matched_ablation_counts_abstention_zero_and_unknown_missing(self):
        out=paired_increment([{'after_cost_pnl_usd':10,'gamma_available':True,'gamma_accept':True},
                              {'after_cost_pnl_usd':-4,'gamma_available':True,'gamma_accept':False},
                              {'after_cost_pnl_usd':None,'gamma_available':True,'gamma_accept':False},
                              {'after_cost_pnl_usd':7,'gamma_available':False,'gamma_accept':False}])
        self.assertEqual(out['common_qualified'],2);self.assertEqual(out['censored_or_gamma_missing'],2)
        self.assertEqual(out['mean_increment_usd_per_opportunity'],2)
    def test_primary_exit_is_matched_price_only(self):
        p=self.opened();t=iso(stamp(p['entry_at'])+timedelta(seconds=1))
        x=exit_step(p,t,p['decision']['features']['close'],t,quote(t),gamma_regime=None,mode='synthetic')
        self.assertEqual(x['status'],'SIMULATED_OPEN')
        self.assertEqual(p['exit_policy'],'MATCHED_PRICE_ONLY')
    def test_vanna_charm_deferred(self):
        self.assertEqual(vanna_charm_decision()['status'],'NO_SIGNAL')
    def test_exit_monotone_clock(self):
        p=self.opened();t=iso(stamp(p['entry_at'])+timedelta(seconds=10))
        p=exit_step(p,t,p['decision']['features']['close'],t,quote(t),mode='synthetic')
        earlier=iso(stamp(t)-timedelta(seconds=1))
        with self.assertRaisesRegex(ValueError,'EXIT_EVENT_NOT_MONOTONE'):
            exit_step(p,earlier,p['target_underlying'],earlier,quote(earlier),mode='synthetic')
    def test_exit_full_contract_identity(self):
        p=self.opened();t=p['deadline']
        result=exit_step(p,t,p['target_underlying'],t,replace(quote(t),strike=110),mode='synthetic')
        self.assertEqual(result['status'],'EXIT_PENDING')
        self.assertEqual(result['exit_blocker'],'LOCKED_CONTRACT_MISMATCH')
    def test_selection_latest_quote_not_best_quote(self):
        q=quote(self.at);old=replace(q,observed_at=iso(stamp(self.at)-timedelta(seconds=1)),bid=1.99)
        plan=plan_option(self.decision(),[q,old],RiskState(100000),'synthetic')
        self.assertEqual(plan['selected_quote']['bid'],q.bid)
    def test_conflicting_same_vintage_quotes_rejected(self):
        q=quote(self.at)
        plan=plan_option(self.decision(),[q,replace(q,bid=1.99)],RiskState(100000),'synthetic')
        self.assertEqual(plan['status'],'NO_TRADE')
        self.assertIn([q.contract_id,'QUOTE_VINTAGE_CONFLICT'],plan['rejects'])
    def test_daily_loss_reserves_full_new_max_loss(self):
        p=plan_option(self.decision(),[quote(self.at)],RiskState(100000,0,0,-499),'synthetic')
        t=iso(stamp(self.at)+timedelta(seconds=1))
        result=simulate_entry(p,quote(t),self.s,t,'synthetic')
        self.assertEqual(result['status'],'NO_FILL');self.assertEqual(result['reason'],'SIZE_BELOW_ONE')
    def test_wrong_contract_cannot_trigger_premium_stop(self):
        p=self.opened();t=iso(stamp(p['entry_at'])+timedelta(seconds=1))
        x=exit_step(p,t,p['decision']['features']['close'],t,quote(t,contract_id='WRONG',bid=.1,ask=.15),mode='synthetic')
        self.assertEqual(x['status'],'SIMULATED_OPEN');self.assertNotIn('exit_trigger',x)
    def test_synthetic_rights_reject_false_flag(self):
        bs=[replace(b,synthetic=False) for b in self.bs]
        self.assertEqual(decide('price_mr',bs,self.s,self.at,mode='market_shadow').reason,'SYNTHETIC_NOT_MARKET')
        q=replace(quote(self.at),synthetic=False,quote_class='TIMESTAMPED_BBO')
        self.assertEqual(quote_reject(q,self.at,'market_shadow'),'SYNTHETIC_NOT_MARKET')
        g=replace(self.g,synthetic=False)
        self.assertEqual(gamma_features(g,self.s,self.at,self.bs[-1].close,'market_shadow')[1],'SYNTHETIC_NOT_MARKET')
    def test_exit_delta_missing_is_not_liquidation_blocker(self):
        for delta in (None,float('nan'),-.9):
            p=self.opened();t=p['deadline'];q=replace(quote(t),delta=delta)
            closed=exit_step(p,t,p['target_underlying'],t,q,mode='synthetic')
            self.assertEqual(closed['status'],'SIMULATED_CLOSED')
    def test_superseded_revision_conflict_is_order_invariant(self):
        from itertools import permutations
        b=self.bs[-1];conflict=replace(b,close=b.close+.001);new=replace(b,revision=1)
        for perm in permutations([b,conflict,new]):
            d=self.decision(bs=self.bs[:-1]+list(perm))
            self.assertEqual(d.reason,'BAR_REVISION_CONFLICT')
    def test_off_grid_decision_rejected(self):
        t=iso(stamp(self.at)+timedelta(seconds=1))
        self.assertEqual(decide('price_mr',self.bs,self.s,t,mode='synthetic').reason,'OFF_DECISION_GRID')
    def test_zero_bid_is_unpriced_exit_not_fill(self):
        p=self.opened();t=p['deadline']
        x=exit_step(p,t,p['target_underlying'],t,quote(t,bid=0,ask=.01),mode='synthetic')
        self.assertEqual(x['status'],'EXIT_PENDING');self.assertEqual(x['exit_blocker'],'NO_POSITIVE_EXIT_BID')
        c=censor_unclosed(x);self.assertIsNone(c['pnl_usd'])
        self.assertAlmostEqual(c['worst_case_premium_loss_usd'],-p['max_loss_budget_usd'])
    def test_zero_bid_requests_premium_stop_without_filling(self):
        p=self.opened();t=iso(stamp(p['entry_at'])+timedelta(seconds=1))
        x=exit_step(p,t,p['decision']['features']['close'],t,quote(t,bid=0,ask=.01),mode='synthetic')
        self.assertEqual(x['status'],'EXIT_PENDING');self.assertEqual(x['exit_blocker'],'NO_POSITIVE_EXIT_BID')
        self.assertEqual(x['exit_trigger'],'PREMIUM_DRAWDOWN_50PCT')
    def test_planner_nonfinite_quote_emits_refusal_not_hash_crash(self):
        for field in ('bid','ask','delta','strike'):
            q=replace(quote(self.at),**{field:float('nan')})
            plan=plan_option(self.decision(),[q],RiskState(100000),'synthetic')
            self.assertEqual(plan['status'],'NO_TRADE');self.assertEqual(plan['reason'],'NO_ELIGIBLE_CONTRACT')
    def test_extreme_gamma_normalization_refuses(self):
        for value in (1e308,1e-308):
            d=self.decision(g=replace(self.g,prior20_dollar_volume=tuple([value]*20)))
            self.assertEqual(d.reason,'GAMMA_NORMALIZATION_NONFINITE')
    def test_naive_time_not_accepted(self):
        with self.assertRaises(ValueError): stamp('2026-10-09T10:30:00')

if __name__=='__main__': unittest.main(verbosity=2)
