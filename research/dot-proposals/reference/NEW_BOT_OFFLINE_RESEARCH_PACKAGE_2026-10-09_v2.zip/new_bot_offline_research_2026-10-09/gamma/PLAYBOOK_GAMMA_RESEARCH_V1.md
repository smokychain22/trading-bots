# Gamma Trader: executable offline research playbooks, version 1

Prepared 2026-10-09 UTC. Status: **PROTOTYPE_ONLY / ZERO MARKET OBSERVATIONS / NO ORDERS**.

## What this package actually does

Two complete, deterministic research policies run on invented inputs:

1. **G+ wall mean reversion:** a confirmed SPY price/VWAP reversal, optionally filtered by robustly positive *modeled* dealer gamma and proximity to a modeled positive-gamma strike concentration.
2. **G− volatility-expansion breakout:** a confirmed SPY opening-range break and recent realized-variance expansion, filtered by robustly negative modeled dealer gamma.

Both have independently runnable price-only comparators. Long single-option structures, contract selection, quote checks, worst-case-premium sizing, subsequent-quote entry simulation, holding rules, exits and missing-exit censoring are executable. These are original proposed rules, not replicated published trading strategies. Numerical thresholds are deliberately fixed research choices; none was estimated or selected from market performance.

**Vanna/charm is explicitly deferred.** The executable function returns `NO_SIGNAL`; formulas alone would not identify dealer flows.

There is no network code, broker interface, order route, account credential, activation, repository mutation or authorization token in this package. A `RESEARCH_CANDIDATE`, `RESEARCH_PLAN` or `SIMULATED_OPEN` is an analytical object with no order authority. Python uses only the standard library. Canonical THETA A/C/H/Q schemas and policies remain separate; generic IV, LIQUIDITY or MOMENTUM scalars cannot honestly encode these new records.

## 1. Mechanism and identification boundary

A local delta-hedging hypothesis motivates the regimes. If a modeled dealer book is long gamma and actively rebalances its delta, its hedge may oppose an underlying move. Negative gamma can reverse that local hedge response. Neither statement identifies who currently owns options, when they hedge, the instrument they hedge with, liquidity impact, future direction, or profitable execution. The Cboe-hosted primary study reconstructs positions using capacity-identified trading records; its volatility work does not validate these proposed entry rules. [Amaya et al., 2025, sections 2.2–2.3](https://cdn.cboe.com/resources/education/research_publications/gammasqueezes.pdf)

Open interest counts paired outstanding long/short contracts; it does not reveal the dealer side. Both opening and closing combinations affect that count. OI or volume is also not a substitute for a fresh two-sided quote with size. [Official OIC general-information FAQ](https://www.optionseducation.org/referencelibrary/faq/general-information)

For each standard SPY option i, inject a stated dealer-contract scenario interval [D_low_i,D_high_i], a nonnegative long-option gamma Γ_i and multiplier M_i=100. Require −OI_i ≤ D_low_i ≤ D_high_i ≤ OI_i. Bounds are input scenario assumptions, **not a statistical confidence interval**. The same OI supports all-long, all-short and no-dealer scenarios. Calls are not automatically positive dealer gamma and puts are not automatically negative dealer gamma.

At the snapshot's underlying reference S:

G_low = 0.01 × S² × Σ(M_i × Γ_i × D_low_i)

G_high = 0.01 × S² × Σ(M_i × Γ_i × D_high_i)

Units: USD of option-delta notional change for a local +1% underlying move. The modeled delta-neutral hedge adjustment is approximately the opposite sign. This is not an observed trade, finite-jump payoff, dollar loss, forecast return or mandatory flow. The gamma model freezes the supplied sensitivities at its spot reference; it does not pretend to reprice a surface. Reject when the decision spot has moved more than 0.1% from that reference.

Only the named, complete modeled universe of standard SPY options with 0–7 calendar DTE is included. Other expiries, OTC positions, futures, dealer stocks and other hedges remain omitted. “Positive” means positive for this modeled subset, not the entire dealer market. The upstream model must document inventory reconstruction or explicit scenario assignments, initial positions, missing series, corrections, OI availability, gamma surface method and version, then-known carry inputs and rights. A completeness flag or hash is a provenance contract, not independent proof of truth.

Normalize each G bound by the median daily underlying dollar turnover from the **prior 20 actual exchange sessions**, excluding the current session. Supply all 20 dated endpoints and a calendar-completeness attestation. The fixture dates are invented and are not an actual calendar history. Production-quality market admission would need a verified calendar and the underlying series; this prototype does not acquire them.

- Positive modeled regime: G_low / turnover ≥ 0.005
- Negative modeled regime: G_high / turnover ≤ −0.005
- Otherwise: neutral or ambiguous; gamma arms abstain
- Zero without a verified completed calculation is unknown, not neutral

The 0.005 threshold is dimensionless given the stated “per 1% move” convention. It is a frozen prototype constant, not a universal microstructure cutoff. Results must disclose sensitivities to it without choosing the best holdout threshold.

## 2. Universe, calendar and decision clock

Research underlying: **SPY only**. Full 390-minute regular sessions only; early closes, halts, missing calendars and unsupported products are rejected. The caller supplies authoritative, historically applicable open/close UTC timestamps, version, source and known-at time derived from America/New_York and actual DST. A 390-minute duration check does not authenticate the calendar.

At each completed one-minute bar end T, issue the decision at T+2 seconds. First eligible time is regular open+32 minutes+2 seconds (10:02:02 ET in an ordinary session). Stop admitting new entries at close−60 minutes. Flat target is close−30 minutes; maximum holding can require an earlier close. All bars from the open through T must be present; a missing bar does not compress the window.

Each immutable bar revision carries start/end, publication and first-seen times, revision number, source, rights and synthetic status. A decision uses only records first seen and published by its timestamp. Among already available revisions for the same bar, the highest revision is selected. A same-revision conflict rejects the snapshot. Later corrections may affect later decisions but cannot rewrite a stored earlier receipt. Bar order is irrelevant; the receipt hashes the canonical ordered bar vintages. Decisions and source hashes must be retained append-only by any future consumer.

The engine refuses naïve timestamps, incomplete one-minute intervals, nonfinite/OHLC-inconsistent values, zero or negative volume, and price-volume sums inconsistent with the range. The required price-volume field is the sum of actual trade price × size under a sealed eligible-trade policy. **OHLC typical-price × volume is not silently substituted for true VWAP.** This stronger field is a known acquisition gap.

A gamma snapshot requires observed ≤ published ≤ first-seen ≤ decision, same regular session, age ≤60 seconds, completed calculation, scope, source payload hash, rights, methodology and signed-inventory assumptions. Future or live-session-only historical classifications are refused. Synthetic provenance is refused by `market_shadow` even if a false synthetic flag was accidentally supplied.

## 3. Shared price features and exact confirmations

Let P_t be each completed bar close and r_t=log(P_t/P_(t−1)). Session VWAP_t = cumulative price-volume / cumulative volume. Opening-range high/low are the maximum high/minimum low over the first 30 bars, frozen thereafter.

σ_ref = sqrt(sum of squared returns in the 20 returns immediately before the latest return). This is an unannualized 20-minute realized root variance, with no centering and no sqrt252 substitution. Both the current and previous VWAP deviations use this same denominator at the current decision, which avoids comparing z scores with changing normalization inside one trigger. A zero/missing denominator abstains.

z_t = log(P_t / VWAP_t) / σ_ref

z_prev = log(P_(t−1) / VWAP_(t−1)) / σ_ref

RV_ratio = sum(last 5 squared returns) / [sum(the immediately preceding 20 squared returns) / 4]. Windows do not overlap. All history is already known; no future price creates the confirmation.

### G+ mean reversion

Price-only baseline `price_mr`:

- Long-direction candidate when z_prev ≤−1, P_t>P_(t−1), z_t<0 and |z_t|<|z_prev|
- Short-direction candidate when z_prev ≥+1, P_t<P_(t−1), z_t>0 and |z_t|<|z_prev|
- In either direction RV_ratio ≤1.5

Gamma gate-only ablation `gamma_mr_no_wall`: same price rule plus positive modeled regime.

Full arm `gamma_mr`: same rule, positive modeled regime, and a positive modeled-gamma strike bin meeting all of:

- Its lower-bound gamma contribution is positive
- Absolute central-scenario gamma at the strike is at least 20% of the sum of absolute central strike contributions
- Strike is within 0.25 × σ_ref × P_(t−1) of P_(t−1)
- Strike lies below previous VWAP for a long-direction reversal, above it for a short-direction reversal

Choose closest qualifying strike, lower strike on an exact tie. This is a modeled concentration filter, not established support/resistance. No pinning outcome is assumed.

### G− breakout / volatility expansion

Price-only baseline `price_bo`:

- Upward candidate: previous close above opening-range high, latest close above previous close and current VWAP
- Downward candidate: previous close below opening-range low, latest close below previous close and current VWAP
- RV_ratio ≥1.5

Gamma arm `gamma_bo`: identical confirmed price rule plus negative modeled regime. No next-bar high or later breakout is used to confirm a historical decision. Negative gamma alone supplies no direction. This implementation deliberately does not require a wall break in the breakout arm.

## 4. Option structure, selection and executable-quote hypothesis

Each directional candidate uses **one long standard SPY call** for the upward direction, or **one long standard SPY put** for the downward direction. No short legs, naked options, delta-hedging or 0DTE positions are introduced. This is a directional test of the signal, not a claim that a positive-gamma regime makes buying premium attractive. If IV decline/theta/spreads overwhelm a correct price reversal, the option policy loses and must fail the economic study.

At the decision timestamp:

1. Resolve each contract to its latest causal BBO, not the best-looking quote. Conflicting identical-vintage quotes or inconsistent identity records reject that contract.
2. Require standard 100-share deliverable, multiplier 100, American exercise, physical settlement, verified listing/last-trading metadata and matching SPY root.
3. Require 7–14 **calendar** DTE and |delta| in [0.40,0.60], with correctly signed, source/method-labeled delta known within 2 seconds. Greeks are a selection input, not a fill price.
4. Choose expiry closest to 10 calendar DTE, earlier expiry on a tie; within it choose delta closest to 0.50, then narrowest dollar spread, lower strike and contract ID.
5. Require timestamped BBO observed ≤published ≤first-seen ≤decision, age ≤2 seconds, finite uncrossed nonnegative bid/positive ask, positive displayed sizes, spread ≤$0.20/share and ≤8% of midpoint. Optionomics session analytics cannot satisfy this quote class.
6. Lock the full contract identity. It cannot change at entry or exit merely because a string ID stayed the same.

Entry is simulated only on the **first** later observed quote for that locked contract, within five seconds of decision and with current session/event gates still clear. It must independently satisfy the quote tests. Reject absolute ask drift over 5% from the selected quote. Do not search later quotes for a favorable fill or switch contracts. `simulate_entry` checks causal timing but the caller must supply evidence that this truly was the first quote; stream-order authenticity is a remaining adapter requirement.

Hypothetical entry = ask+$0.01/share, exit = max(0,bid−$0.01/share); fee=$0.70/contract/side. These are **explicit invented cost assumptions**, not a broker tariff or attainable price promise. Baseline and gamma arms must use the same assumptions and the same locked contract on common opportunities. Compare 1× and 2× spread/slippage/fee scenarios, including no-fill scenarios. Displayed sizes and crossing a quote do not guarantee execution or queue priority.

## 5. Risk sizing and portfolio state

Input equity is a hypothetical fixed research capital base, not an account balance. Max prospective loss per contract = entry debit×100 + both side fees. Quantity is the minimum of:

- 2 contracts
- floor(0.25% of research equity / per-contract loss bound)
- floor(remaining 0.50% daily loss budget / per-contract loss bound)
- floor(10% of the smaller displayed entry bid/ask size)

Remaining daily budget = max(0,0.50% equity + min(0,realized P&L today)). Gains do not expand the loss budget. This reserves full premium loss for the new position. Below one contract means no fill. At most one active position and two entries per session; no pyramiding, averaging down, borrowing or reinvestment of unrealized gains. The consumer supplies and must serialize the risk ledger; the pure function does not provide account-wide concurrency locking.

A stop is not a guaranteed loss cap. The full paid premium plus modeled fees is the stated bounded-loss basis for these long options. The policy rejects imminent/unknown ex-dividend metadata, unknown event coverage and unsupported corporate-action deliverables; it never treats a missing restriction as clear.

## 6. Holding and exits

At entry lock the underlying close P0 and σ_ref from the signal. For direction d=+1 or −1:

- Underlying stop = P0×(1−d×σ_ref)
- MR target = signal-time session VWAP (frozen)
- Breakout target = P0×(1+d×1.5×σ_ref)
- MR maximum holding 45 minutes; breakout maximum 60 minutes
- Deadline = earlier of maximum hold and session close−30 minutes
- Option premium bid ≤50% of entry debit/share triggers an exit request
- Known event blackout, halt or research-abort flag triggers an exit request
- Missing/stale (>2 seconds) underlying observation also triggers an exit request

Only new observations can trigger/price exits. Exit event times must strictly increase, including after an `EXIT_PENDING`. No intrabar best-price fill is inferred from OHLC. If stop and target could both have been crossed between observations, the subsequent admissible bid is the price; no favorable path ordering is invented.

Primary comparison uses `MATCHED_PRICE_ONLY` exits for **all** arms. Gamma changes only entry admission. A separately labeled `GAMMA_EXIT_CHALLENGER` may also request an exit when required modeled gamma disappears or flips; do not merge its outcomes into the gate-only ablation.

An exit needs the locked contract's current qualified **positive** bid and sufficient bid size. A zero bid is not an executable sale and remains unpriced; the premium-loss bound is a separate stress outcome. Wide spreads are accepted for liquidation and charged, rather than assumed away. Missing or stale delta does not block liquidation because delta is unused there. A quote for another contract cannot trigger an option stop or price the exit. If the bid cannot be established, retain `EXIT_PENDING`; do not invent a close, zero return, last mark or midpoint. At the sample boundary use `CENSORED_EXIT_UNPRICED`, P&L=null, and separately report the full-premium-loss bound. No additional position can open while this remains unresolved in the consumer ledger.

A long option has no short-option assignment obligation, but it can create an exercise/physical-delivery issue if held through expiry. This intraday, ≥7-DTE design schedules an early close and never exercises. A market halt can make that impossible; the unresolved position is censored and escalated in any later operational design. American short options can be assigned before expiration, which is one reason short spreads are outside v1. [OIC exercise and assignment](https://www.optionseducation.org/optionsoverview/exercising-options)

## 7. Matched benchmarks and incremental gamma experiment

The strategy must earn its complexity. Evaluate these preregistered arms:

- `price_mr`: price/VWAP/RV reversal only
- `gamma_mr_no_wall`: same candidate stream plus gamma sign/magnitude
- `gamma_mr`: same stream plus gamma and wall gate
- `price_bo`: price/opening-range/VWAP/RV breakout only
- `gamma_bo`: same stream plus gamma sign/magnitude
- Cash/no-trade = zero P&L before account-specific idle-cash income

Keep the **same base price-trigger opportunity ledger**, contract selector, execution timing, size convention and primary exits. For each qualified base opportunity, compute one outcome and apply the gamma acceptance mask. A gamma rejection contributes zero rather than disappearing; gamma-unavailable opportunities remain an explicit coverage stratum. Missing execution outcomes remain censored, never zero. `paired_increment` implements this opportunity-level comparison. It is not a feasible overlapping portfolio return; separately run each arm's one-position/two-entry ledger to assess capital constraints.

Report signed underlying log returns at exactly matched entry/exit instants with stated bps costs as a diagnostic. Do not label them option P&L. The regression suite contains a case where the underlying target is reached but the long option loses money.

Additional preregistered falsifiers, to be run only after qualified market data exists:

1. Invert all modeled dealer signs while preserving OI, dates and price features.
2. Replace walls with listed strikes matched on distance to price, strike spacing and date. Randomly select among that eligible set with seed 20261009; a pseudo-wall comparison must not silently change distances or availability.
3. Lag inventory assumptions by one full exchange session while recomputing Greeks only from then-known inputs; report coverage loss and never relabel lagged inventory as current observation.
4. Train-only residualize normalized gamma and wall distance on time-of-day, spot/strike distance, RV, trend, IV level/skew and liquidity. Compare incremental information, not raw strategy mean alone. If these controls are unavailable, this specific inference is unavailable.
5. Compare 0.0025/0.005/0.01 magnitude thresholds and 0.125/0.25/0.5 sigma wall bands as a disclosed sensitivity family. Do not select winners from holdout results.

The code runs missing-model, sign-intervention, wall-ablation, ordering and matched-outcome arithmetic checks on invented values. It does not claim to have run the market falsifiers, fitted residual models or measured an edge.

## 8. Walk-forward methodology and stopping rules

Seal all input hashes, trade eligibility, threshold choices, source vintages, costs, model inventory assumptions and any selection family **before** outcome inspection. Use consecutive actual exchange sessions, retaining gap/abstention rows. Initial research minimum: 252 sessions training, 63 development sessions, then at least 126 sealed test sessions. These are protocol choices, not assurances of statistical power; insufficient independent events means inconclusive.

The present deterministic rules need no fitted predictor. For any later learned gamma-inventory calibration or residual/control model, use expanding past-only folds and refit every 63 exchange sessions. `expanding_walk_forward` groups by supplied session and excludes training labels whose endpoint or first availability is not strictly before the fit origin. This prevents future-label leakage; the fixture demonstrates the rule with small invented folds. Calendar validity and label authenticity remain upstream requirements.

Do not tune this policy on test sessions. Earlier test labels may enter a later scheduled fit only if the protocol expressly specifies prequential refitting and they have matured; report this clearly rather than calling all parameters frozen. Purge labels overlapping a fit/test boundary. With intraday exits there should be no overnight return label, but unpriced exits remain censored and cannot become training outcomes until actually resolved. Use same-day clustering, and resample 5-consecutive-session blocks (2,000 draws, seed 20261009) with all arms and missingness masks together for uncertainty. Threshold families require multiplicity reporting; no uncorrected best-of-many significance claim.

Primary endpoint: incremental after-cost option USD P&L per common price-trigger opportunity, accompanied by regime coverage and executable-quote coverage. Secondary endpoints: feasible portfolio after-cost P&L, turnover, drawdown, full-premium-loss incidence, unresolved exit rate, tail quantiles and worst marked scenarios. Never infer a profitable bot from hit rate or gross underlying returns. Report both coverage-conditioned estimates and all-opportunity censoring bounds; no independent-market evidence currently exists.

Stop promotion if gamma adds no stable incremental information beyond price/RV/IV/liquidity controls, sign alternatives work equally well, pseudo-walls do as well, costs remove apparent gains, inventory sensitivity reverses the conclusion, or close coverage is inadequate. A failed or inconclusive gamma test does not invalidate the simpler price benchmark; it removes the claimed gamma advantage.

## 9. Events, tail cases and market-open observation contract

Before any later prospective observation, establish the actual regular-session calendar, scheduled macro announcements, material ETF/index events, ex-dividend date, halts/corporate actions and data rights. v1's `VERIFIED_CLEAR` is an externally evidenced input. Proposed event window: no new entries from 15 minutes before until 15 minutes after scheduled CPI, payrolls, FOMC decisions/press conferences or other prelisted high-impact releases; request close before the blackout starts. Unknown or expired calendar evidence blocks entries. Unscheduled news cannot be completely excluded; document residual jump risk.

At the next market open, the useful authorized activity would be a **read-only observation**, only if actual qualified sources are available:

1. At open, create an immutable observation ledger with UTC and ET clocks, calendar/source versions, payload hashes, read-only scope and `orders_enabled=false`.
2. Record arriving bar vintages, true price-volume, gap events and current quote timestamps/sizes; retain stale and missing rows with reasons.
3. Separately ask whether a causally timestamped and explained inventory model exists. Public OI alone or undocumented derived “dealer” fields means `NO_SIGNAL`; do not synthesize signs.
4. After warm-up, log all price-only and gamma-arm decisions on the same minute grid. The price-only diagnostic can run if gamma is absent; option selection still needs a qualified timestamped chain.
5. Do not label a candidate “filled.” Any quote-crossing result remains a hypothetical research fill with assumptions. If execution-quality data is absent, record no-fill or unpriced, not performance.
6. End at the ordinary session cutoff, retain unresolved marks and input hashes, and report coverage, refusal counts and schema issues. No trade recommendation, activation, monitor or scheduled observation has been started by this package.

If no compliant, free or already-authorized data sample meets the contract, the terminal result is `DATA_NOT_AVAILABLE`. This is a complete offline prototype with explicit live applicability gaps, not an invitation to buy access or scrape archives.

## 10. Current provider hazards and data gaps

The official Optionomics reference describes session-ingested research analytics rather than execution data. Its quote endpoint's regime follows the live session even when another date is requested. `total_gex=0` can indicate that exposures were not calculated. The general expected-move metric uses the front-expiration horizon, and IV strings represent annualized decimal volatility. These semantics require explicit rejection or mapping; they do not establish dealer-sign methodology, causal historical vintages or account entitlement. The refusal adapter and tests preserve these hazards. No authenticated API call was made. [Official API documentation](https://www.optionomics.ai/docs/api)

Outstanding inputs: defensible signed-inventory model/scenario provenance; complete point-in-time option universe and OI vintages; licensed/authorized minute trade aggregates and true VWAP numerators; live-quality timestamped option BBO/delta at entry and exits; history of quote revisions; then-known calendar/events/dividends; actual fee model and executable fill study. No actual market dataset or entitlement is present.

## 11. Vanna/charm: precise deferral

For modeled position D_i and delta Δ_i(S,σ,t), a local hedge differential includes −Σ M_i[D_iΓ_i dS + D_i(∂Δ_i/∂σ)dσ + D_i(∂Δ_i/∂t)dt + Δ_i dD_i], plus higher-order/cross terms. Here t is forward calendar time, so charm is ∂Δ/∂t, not an unlabeled derivative with respect to remaining maturity. A volatility-point unit must be distinguished from one whole decimal-volatility unit.

Signed inventory, the actual volatility-surface response, intraday position changes, hedge offsets/timing and time-to-expiry conventions are missing. Even a computed vanna/charm sensitivity would not identify a causal directional flow. The executable `vanna_charm_decision()` therefore returns `NO_SIGNAL`. A later study would need those inputs and incremental tests against price/IV changes before a directional policy is justified.

## 12. Reproduce and inspect

From this directory:

    python -m unittest -v test_gamma_research.py
    python run_research.py --out synthetic_results_v1.json
    python run_research.py --write-example synthetic_input_v1.json --out synthetic_results_v1.json
    python run_research.py --input synthetic_input_v1.json --out synthetic_decision_v1.json

The JSON example is a complete invented decision-input contract, not a market sample. Output and source hashes, exact command results and independent review are saved separately. Synthetic pass counts establish implemented arithmetic and refusal behavior only. They establish **no profitability, optimality, capacity, dealer-flow measurement or market-open readiness**.
