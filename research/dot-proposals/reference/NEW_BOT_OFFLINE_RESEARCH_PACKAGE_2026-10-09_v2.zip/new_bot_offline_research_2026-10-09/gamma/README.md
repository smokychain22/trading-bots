# Gamma research prototype v1

Executable offline prototype with two policies, their price-only benchmarks and an explicitly deferred vanna/charm hypothesis. No orders, feeds, accounts, external publication, actual dealer inventories or market performance.

- `PLAYBOOK_GAMMA_RESEARCH_V1.md`: complete policy, math, selection/cost/holding/risk rules, ablation and walk-forward protocol, and prospective observation contract
- `gamma_research.py`: pure decision, contract-selection, simulated entry/exit and research-comparison functions
- `synthetic_fixture.py`: invented input generator
- `run_research.py`: deterministic demonstration and offline JSON decision runner
- `test_gamma_research.py`: refusal/causality/arithmetic regression suite
- `synthetic_input_v1.json`: full invented input contract
- `synthetic_results_v1.json`, `synthetic_decision_v1.json`: reproducible demonstrations
- `SOURCE_REGISTER_V1.json`: checked primary sources and limitations
- `verify_reproduce.py`: clean relative-path reproduction entrypoint
- `READINESS_V1.json`: implemented scope and explicit live-applicability gaps
- `PUBLIC_SAFE_MANIFEST_V1.json`: exact public-safe whitelist and hashes
- `verification/`: exact commands, receipts and hashes
- `independent_review/`: independent mathematical/code checks and findings

Run `python -m unittest -v test_gamma_research.py` and `python run_research.py --out synthetic_results_v1.json` in this directory. Standard-library Python only. `market_shadow` rejects synthetic inputs; no market adapter/data exists. A research candidate never has order authority. Read the playbook before interpreting any output.

For a clean copied package, run `python verify_reproduce.py`; it reruns both suites and checks byte-identical demonstration outputs. The public-safe manifest excludes Python caches and is for packaging only, not publication authorization.
