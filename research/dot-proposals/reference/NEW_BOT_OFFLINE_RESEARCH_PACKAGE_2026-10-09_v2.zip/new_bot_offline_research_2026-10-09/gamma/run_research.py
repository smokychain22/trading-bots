#!/usr/bin/env python3
"""Deterministic synthetic demonstration and offline JSON-input decision runner."""
import argparse
import json
from pathlib import Path
from dataclasses import asdict, replace
from datetime import timedelta
from gamma_research import *
from synthetic_fixture import bars, session, gamma, decision_time, quote, iso

def demo():
    output={'version':VERSION,'status':'OFFLINE_SYNTHETIC_LOGIC_DEMONSTRATION',
            'performance_evidence':False,'market_observations':0,'orders_enabled':False,'examples':[]}
    for kind in ('mr','bo'):
        for direction in (-1,1):
            bs=bars(kind,direction);at=decision_time(bs);s=session();g=gamma(bs,1 if kind=='mr' else -1)
            results=[]
            for arm in ['price_'+kind,'gamma_'+kind]+(['gamma_mr_no_wall'] if kind=='mr' else []):
                d=decide(arm,bs,s,at,g,'synthetic')
                p=plan_option(d,[quote(at,direction)],RiskState(100000),'synthetic')
                et=iso(stamp(at)+timedelta(seconds=1))
                opened=simulate_entry(p,quote(et,direction),s,et,'synthetic')
                xt=iso(stamp(et)+timedelta(minutes=5))
                closed=exit_step(opened,xt,opened['target_underlying'],xt,quote(xt,direction,bid=2.1,ask=2.16),mode='synthetic')
                results.append({'decision':asdict(d),'simulated_position':closed})
            output['examples'].append({'scenario':kind,'direction':direction,'arms':results})
    bs=bars();at=decision_time(bs);s=session()
    output['honest_missing_model']=asdict(decide('gamma_mr',bs,s,at,None,'synthetic'))
    output['vanna_charm']=vanna_charm_decision()
    output['paired_ablation_arithmetic']=paired_increment([
        {'after_cost_pnl_usd':10,'gamma_available':True,'gamma_accept':True},
        {'after_cost_pnl_usd':-4,'gamma_available':True,'gamma_accept':False},
        {'after_cost_pnl_usd':None,'gamma_available':True,'gamma_accept':False}])
    return output

def from_json(payload):
    if payload.get('schema_version') != VERSION:
        raise ValueError('SCHEMA_VERSION_REQUIRED')
    if payload.get('mode') not in ('synthetic','market_shadow'):
        raise ValueError('MODE_REQUIRED')
    s=Session(**payload['session']);bs=[Bar(**b) for b in payload['bars']]
    g=payload.get('gamma_input')
    if g is not None:
        g=dict(g);g['rows']=tuple(PositionRow(**r) for r in g['rows'])
        g['prior20_dollar_volume']=tuple(g['prior20_dollar_volume'])
        g['prior20_session_ends']=tuple(g['prior20_session_ends'])
        g=GammaInput(**g)
    return asdict(decide(payload['arm'],bs,s,payload['decision_at'],g,payload['mode']))

def example_input():
    bs=bars();return {'schema_version':VERSION,'mode':'synthetic','arm':'gamma_mr',
      'decision_at':decision_time(bs),'session':asdict(session()),'bars':[asdict(b) for b in bs],
      'gamma_input':asdict(gamma(bs))}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path);ap.add_argument('--out',type=Path)
    ap.add_argument('--write-example',type=Path);a=ap.parse_args()
    if a.write_example:
        a.write_example.write_text(json.dumps(example_input(),indent=2)+'\n')
    result=from_json(json.loads(a.input.read_text())) if a.input else demo()
    body=json.dumps(result,indent=2,sort_keys=True,allow_nan=False)+'\n'
    if a.out:a.out.write_text(body)
    else:print(body,end='')
