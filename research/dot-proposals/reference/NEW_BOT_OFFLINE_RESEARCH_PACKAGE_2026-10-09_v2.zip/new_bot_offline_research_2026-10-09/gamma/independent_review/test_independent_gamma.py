"""Independent adversarial checks. Invented data only; not performance evidence.

Run from any directory:
PYTHONDONTWRITEBYTECODE=1 python test_independent_gamma.py
"""
from dataclasses import asdict, replace
from datetime import timedelta
from decimal import Decimal
from itertools import product, permutations
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from gamma_research import (Config, PositionRow, RiskState, causal_bars,
                            censor_unclosed, decide, exit_step,
                            expanding_walk_forward, gamma_features,
                            paired_increment, plan_option, quote_reject,
                            simulate_entry, stamp, underlying_benchmark)
from synthetic_fixture import bars, decision_time, gamma, quote, session


def later(at, seconds):
    return (stamp(at) + timedelta(seconds=seconds)).isoformat()


class IndependentGammaChecks(unittest.TestCase):
    def setUp(self):
        self.bs = bars()
        self.s = session()
        self.at = decision_time(self.bs)
        self.d = decide('price_mr', self.bs, self.s, self.at, mode='synthetic')
        self.g = gamma(self.bs)

    def opened(self, *, decision=None, risk=None, **kwargs):
        d = decision or self.d
        p = plan_option(d, [quote(self.at)], risk or RiskState(100000), mode='synthetic')
        at = later(self.at, 1)
        return simulate_entry(p, quote(at), self.s, at, mode='synthetic', **kwargs)

    def test_fixture_is_explicitly_invented(self):
        self.assertTrue(all(b.synthetic and b.rights == 'SYNTHETIC' for b in self.bs))
        self.assertTrue(self.g.synthetic)
        self.assertIn('not inferred from OI', self.g.inventory_assumptions)

    def test_units_against_decimal_oracle_and_both_option_types(self):
        for typ in ('call', 'put'):
            r = PositionRow('ORACLE_' + typ, 100, typ, self.g.rows[0].expiry,
                            100, .02, 100, 50, 100)
            g = replace(self.g, spot_reference=100, rows=(r,))
            f, bad = gamma_features(g, self.s, self.at, 100, 'synthetic')
            self.assertIsNone(bad)
            unit = Decimal('.01') * 100 * 100 * 100 * Decimal('.02')
            self.assertEqual(f['g_low_usd_per_1pct'], float(unit * 50))
            self.assertEqual(f['g_high_usd_per_1pct'], float(unit * 100))

    def test_interval_encloses_all_box_corners(self):
        rows = (
            PositionRow('A', 100, 'call', self.g.rows[0].expiry, 100, .02, 100, 20, 90),
            PositionRow('B', 101, 'put', self.g.rows[0].expiry, 100, .03, 100, -80, -10),
        )
        f, bad = gamma_features(replace(self.g, spot_reference=100, rows=rows),
                                self.s, self.at, 100, 'synthetic')
        self.assertIsNone(bad)
        corners = [sum(.01 * 100**2 * r.multiplier * r.long_gamma * n
                       for r, n in zip(rows, corner))
                   for corner in product(*[(r.modeled_dealer_contracts_low,
                                            r.modeled_dealer_contracts_high) for r in rows])]
        self.assertAlmostEqual(f['g_low_usd_per_1pct'], min(corners))
        self.assertAlmostEqual(f['g_high_usd_per_1pct'], max(corners))

    def test_identical_oi_has_no_unique_dealer_sign(self):
        regimes = []
        for low, high in [(6000, 8000), (-8000, -6000), (-8000, 8000)]:
            r = replace(self.g.rows[0], modeled_dealer_contracts_low=low,
                        modeled_dealer_contracts_high=high)
            f, bad = gamma_features(replace(self.g, rows=(r,)), self.s, self.at,
                                    self.bs[-1].close, 'synthetic')
            self.assertIsNone(bad)
            regimes.append(f['regime'])
        self.assertEqual(regimes, ['POSITIVE', 'NEGATIVE', 'NEUTRAL_OR_AMBIGUOUS'])

    def test_oi_sign_shortcut_is_rejected(self):
        d = decide('gamma_mr', self.bs, self.s, self.at,
                   replace(self.g, sign_method='CALL_POSITIVE_PUT_NEGATIVE'), 'synthetic')
        self.assertEqual(d.status, 'NO_SIGNAL')

    def test_delayed_revision_cannot_rewrite_decision(self):
        revised = replace(self.bs[-1], revision=9, close=self.bs[-1].close + .001,
                          published_at=later(self.at, 100), first_seen_at=later(self.at, 100))
        d = decide('price_mr', self.bs + [revised], self.s, self.at, mode='synthetic')
        self.assertEqual(asdict(d), asdict(self.d))

    def test_first_seen_delay_is_not_backdated(self):
        b = replace(self.bs[-1], first_seen_at=later(self.at, 1))
        d = decide('price_mr', self.bs[:-1] + [b], self.s, self.at, mode='synthetic')
        self.assertEqual(d.reason, 'BAR_GAP_OR_LATE')

    def test_off_grid_decisions_fail_closed(self):
        for offset in (-1, 1):
            d = decide('price_mr', self.bs, self.s, later(self.at, offset), mode='synthetic')
            self.assertEqual(d.status, 'NO_TRADE')
            self.assertEqual(d.reason, 'OFF_DECISION_GRID')

    def test_bar_permutation_and_exact_duplicates_are_invariant(self):
        d = decide('price_mr', list(reversed(self.bs)) + [self.bs[5]], self.s,
                   self.at, mode='synthetic')
        self.assertEqual(asdict(d), asdict(self.d))

    def test_same_revision_conflict_fails_closed(self):
        b = replace(self.bs[-1], close=self.bs[-1].close + .001)
        d = decide('price_mr', self.bs + [b], self.s, self.at, mode='synthetic')
        self.assertNotEqual(d.status, 'RESEARCH_CANDIDATE')

    def test_superseded_revision_conflicts_are_order_invariant(self):
        old = self.bs[-1]
        conflicting = replace(old, close=old.close + .001)
        newer = replace(old, revision=1, close=old.close + .002)
        results = []
        for tail in permutations((old, conflicting, newer)):
            d = decide('price_mr', self.bs[:-1] + list(tail), self.s,
                       self.at, mode='synthetic')
            results.append((d.status, d.reason))
        self.assertEqual(set(results), {('NO_TRADE', 'BAR_REVISION_CONFLICT')})

    def test_latest_contract_bbo_wins_over_narrower_old_bbo(self):
        old = replace(quote(self.at), observed_at=later(self.at, -1), bid=1.99)
        new = quote(self.at)
        for chain in ([old, new], [new, old]):
            p = plan_option(self.d, chain, RiskState(100000), mode='synthetic')
            self.assertEqual(p['selected_quote'], asdict(new))

    def test_future_quote_does_not_rewrite_plan(self):
        q = quote(self.at)
        future = replace(q, observed_at=later(self.at, 1), published_at=later(self.at, 1),
                         first_seen_at=later(self.at, 1), bid=2, ask=2.01)
        p = plan_option(self.d, [q, future], RiskState(100000), mode='synthetic')
        self.assertEqual(p['selected_quote'], asdict(q))

    def test_latest_invalid_quote_cannot_fall_back_to_old(self):
        old = replace(quote(self.at), observed_at=later(self.at, -1))
        bad = replace(quote(self.at), bid=3)
        p = plan_option(self.d, [old, bad], RiskState(100000), mode='synthetic')
        self.assertEqual(p['status'], 'NO_TRADE')

    def test_nonfinite_latest_quote_returns_refusal_not_hash_exception(self):
        old = replace(quote(self.at), observed_at=later(self.at, -1))
        for field in ('ask', 'delta'):
            with self.subTest(field=field):
                bad = replace(quote(self.at), **{field:float('nan')})
                for chain in ([bad], [old, bad]):
                    p = plan_option(self.d, chain, RiskState(100000), mode='synthetic')
                    self.assertEqual(p['status'], 'NO_TRADE')

    def test_same_vintage_conflict_is_not_optimized(self):
        q = quote(self.at)
        p = plan_option(self.d, [q, replace(q, bid=1.99)], RiskState(100000), mode='synthetic')
        self.assertEqual(p['status'], 'NO_TRADE')

    def test_daily_budget_reserves_whole_premium_and_fees(self):
        p = self.opened(risk=RiskState(100000, realized_pnl_today=-499))
        self.assertEqual(p['status'], 'NO_FILL')
        p = self.opened(risk=RiskState(100000, realized_pnl_today=-290))
        self.assertEqual(p['status'], 'SIMULATED_OPEN')
        self.assertLessEqual(p['max_loss_budget_usd'], 210)

    def test_entry_same_quote_and_more_than_five_seconds_fail(self):
        p = plan_option(self.d, [quote(self.at)], RiskState(100000), mode='synthetic')
        for at in (self.at, later(self.at, 6)):
            self.assertEqual(simulate_entry(p, quote(at), self.s, at,
                                            mode='synthetic')['status'], 'NO_FILL')

    def test_exit_cannot_go_backwards_after_observation(self):
        p = self.opened()
        at = later(p['entry_at'], 10)
        p = exit_step(p, at, self.d.features['close'], at, quote(at), mode='synthetic')
        earlier = later(at, -5)
        with self.assertRaises(ValueError):
            exit_step(p, earlier, self.d.features['close'], earlier, quote(earlier),
                      mandatory_exit=True, mode='synthetic')

    def test_full_identity_is_locked_at_exit(self):
        p = self.opened()
        at = later(p['entry_at'], 10)
        q = replace(quote(at), strike=200, option_type='put', delta=-.5)
        result = exit_step(p, at, None, None, q, mandatory_exit=True, mode='synthetic')
        self.assertEqual(result['status'], 'EXIT_PENDING')
        self.assertEqual(result['exit_blocker'], 'LOCKED_CONTRACT_MISMATCH')

    def test_unrelated_cheap_quote_cannot_latch_premium_stop(self):
        p = self.opened()
        at = later(p['entry_at'], 10)
        q = quote(at, contract_id='UNRELATED_CONTRACT', bid=.40, ask=.45)
        result = exit_step(p, at, self.d.features['close'], at, q, mode='synthetic')
        self.assertNotEqual(result.get('exit_trigger'), 'PREMIUM_DRAWDOWN_50PCT')

    def test_mismatched_metadata_cannot_latch_premium_stop(self):
        p = self.opened()
        at = later(p['entry_at'], 10)
        q = replace(quote(at, bid=.40, ask=.45), strike=200)
        result = exit_step(p, at, self.d.features['close'], at, q, mode='synthetic')
        self.assertNotEqual(result.get('exit_trigger'), 'PREMIUM_DRAWDOWN_50PCT')

    def test_exit_does_not_depend_on_unused_delta(self):
        p = self.opened()
        at = p['deadline']
        for delta in (None, float('nan'), -.5):
            with self.subTest(delta=delta):
                q = replace(quote(at), delta=delta)
                result = exit_step(p, at, None, None, q, mandatory_exit=True, mode='synthetic')
                self.assertEqual(result['status'], 'SIMULATED_CLOSED')

    def test_wide_exit_crosses_bid_without_reusing_entry_filter(self):
        p = self.opened()
        at = p['deadline']
        q = quote(at, bid=.2, ask=3)
        result = exit_step(p, at, None, None, q, mandatory_exit=True, mode='synthetic')
        self.assertEqual(result['status'], 'SIMULATED_CLOSED')
        self.assertAlmostEqual(result['exit_price'], .19)

    def test_pending_exit_is_censored_not_zero_pnl(self):
        p = self.opened()
        at = p['deadline']
        pending = exit_step(p, at, None, None, None, mandatory_exit=True, mode='synthetic')
        result = censor_unclosed(pending)
        self.assertIsNone(result['pnl_usd'])
        self.assertEqual(result['worst_case_premium_loss_usd'], -p['max_loss_budget_usd'])

    def test_unchanged_bbo_costs_exactly_spread_slippage_and_fees(self):
        p = self.opened()
        at = p['deadline']
        result = exit_step(p, at, None, None, quote(at), mandatory_exit=True, mode='synthetic')
        expected = (Decimal('1.94') - Decimal('.01') - Decimal('2.00') - Decimal('.01')) * 100
        expected -= Decimal('.70') * 2
        self.assertAlmostEqual(result['pnl_usd'], float(expected) * p['quantity'])

    def test_zero_bid_is_unpriced_and_censoring_retains_loss_bound(self):
        p = self.opened()
        at = p['deadline']
        result = exit_step(p, at, None, None, quote(at, bid=0, ask=.05),
                           mandatory_exit=True, mode='synthetic')
        self.assertEqual(result['status'], 'EXIT_PENDING')
        self.assertEqual(result['exit_blocker'], 'NO_POSITIVE_EXIT_BID')
        censored = censor_unclosed(result)
        self.assertIsNone(censored['pnl_usd'])
        self.assertAlmostEqual(censored['worst_case_premium_loss_usd'], -p['max_loss_budget_usd'])

    def test_zero_bid_triggers_stop_but_cannot_price_exit(self):
        p = self.opened()
        at = later(p['entry_at'], 10)
        result = exit_step(p, at, self.d.features['close'], at,
                           quote(at, bid=0, ask=.05), mode='synthetic')
        self.assertEqual(result['status'], 'EXIT_PENDING')
        self.assertEqual(result['exit_trigger'], 'PREMIUM_DRAWDOWN_50PCT')
        self.assertEqual(result['exit_blocker'], 'NO_POSITIVE_EXIT_BID')

    def test_market_mode_rejects_explicit_synthetic_rights(self):
        bs = [replace(b, synthetic=False) for b in self.bs]
        d = decide('price_mr', bs, self.s, self.at, mode='market_shadow')
        self.assertNotEqual(d.status, 'RESEARCH_CANDIDATE')
        g = replace(self.g, synthetic=False)
        _, bad = gamma_features(g, self.s, self.at, self.bs[-1].close, 'market_shadow')
        self.assertIsNotNone(bad)
        q = replace(quote(self.at), synthetic=False, quote_class='TIMESTAMPED_BBO')
        self.assertIsNotNone(quote_reject(q, self.at, 'market_shadow'))

    def test_gate_primary_has_identical_exit_policy_and_pnl(self):
        gd = decide('gamma_mr', self.bs, self.s, self.at, self.g, 'synthetic')
        p0, pg = self.opened(), self.opened(decision=gd)
        self.assertEqual(p0['exit_policy'], 'MATCHED_PRICE_ONLY')
        self.assertEqual(pg['exit_policy'], 'MATCHED_PRICE_ONLY')
        at = p0['deadline']
        x0 = exit_step(p0, at, None, None, quote(at), mode='synthetic')
        xg = exit_step(pg, at, None, None, quote(at), mode='synthetic')
        self.assertEqual(x0['pnl_usd'], xg['pnl_usd'])
        self.assertEqual(x0['exit_trigger'], xg['exit_trigger'])

    def test_matched_ablation_denominator_is_common_qualified(self):
        result = paired_increment([
            {'after_cost_pnl_usd':20, 'gamma_available':True, 'gamma_accept':True},
            {'after_cost_pnl_usd':-10, 'gamma_available':True, 'gamma_accept':False},
            {'after_cost_pnl_usd':1000, 'gamma_available':False, 'gamma_accept':False},
            {'after_cost_pnl_usd':None, 'gamma_available':True, 'gamma_accept':False},
        ])
        self.assertEqual(result['common_qualified'], 2)
        self.assertEqual(result['censored_or_gamma_missing'], 2)
        self.assertEqual(result['mean_increment_usd_per_opportunity'], 5)

    def test_walk_forward_uses_label_availability_not_only_end(self):
        rows = []
        for day in range(5):
            at = later(self.at, 86400 * day)
            rows.append({'id':str(day), 'session':stamp(at).date().isoformat(),
                         'decision_at':at, 'label_end':later(at, 60),
                         'label_available_at':later(at, 120)})
        rows[0]['label_available_at'] = later(self.at, 86400 * 4)
        folds = expanding_walk_forward(rows, train_sessions=2, test_sessions=1)
        self.assertEqual(folds[0]['train_ids'], ['1'])
        self.assertTrue(all(set(f['train_ids']).isdisjoint(f['test_ids']) for f in folds))

    def test_underlying_return_is_labeled_separately(self):
        result = underlying_benchmark(1, 100, 101)
        self.assertEqual(result['meaning'], 'DIRECTION_DIAGNOSTIC_NOT_OPTION_PNL')


if __name__ == '__main__':
    unittest.main(verbosity=2)
