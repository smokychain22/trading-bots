# Independent Gamma v1 review

Review date: 2026-10-09 UTC. Scope: the isolated offline prototype, fixture, runner, main regression suite, README and playbook. No production repository, network feed, broker, account, order or publication action was used. All test inputs are invented. **Passing synthetic checks is not performance evidence.**

## Result

Thirty-three independently written adversarial checks pass on the source bytes recorded in `review_receipt.json`. The main regression suite was independently rerun. The demonstration and JSON-input runner were independently regenerated, with byte-for-byte equality against the supplied reference outputs at verification time. See the receipt for exact command exit codes, counts, timings and hashes.

No unresolved material defect was found in the reviewed paths after the fixes below. This is a bounded mathematical and software review, not empirical validation or approval for market use.

## Findings reproduced and subsequently fixed

1. **Retroactive exits.** An open position previously accepted an exit timestamp earlier than its last observation. Strictly increasing event timestamps now reject this.
2. **Best-looking stale BBO selection.** Two fresh records for one contract could cause the narrower older quote to win contract selection. Latest causal vintage now wins; a bad latest quote cannot fall back to a favorable earlier quote, and same-vintage conflicts are rejected.
3. **Incomplete exit identity.** Keeping a contract ID while changing strike/type/expiry previously priced an unrelated exit. Full immutable contract identity is now checked.
4. **Unrelated quote contaminating a stop.** A cheap quote for another contract could latch the premium stop before identity rejection, then force closure at the next valid quote. Identity is now verified before premium-stop evaluation.
5. **Daily loss budget overshoot.** At a realized loss of $499 on $100,000 research equity, a new $202.40 full-loss position was allowed despite the $500 daily budget. Remaining daily budget now caps quantity before entry; premium and both fees are reserved.
6. **Unused delta blocking liquidation.** A valid bid with missing/nonfinite/mis-signed delta previously prevented exit. Delta validation is now entry-only; a usable locked-contract bid remains usable for liquidation.
7. **Synthetic provenance inconsistency.** Records with explicit `SYNTHETIC` rights could enter market mode if the separate boolean/class were relabeled. Explicit synthetic rights now also cause rejection.
8. **Order-dependent historical conflicts.** With two conflicting revision-0 bars and a valid revision-1 bar, input permutation determined whether the conflict was detected. Every causally visible `(bar end, revision)` conflict is now detected before selecting the highest revision. All six adversarial permutations reject identically.
9. **Nonfinite quotes escaping the refusal ledger.** The latest-vintage grouping initially hashed malformed quotes before validating them, so a NaN ask/delta raised a JSON exception instead of returning a no-trade result. Such latest quotes now return a refusal and cannot fall back to an older usable quote.

## Independent mathematical and causal checks

- Decimal oracle verifies dollar delta sensitivity units for calls and puts. Both have positive long-option gamma; dealer sign is an explicit inventory assumption.
- Enumerated interval corners verify aggregation of independent signed-inventory bounds.
- Identical open interest permits positive, negative and ambiguous modeled regimes. An OI-based sign shortcut is rejected.
- Later corrections, delayed first-seen timestamps, input reordering, duplicate bars and conflicting revisions are tested.
- Latest/future/conflicting option quotes, first subsequent quote timing, drift-independent causal timing and locked identity are exercised.
- Unchanged option BBO loses exactly spread, two slippage charges and two fees under the configured assumptions. A zero bid can request a premium stop but cannot supply a hypothetical sale price; the exit stays pending and censoring preserves a separate premium-plus-fees loss bound.
- Wide-spread liquidation, missing-exit censoring, monotone exits and unrelated premium-stop contamination are covered.
- Gamma-gated primary arms use the same price-only exit policy and same outcome on shared opportunities. Missing outcomes and missing gamma remain excluded coverage strata, rather than zero returns.
- Walk-forward training uses label availability as well as label end; training and test IDs are disjoint in the independent fixture.

## Important limits retained in the playbook

- No market observations, realized performance, calibrated dealer-inventory reconstruction, price impact, capacity or executable fill study exists here.
- Scenario intervals cover the supplied inventory assumptions. They are not statistical confidence intervals and do not quantify gamma-surface, scope, hedge-timing or omitted-book uncertainty.
- `complete_scope`, calendar/rights attestations and hashes cannot independently authenticate their upstream sources. The fixture calendar is invented.
- The caller must establish that the entry quote truly is the first subsequent observation, persist append-only decision/source receipts, and serialize the risk ledger. These pure functions do not implement a full stream adapter or concurrency-safe portfolio engine.
- The opportunity-level matched comparison is conditional on common qualified outcomes. It is not an overlapping portfolio backtest. Coverage-conditioned estimates, all-opportunity censoring bounds and separate feasible portfolio results remain necessary.
- Actual market falsifiers, pseudo-wall controls, residual models, holdout uncertainty and walk-forward empirical testing remain a specified protocol, not completed results.
- Vanna/charm is deliberately deferred. Underlying directional returns are labeled separately from option P&L.

The README and playbook disclose these boundaries consistently with the implementation. External source claims were not independently re-fetched by this code-review pass.

The relative-path package verifier and public-safe manifest are packaging additions. Their inclusion does not expand this engine review into source-entitlement or privacy certification.

## Reproduction

From `gamma/v1`:

    PYTHONDONTWRITEBYTECODE=1 python independent_review/test_independent_gamma.py
    PYTHONDONTWRITEBYTECODE=1 python -m unittest -v test_gamma_research.py
    PYTHONDONTWRITEBYTECODE=1 python run_research.py --out independent_review/synthetic_demo_rerun.json
    PYTHONDONTWRITEBYTECODE=1 python run_research.py --input synthetic_input_v1.json --out independent_review/json_decision_rerun.json

`review_receipt.json` and `SHA256SUMS` bind this report to the exact reviewed files. Later source edits require rerunning the checks; these receipts do not automatically cover them.
