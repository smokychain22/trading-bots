#!/usr/bin/env python3
"""Gamma incubator v1. Offline, no network, broker, order or production integration.
All executable examples are invented. Dealer positions are model inputs, never OI facts.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, field
from datetime import datetime, timedelta
from math import isfinite, log, sqrt, floor
from statistics import median
from typing import Optional
import hashlib
import json

VERSION = 'GAMMA_RESEARCH_V1'
CONTRACT_IDENTITY = ('contract_id','symbol','option_type','strike','expiry','last_trade_at','exercise','settlement','multiplier','standard_deliverable')

def stamp(s: str) -> datetime:
    d = datetime.fromisoformat(s.replace('Z', '+00:00'))
    if d.tzinfo is None:
        raise ValueError('NAIVE_TIME')
    return d

def digest(x) -> str:
    return hashlib.sha256(json.dumps(x, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()

def finite(*xs) -> bool:
    return all(isinstance(x, (int, float)) and not isinstance(x, bool) and isfinite(x) for x in xs)

@dataclass(frozen=True)
class Config:
    gamma_floor: float = .005  # dollars delta-notional / 1% move, divided by prior daily dollar volume
    gamma_max_age_s: int = 60
    quote_max_age_s: int = 2
    bar_latency_s: int = 2
    wall_tolerance_sigma: float = .25
    wall_min_fraction: float = .20
    mr_z: float = 1.0
    mr_max_rv_ratio: float = 1.5
    bo_min_rv_ratio: float = 1.5
    risk_fraction: float = .0025
    daily_loss_fraction: float = .005
    max_entries: int = 2
    max_contracts: int = 2
    size_fraction: float = .10
    max_spread_fraction: float = .08
    max_spread_usd: float = .20
    fee_per_contract_side: float = .70
    slippage_per_share_side: float = .01
    max_entry_price_drift: float = .05

@dataclass(frozen=True)
class Bar:
    symbol: str
    start: str
    end: str
    published_at: str
    first_seen_at: str
    revision: int
    open: float
    high: float
    low: float
    close: float
    volume: float
    price_volume: float  # sum actual trade price * size, NOT typical-price approximation
    source: str
    rights: str
    synthetic: bool = False

@dataclass(frozen=True)
class Session:
    symbol: str
    open_at: str
    close_at: str
    calendar_version: str
    calendar_known_at: str
    event_state: str  # VERIFIED_CLEAR, BLACKOUT, UNKNOWN
    event_known_at: str
    event_valid_until: str
    ex_dividend_before_next_session: Optional[bool]
    halted: bool = False
    standard_full_session: bool = True
    calendar_source: str = ''
    event_source: str = ''

@dataclass(frozen=True)
class PositionRow:
    contract_id: str
    strike: float
    option_type: str
    expiry: str
    multiplier: int
    long_gamma: float  # delta change per $1 underlying move, per option share
    open_interest: int
    modeled_dealer_contracts_low: float
    modeled_dealer_contracts_high: float

@dataclass(frozen=True)
class GammaInput:
    symbol: str
    spot_reference: float
    observed_at: str
    published_at: str
    first_seen_at: str
    model_version: str
    sign_method: str
    source: str
    source_payload_sha256: str
    rights: str
    synthetic: bool
    scope: str
    complete_scope: bool
    rows: tuple[PositionRow, ...]
    prior20_dollar_volume: tuple[float, ...]
    scale_known_at: str
    scale_last_session_end: str
    scale_source: str
    surface_method: str
    inventory_assumptions: str
    historical_safe: bool = True
    calculation_status: str = 'UNVERIFIED'
    prior20_session_ends: tuple[str, ...] = ()
    scale_calendar_complete: bool = False

@dataclass(frozen=True)
class OptionQuote:
    contract_id: str
    symbol: str
    option_type: str
    strike: float
    expiry: str
    last_trade_at: str
    exercise: str
    settlement: str
    multiplier: int
    standard_deliverable: bool
    listed_at: str
    observed_at: str
    published_at: str
    first_seen_at: str
    bid: float
    ask: float
    bid_size: int
    ask_size: int
    delta: float
    delta_known_at: str
    delta_method: str
    source: str
    rights: str
    quote_class: str  # TIMESTAMPED_BBO or SYNTHETIC_BBO; SESSION_RECORDED rejected
    synthetic: bool = False

@dataclass(frozen=True)
class RiskState:
    research_equity: float
    active_positions: int = 0
    entries_today: int = 0
    realized_pnl_today: float = 0.0

@dataclass
class Decision:
    arm: str
    status: str
    reason: str
    decision_at: str
    direction: int = 0
    features: dict = field(default_factory=dict)
    evidence_hash: str = ''
    gamma: dict = field(default_factory=dict)


def session_reject(s: Session, at: str, entry: bool = True) -> Optional[str]:
    t, op, cl = stamp(at), stamp(s.open_at), stamp(s.close_at)
    if not s.calendar_version or not s.calendar_source or stamp(s.calendar_known_at) > t:
        return 'CALENDAR_UNVERIFIED'
    if s.symbol != 'SPY' or not s.standard_full_session or (cl - op).total_seconds() != 23400:
        return 'UNSUPPORTED_SESSION'
    if s.halted:
        return 'HALTED'
    if (s.event_state != 'VERIFIED_CLEAR' or not s.event_source or
        stamp(s.event_known_at) > t or stamp(s.event_valid_until) <= t):
        return 'EVENT_UNKNOWN_OR_BLACKOUT'
    if s.ex_dividend_before_next_session is not False:
        return 'EX_DIVIDEND_UNKNOWN_OR_IMMINENT'
    if t < op + timedelta(minutes=32) or t >= cl - timedelta(minutes=60):
        if entry:
            return 'OUTSIDE_ENTRY_WINDOW'
    return None


def causal_bars(records: list[Bar], s: Session, at: str, mode: str, cfg=Config()) -> list[Bar]:
    if mode not in ('synthetic', 'market_shadow'):
        raise ValueError('MODE_UNSUPPORTED')
    t, op = stamp(at), stamp(s.open_at)
    by_end = {}
    revision_payloads = {}
    for b in records:
        end = stamp(b.end)
        if b.symbol != s.symbol or stamp(b.start) < op or end > t:
            continue
        pub, seen = stamp(b.published_at), stamp(b.first_seen_at)
        if pub > t or seen > t:
            continue  # Later vintage never rewrites an earlier decision.
        if pub < end or seen < pub or b.revision < 0:
            raise ValueError('BAR_CLOCK_INVALID')
        if not b.source or b.rights not in ('RESEARCH_ALLOWED', 'SYNTHETIC'):
            raise ValueError('BAR_PROVENANCE_INVALID')
        if mode != 'synthetic' and (b.synthetic or b.rights == 'SYNTHETIC'):
            raise ValueError('SYNTHETIC_NOT_MARKET')
        if not finite(b.open, b.high, b.low, b.close, b.volume, b.price_volume):
            raise ValueError('BAR_NONFINITE')
        if (b.low <= 0 or b.low > min(b.open, b.close) or b.high < max(b.open, b.close)
                or b.high < b.low or b.volume <= 0 or b.price_volume <= 0
                or not b.low <= b.price_volume / b.volume <= b.high):
            raise ValueError('BAR_VALUES_INVALID')
        if end - stamp(b.start) != timedelta(minutes=1):
            raise ValueError('BAR_INTERVAL_INVALID')
        key = (end,b.revision)
        payload = asdict(b)
        if key in revision_payloads and revision_payloads[key] != payload:
            raise ValueError('BAR_REVISION_CONFLICT')
        revision_payloads[key] = payload
        old = by_end.get(end)
        if old is None or b.revision > old.revision:
            by_end[end] = b
    latest = (t - timedelta(seconds=cfg.bar_latency_s)).replace(second=0, microsecond=0)
    expected = []
    end = op + timedelta(minutes=1)
    while end <= latest:
        expected.append(end)
        end += timedelta(minutes=1)
    if not expected or any(x not in by_end for x in expected):
        raise ValueError('BAR_GAP_OR_LATE')
    return [by_end[x] for x in expected]


def price_features(bs: list[Bar]) -> dict:
    if len(bs) < 32:
        raise ValueError('BAR_WARMUP')
    closes = [b.close for b in bs]
    rets = [log(b / a) for a, b in zip(closes, closes[1:])]
    ref = rets[-21:-1]
    sigma = sqrt(sum(x*x for x in ref))
    priorq = sum(x*x for x in rets[-25:-5])
    if sigma <= 0 or priorq <= 0:
        raise ValueError('RV_ZERO_OR_UNKNOWN')
    vwap = sum(b.price_volume for b in bs) / sum(b.volume for b in bs)
    prev_vwap = sum(b.price_volume for b in bs[:-1]) / sum(b.volume for b in bs[:-1])
    if not finite(vwap,prev_vwap,sigma,priorq) or min(vwap,prev_vwap)<=0:
        raise ValueError('FEATURE_NONFINITE')
    return {'close': closes[-1], 'previous_close': closes[-2], 'vwap': vwap,
            'previous_vwap': prev_vwap, 'sigma20': sigma,
            'z': log(closes[-1]/vwap)/sigma,
            'previous_z': log(closes[-2]/prev_vwap)/sigma,
            'rv_ratio_5_vs_prior20': sum(x*x for x in rets[-5:])/(priorq/4),
            'or_high': max(b.high for b in bs[:30]),
            'or_low': min(b.low for b in bs[:30]), 'bar_end': bs[-1].end,
            'bar_count': len(bs)}


def gamma_features(g: Optional[GammaInput], s: Session, at: str, spot: float,
                   mode: str, cfg=Config()) -> tuple[Optional[dict], Optional[str]]:
    if g is None:
        return None, 'MODELED_INVENTORY_MISSING'
    if g.calculation_status != 'COMPUTED':
        return None, 'GAMMA_NOT_VERIFIED_COMPUTED'
    t, obs, pub, seen = stamp(at), stamp(g.observed_at), stamp(g.published_at), stamp(g.first_seen_at)
    if not finite(g.spot_reference) or g.spot_reference <= 0 or abs(spot/g.spot_reference-1) > .001:
        return None, 'GAMMA_SPOT_REFERENCE_STALE'
    if g.symbol != s.symbol or g.scope != 'SPY_STANDARD_OPTIONS_0_7_CALENDAR_DTE' or not g.complete_scope:
        return None, 'GAMMA_SCOPE_UNKNOWN'
    if not obs <= pub <= seen <= t or (t-obs).total_seconds() > cfg.gamma_max_age_s or obs < stamp(s.open_at):
        return None, 'GAMMA_STALE_OR_FUTURE'
    if (g.sign_method not in ('EXPLICIT_INVENTORY_SCENARIOS', 'CAPACITY_RECONSTRUCTION_MODEL')
        or not g.model_version or not g.inventory_assumptions or not g.surface_method):
        return None, 'DEALER_SIGN_UNIDENTIFIED'
    if not g.historical_safe:
        return None, 'CURRENT_REGIME_NOT_HISTORICAL_PIT'
    if mode != 'synthetic' and (g.synthetic or g.rights == 'SYNTHETIC'):
        return None, 'SYNTHETIC_NOT_MARKET'
    if not g.source or len(g.source_payload_sha256) != 64 or any(c not in '0123456789abcdef' for c in g.source_payload_sha256) or g.rights not in ('RESEARCH_ALLOWED', 'SYNTHETIC'):
        return None, 'GAMMA_PROVENANCE_INVALID'
    if (len(g.prior20_dollar_volume) != 20 or not finite(*g.prior20_dollar_volume)
        or min(g.prior20_dollar_volume) <= 0 or stamp(g.scale_known_at) > t
        or stamp(g.scale_last_session_end) >= stamp(s.open_at) or not g.scale_source):
        return None, 'GAMMA_SCALE_UNAVAILABLE'
    ends = [stamp(x) for x in g.prior20_session_ends]
    if (not g.scale_calendar_complete or len(ends) != 20 or len(set(ends)) != 20
        or ends != sorted(ends) or ends[-1] != stamp(g.scale_last_session_end)
        or any(x >= stamp(s.open_at) for x in ends)):
        return None, 'GAMMA_SCALE_CALENDAR_INVALID'
    if not g.rows or len({r.contract_id for r in g.rows}) != len(g.rows):
        return None, 'GAMMA_ROWS_MISSING_OR_DUPLICATE'
    bins = {}
    for r in sorted(g.rows,key=lambda r:r.contract_id):
        dte = (stamp(r.expiry).date() - t.date()).days
        if (not finite(r.strike, r.long_gamma, r.open_interest, r.modeled_dealer_contracts_low,
                       r.modeled_dealer_contracts_high) or r.strike <= 0 or r.long_gamma < 0
            or r.open_interest < 0 or r.multiplier != 100 or r.option_type not in ('call', 'put')
            or not 0 <= dte <= 7 or stamp(r.expiry) <= obs
            or not -r.open_interest <= r.modeled_dealer_contracts_low <= r.modeled_dealer_contracts_high <= r.open_interest):
            return None, 'GAMMA_ROW_INVALID'
        scale = .01*g.spot_reference*g.spot_reference*r.multiplier*r.long_gamma
        low, high = bins.setdefault(r.strike, [0., 0.])
        bins[r.strike] = [low + scale*r.modeled_dealer_contracts_low,
                          high + scale*r.modeled_dealer_contracts_high]
    low, high = sum(x[0] for x in bins.values()), sum(x[1] for x in bins.values())
    if not finite(low,high):
        return None, 'GAMMA_AGGREGATE_NONFINITE'
    denom = median(g.prior20_dollar_volume)
    if not finite(denom) or denom <= 0 or not finite(low/denom,high/denom):
        return None, 'GAMMA_NORMALIZATION_NONFINITE'
    regime = 'POSITIVE' if low/denom >= cfg.gamma_floor else 'NEGATIVE' if high/denom <= -cfg.gamma_floor else 'NEUTRAL_OR_AMBIGUOUS'
    gross = sum(abs((v[0]+v[1])/2) for v in bins.values())
    if not finite(gross):
        return None, 'GAMMA_AGGREGATE_NONFINITE'
    walls = [{'strike': k, 'g_low': v[0], 'g_high': v[1],
              'modeled_abs_fraction': abs((v[0]+v[1])/2)/gross if gross else 0}
             for k,v in sorted(bins.items())]
    return {'g_low_usd_per_1pct': low, 'g_high_usd_per_1pct': high,
            'normalized_low': low/denom, 'normalized_high': high/denom,
            'regime': regime, 'walls': walls, 'model_version': g.model_version,
            'sign_method': g.sign_method, 'synthetic': g.synthetic,
            'input_hash': digest(dict(asdict(g), rows=sorted([asdict(r) for r in g.rows],key=lambda r:r['contract_id']))), 'meaning': 'MODELED_SENSITIVITY_NOT_ACTUAL_FLOW'}, None


def decide(arm: str, records: list[Bar], s: Session, at: str,
           g: Optional[GammaInput] = None, mode='market_shadow', cfg=Config()) -> Decision:
    arms = {'price_mr', 'price_bo', 'gamma_mr', 'gamma_mr_no_wall', 'gamma_bo'}
    if arm not in arms:
        raise ValueError('ARM_UNSUPPORTED')
    d = Decision(arm, 'NO_TRADE', '', at)
    if stamp(at).second != cfg.bar_latency_s or stamp(at).microsecond != 0:
        d.reason = 'OFF_DECISION_GRID'
        return d
    bad = session_reject(s, at)
    if bad:
        d.reason = bad
        return d
    try:
        bs = causal_bars(records, s, at, mode, cfg)
        f = price_features(bs)
    except ValueError as e:
        d.reason = str(e)
        return d
    d.features = f
    d.evidence_hash = digest({'bars': [asdict(b) for b in bs], 'session': asdict(s), 'config': asdict(cfg)})
    if arm.startswith('gamma'):
        gf, bad = gamma_features(g, s, at, f['close'], mode, cfg)
        if bad:
            d.status, d.reason = 'NO_SIGNAL', bad
            return d
        d.gamma = gf
    mr = 'mr' in arm
    pz, z = f['previous_z'], f['z']
    if mr:
        direction = (1 if pz <= -cfg.mr_z and f['close'] > f['previous_close'] and z < 0 and abs(z) < abs(pz)
                     else -1 if pz >= cfg.mr_z and f['close'] < f['previous_close'] and z > 0 and abs(z) < abs(pz) else 0)
        if not direction or f['rv_ratio_5_vs_prior20'] > cfg.mr_max_rv_ratio:
            d.reason = 'PRICE_MR_NOT_CONFIRMED'
            return d
    else:
        direction = (1 if f['previous_close'] > f['or_high'] and f['close'] > f['previous_close'] and f['close'] > f['vwap']
                     else -1 if f['previous_close'] < f['or_low'] and f['close'] < f['previous_close'] and f['close'] < f['vwap'] else 0)
        if not direction or f['rv_ratio_5_vs_prior20'] < cfg.bo_min_rv_ratio:
            d.reason = 'PRICE_BO_NOT_CONFIRMED'
            return d
    if arm.startswith('gamma'):
        if d.gamma['regime'] != ('POSITIVE' if mr else 'NEGATIVE'):
            d.reason = 'MODELED_GAMMA_REGIME_MISMATCH'
            return d
        if arm == 'gamma_mr':
            tol = cfg.wall_tolerance_sigma * f['sigma20'] * f['previous_close']
            matches = [w for w in d.gamma['walls'] if w['g_low'] > 0
                       and w['modeled_abs_fraction'] >= cfg.wall_min_fraction
                       and abs(w['strike']-f['previous_close']) <= tol
                       and direction*(f['previous_vwap']-w['strike']) > 0]
            if not matches:
                d.reason = 'MODELED_WALL_NOT_CONFIRMED'
                return d
            d.gamma['selected_wall'] = min(matches, key=lambda w:(abs(w['strike']-f['previous_close']),w['strike']))
    d.direction, d.status, d.reason = direction, 'RESEARCH_CANDIDATE', 'RULES_CONFIRMED_NO_ORDER'
    d.evidence_hash = digest({'base': d.evidence_hash, 'gamma': d.gamma, 'arm': arm})
    return d


def quote_reject(q: OptionQuote, at: str, mode: str, cfg=Config(), entry=True) -> Optional[str]:
    t, obs, pub, seen = stamp(at), stamp(q.observed_at), stamp(q.published_at), stamp(q.first_seen_at)
    if not obs <= pub <= seen <= t or (t-obs).total_seconds() > cfg.quote_max_age_s:
        return 'QUOTE_STALE_OR_FUTURE'
    if q.quote_class not in ('TIMESTAMPED_BBO', 'SYNTHETIC_BBO'):
        return 'SESSION_ANALYTICS_NOT_EXECUTION_QUOTE'
    if mode != 'synthetic' and (q.synthetic or q.quote_class == 'SYNTHETIC_BBO' or q.rights == 'SYNTHETIC'):
        return 'SYNTHETIC_NOT_MARKET'
    if not q.source or q.rights not in ('RESEARCH_ALLOWED', 'SYNTHETIC'):
        return 'QUOTE_PROVENANCE_INVALID'
    if (not finite(q.bid,q.ask,q.bid_size,q.ask_size,q.strike) or q.bid < 0 or q.ask <= 0
        or q.bid > q.ask or min(q.bid_size,q.ask_size) <= 0):
        return 'QUOTE_INVALID'
    if q.symbol != 'SPY' or q.option_type not in ('call','put') or q.multiplier != 100 or not q.standard_deliverable:
        return 'CONTRACT_UNSUPPORTED'
    if q.exercise != 'AMERICAN' or q.settlement != 'PHYSICAL' or stamp(q.listed_at) > t or stamp(q.last_trade_at) <= t:
        return 'CONTRACT_METADATA_INVALID'
    if entry and (not q.delta_method or stamp(q.delta_known_at) > t or (t-stamp(q.delta_known_at)).total_seconds() > cfg.quote_max_age_s):
        return 'DELTA_STALE_OR_UNVERIFIED'
    if entry and (not finite(q.delta) or not (0 <= q.delta <= 1 if q.option_type == 'call' else -1 <= q.delta <= 0)):
        return 'DELTA_SIGN_INVALID'
    if not entry and q.bid == 0:
        return 'NO_POSITIVE_EXIT_BID'
    # Exits do not refuse a wide market: report and cross observed bid conservatively.
    if entry and (q.ask-q.bid > cfg.max_spread_usd or (q.ask-q.bid)/((q.ask+q.bid)/2) > cfg.max_spread_fraction):
        return 'QUOTE_TOO_WIDE'
    return None


def latest_causal_quotes(chain: list[OptionQuote], at: str) -> tuple[list[OptionQuote], list]:
    t=stamp(at); groups={}; selected=[]; rejects=[]
    for q in chain:
        if stamp(q.first_seen_at)>t or stamp(q.published_at)>t: continue
        groups.setdefault(q.contract_id,[]).append(q)
    for cid,qs in sorted(groups.items()):
        identities={tuple(getattr(q,k) for k in CONTRACT_IDENTITY) for q in qs}
        if len(identities)>1:
            rejects.append([cid,'CONTRACT_IDENTITY_CONFLICT']);continue
        keys=[(stamp(q.observed_at),stamp(q.published_at),stamp(q.first_seen_at)) for q in qs]
        latest=max(keys);latest_qs=[q for q,k in zip(qs,keys) if k==latest]
        if any(asdict(q) != asdict(latest_qs[0]) for q in latest_qs[1:]):
            rejects.append([cid,'QUOTE_VINTAGE_CONFLICT']);continue
        selected.append(latest_qs[0])
    return selected,rejects


def plan_option(d: Decision, chain: list[OptionQuote], risk: RiskState, mode='market_shadow', cfg=Config()) -> dict:
    out = {'status':'NO_TRADE', 'reason':'NO_CANDIDATE', 'orders_enabled':False}
    if d.status != 'RESEARCH_CANDIDATE':
        return out
    if (not finite(risk.research_equity, risk.realized_pnl_today) or risk.research_equity <= 0
        or risk.active_positions or risk.entries_today >= cfg.max_entries
        or risk.realized_pnl_today <= -cfg.daily_loss_fraction*risk.research_equity):
        return dict(out,reason='RISK_LIMIT')
    eligible=[]
    chain,rejects=latest_causal_quotes(chain,d.decision_at)
    for q in chain:
        bad = quote_reject(q,d.decision_at,mode,cfg)
        dte = (stamp(q.expiry).date()-stamp(d.decision_at).date()).days
        if bad:
            rejects.append([q.contract_id,bad]); continue
        if q.option_type != ('call' if d.direction == 1 else 'put') or not 7 <= dte <= 14 or not .4 <= abs(q.delta) <= .6:
            rejects.append([q.contract_id,'DTE_TYPE_OR_DELTA']); continue
        eligible.append((abs(dte-10),q.expiry,abs(abs(q.delta)-.5),q.ask-q.bid,q.strike,q.contract_id,q))
    if not eligible:
        return dict(out,reason='NO_ELIGIBLE_CONTRACT', rejects=rejects)
    q = min(eligible,key=lambda z:z[:-1])[-1]
    return {'status':'RESEARCH_PLAN', 'orders_enabled':False, 'decision':asdict(d),
            'selected_quote':asdict(q), 'risk':asdict(risk), 'rejects':rejects,
            'structure':'LONG_SINGLE_CALL' if d.direction==1 else 'LONG_SINGLE_PUT',
            'contract_locked_before_execution':True}


def simulate_entry(plan: dict, first_quote: OptionQuote, s: Session, at: str,
                   mode='market_shadow', cfg=Config(), gamma_exit_enabled=False) -> dict:
    """Caller must supply the FIRST observed postdecision quote for locked contract.
    There is no fill search or replacement contract. Quote crossing is a hypothetical fill.
    """
    out = {'status':'NO_FILL', 'reason':'INVALID_PLAN', 'orders_enabled':False}
    if plan.get('status') != 'RESEARCH_PLAN': return out
    d, q0, risk = plan['decision'], plan['selected_quote'], plan['risk']
    if any(getattr(first_quote,k) != q0[k] for k in CONTRACT_IDENTITY):
        return dict(out,reason='LOCKED_CONTRACT_MISMATCH')
    if stamp(first_quote.observed_at) <= stamp(d['decision_at']) or stamp(at)-stamp(d['decision_at']) > timedelta(seconds=5):
        return dict(out,reason='NO_CAUSAL_NEXT_QUOTE_WITHIN_5S')
    bad = session_reject(s,at) or quote_reject(first_quote,at,mode,cfg)
    if bad: return dict(out,reason=bad)
    if abs(first_quote.ask/q0['ask']-1)>cfg.max_entry_price_drift:
        return dict(out,reason='ENTRY_PRICE_DRIFT')
    unit_debit = first_quote.ask + cfg.slippage_per_share_side
    loss_bound = unit_debit*100 + 2*cfg.fee_per_contract_side
    remaining_daily=max(0.,cfg.daily_loss_fraction*risk['research_equity']+min(0.,risk['realized_pnl_today']))
    quantity = min(cfg.max_contracts, floor(risk['research_equity']*cfg.risk_fraction/loss_bound),
                   floor(remaining_daily/loss_bound),
                   floor(min(first_quote.ask_size,first_quote.bid_size)*cfg.size_fraction))
    if quantity < 1: return dict(out,reason='SIZE_BELOW_ONE')
    f = d['features']; direction=d['direction']; mr='mr' in d['arm']
    stop = f['close']*(1-direction*f['sigma20'])
    target = f['vwap'] if mr else f['close']*(1+direction*1.5*f['sigma20'])
    deadline=min(stamp(at)+timedelta(minutes=45 if mr else 60),stamp(s.close_at)-timedelta(minutes=30))
    return {'status':'SIMULATED_OPEN', 'orders_enabled':False, 'decision':d,
            'contract':asdict(first_quote), 'entry_at':at, 'entry_price':unit_debit,
            'quantity':quantity,'entry_debit_usd':unit_debit*100*quantity,
            'entry_fee_usd':cfg.fee_per_contract_side*quantity,
            'max_loss_budget_usd':loss_bound*quantity,'stop_underlying':stop,
            'target_underlying':target,'deadline':deadline.isoformat(),
            'fill_assumption':'ASK_PLUS_SLIPPAGE_NOT_ACTUAL_FILL',
            'exit_policy':'GAMMA_EXIT_CHALLENGER' if gamma_exit_enabled else 'MATCHED_PRICE_ONLY'}


def exit_step(position: dict, at: str, underlying: Optional[float], underlying_known_at: Optional[str],
              quote: Optional[OptionQuote], mandatory_exit: bool=False,
              gamma_regime: Optional[str]=None, mode='market_shadow', cfg=Config()) -> dict:
    if position.get('status') not in ('SIMULATED_OPEN','EXIT_PENDING'):
        raise ValueError('POSITION_NOT_OPEN')
    if stamp(at) <= stamp(position.get('last_observed_at',position['entry_at'])):
        raise ValueError('EXIT_EVENT_NOT_MONOTONE')
    d=position['decision']; direction=d['direction']; reason=position.get('exit_trigger')
    quote_identity_ok = quote is not None and all(getattr(quote,k)==position['contract'][k] for k in CONTRACT_IDENTITY)
    uvalid = (underlying is not None and finite(underlying) and underlying>0 and underlying_known_at
              and timedelta(0)<=stamp(at)-stamp(underlying_known_at)<=timedelta(seconds=2))
    if not reason:
        if mandatory_exit: reason='EVENT_HALT_OR_MANUAL_RESEARCH_ABORT'
        elif stamp(at)>=stamp(position['deadline']): reason='MAX_HOLD_OR_SESSION_CUTOFF'
        elif not uvalid: reason='UNDERLYING_DATA_LOST'
        elif position.get('exit_policy') == 'GAMMA_EXIT_CHALLENGER' and d['arm'].startswith('gamma') and gamma_regime != ('POSITIVE' if 'mr' in d['arm'] else 'NEGATIVE'):
            reason='MODELED_GAMMA_LOST_OR_FLIPPED'
        elif direction*(underlying-position['stop_underlying'])<=0: reason='UNDERLYING_STOP'
        elif direction*(underlying-position['target_underlying'])>=0: reason='UNDERLYING_TARGET'
        elif quote_identity_ok and quote_reject(quote,at,mode,cfg,False) in (None,'NO_POSITIVE_EXIT_BID') and quote.bid <= .5*position['entry_price']:
            reason='PREMIUM_DRAWDOWN_50PCT'
    if not reason: return dict(position, last_observed_at=at)
    bad = ('EXIT_QUOTE_MISSING' if quote is None else 'LOCKED_CONTRACT_MISMATCH'
           if any(getattr(quote,k) != position['contract'][k] for k in CONTRACT_IDENTITY) else quote_reject(quote,at,mode,cfg,False))
    if bad:
        return dict(position,status='EXIT_PENDING',exit_trigger=reason,exit_blocker=bad,last_observed_at=at)
    if quote.bid_size < position['quantity']:
        return dict(position,status='EXIT_PENDING',exit_trigger=reason,exit_blocker='EXIT_SIZE_INSUFFICIENT',last_observed_at=at)
    px=max(0,quote.bid-cfg.slippage_per_share_side)
    qty=position['quantity']; exit_fee=qty*cfg.fee_per_contract_side
    pnl=(px-position['entry_price'])*100*qty-position['entry_fee_usd']-exit_fee
    return dict(position,status='SIMULATED_CLOSED',exit_trigger=reason,exit_at=at,exit_price=px,
                exit_fee_usd=exit_fee,pnl_usd=pnl,
                fill_assumption='ASK_PLUS_SLIPPAGE_TO_BID_MINUS_SLIPPAGE_NOT_ACTUAL_FILLS')


def censor_unclosed(position:dict) -> dict:
    if position['status'] not in ('SIMULATED_OPEN','EXIT_PENDING'): return position
    return dict(position,status='CENSORED_EXIT_UNPRICED',pnl_usd=None,
                worst_case_premium_loss_usd=-position['max_loss_budget_usd'])


def underlying_benchmark(direction:int, entry:float, exit:float, roundtrip_bps:float=2.) -> dict:
    if direction not in (-1,1) or not finite(entry,exit,roundtrip_bps) or min(entry,exit)<=0 or roundtrip_bps<0:
        raise ValueError('BENCHMARK_INPUT_INVALID')
    return {'gross_log_return':direction*log(exit/entry),
            'after_assumed_cost_log_return':direction*log(exit/entry)-roundtrip_bps/10000,
            'cost_assumption_bps':roundtrip_bps,'meaning':'DIRECTION_DIAGNOSTIC_NOT_OPTION_PNL'}


def expanding_walk_forward(rows:list[dict], train_sessions:int=252, test_sessions:int=63) -> list[dict]:
    """Session-grouped expanding folds. Labels must mature AND first be available before fit.
    Each row requires session, decision_at, label_end, label_available_at. No random split.
    """
    if train_sessions<1 or test_sessions<1: raise ValueError('FOLD_SIZE_INVALID')
    if len({r['id'] for r in rows}) != len(rows): raise ValueError('DUPLICATE_LABEL_ID')
    for r in rows:
        if not stamp(r['decision_at']) <= stamp(r['label_end']) <= stamp(r['label_available_at']):
            raise ValueError('LABEL_CLOCK_INVALID')
    sessions=sorted({r['session'] for r in rows}); folds=[]
    for i in range(train_sessions,len(sessions),test_sessions):
        test_dates=sessions[i:i+test_sessions]
        test=[r for r in rows if r['session'] in test_dates]
        fit=min(stamp(r['decision_at']) for r in test)
        train=[r for r in rows if r['session'] in sessions[:i]
               and stamp(r['decision_at'])<fit and stamp(r['label_end'])<fit
               and stamp(r['label_available_at'])<fit]
        folds.append({'fit_at':fit.isoformat(),'train_ids':[r['id'] for r in train],
                      'test_ids':[r['id'] for r in test], 'test_sessions':test_dates})
    return folds


def paired_increment(rows:list[dict]) -> dict:
    """Each row is one price-trigger opportunity, outcome fixed before applying gamma gate.
    Rejected gates contribute zero. Missing executable outcomes remain censored, not zero.
    This is an opportunity-normalized diagnostic, not a feasible overlapping portfolio.
    """
    valid=[r for r in rows if r['after_cost_pnl_usd'] is not None and r['gamma_available']]
    diffs=[(r['after_cost_pnl_usd'] if r['gamma_accept'] else 0)-r['after_cost_pnl_usd'] for r in valid]
    return {'opportunities':len(rows),'common_qualified':len(valid),
            'censored_or_gamma_missing':len(rows)-len(valid),
            'mean_increment_usd_per_opportunity':sum(diffs)/len(diffs) if diffs else None,
            'meaning':'MATCHED_OUTCOMES_WITH_ZERO_FOR_GATE_ABSTENTION_NOT_PAIRED_TRADE_RETURNS'}


def provider_field_admission(field: str, payload: dict, intended_use: str, requested_horizon_days: Optional[int]=None) -> dict:
    """No fetching or inferred entitlements. Guard for Optionomics' documented semantics.
    This is a refusal adapter, not a transformation of analytics into executable evidence.
    """
    if field == 'quote.regime':
        return {'status':'REJECT','reason':'LIVE_SESSION_REGIME_NOT_HISTORICAL_PIT'}
    if field == 'total_gex':
        if payload.get('total_gex') == 0 and payload.get('exposure_calculation_status') != 'VERIFIED_COMPUTED':
            return {'status':'REJECT','reason':'ZERO_MAY_MEAN_EXPOSURES_NOT_COMPUTED'}
        return {'status':'REJECT','reason':'SIGNED_INVENTORY_METHOD_AND_CAUSAL_PROVENANCE_REQUIRED'}
    if field == 'expected_move_pct':
        if requested_horizon_days is None or payload.get('front_expiry_dte') != requested_horizon_days:
            return {'status':'REJECT','reason':'FRONT_EXPIRY_HORIZON_MISMATCH_OR_UNKNOWN'}
        return {'status':'REJECT','reason':'EXPECTED_MOVE_NOT_DEALER_GAMMA_SIGNAL'}
    if intended_use == 'EXECUTION':
        return {'status':'REJECT','reason':'SESSION_ANALYTICS_NOT_EXECUTION_QUOTE'}
    return {'status':'REJECT','reason':'NO_QUALIFIED_FIELD_MAPPING'}


def vanna_charm_decision() -> dict:
    return {'status':'NO_SIGNAL','reason':'DEFERRED_SIGNED_INVENTORY_SURFACE_DYNAMICS_AND_FLOW_IDENTIFICATION_MISSING',
            'orders_enabled':False,'prototype_version':VERSION}
