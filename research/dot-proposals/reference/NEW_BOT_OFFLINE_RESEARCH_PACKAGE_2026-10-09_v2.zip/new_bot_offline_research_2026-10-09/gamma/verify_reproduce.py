#!/usr/bin/env python3
"""Run from any directory. Standard library only; all paths relative to this package.
No network, external application, credential, order or production dependency.
"""
import hashlib
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'verification'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def run(args,name):
    p=subprocess.run([sys.executable]+args,cwd=ROOT,text=True,capture_output=True)
    (OUT/(name+'.stdout.txt')).write_text(p.stdout)
    (OUT/(name+'.stderr.txt')).write_text(p.stderr)
    return {'command':['python']+args,'cwd':'.','exit_code':p.returncode,
            'stdout_path':'verification/'+name+'.stdout.txt',
            'stderr_path':'verification/'+name+'.stderr.txt'}
def main():
    OUT.mkdir(exist_ok=True)
    commands=[run(['-m','unittest','-v','test_gamma_research.py'],'main_tests'),
              run(['-m','unittest','discover','-s','independent_review','-v'],'independent_tests'),
              run(['run_research.py','--out','verification/reproduced_synthetic_results.json'],'demo'),
              run(['run_research.py','--input','synthetic_input_v1.json','--out','verification/reproduced_synthetic_decision.json'],'json_input')]
    matches={name:sha(ROOT/name)==sha(OUT/repro) for name,repro in [
        ('synthetic_results_v1.json','reproduced_synthetic_results.json'),
        ('synthetic_decision_v1.json','reproduced_synthetic_decision.json')]}
    sources=['gamma_research.py','synthetic_fixture.py','run_research.py','test_gamma_research.py',
             'independent_review/test_independent_gamma.py','verify_reproduce.py',
             'synthetic_input_v1.json','synthetic_results_v1.json','synthetic_decision_v1.json',
             'PLAYBOOK_GAMMA_RESEARCH_V1.md','SOURCE_REGISTER_V1.json']
    receipt={'version':'GAMMA_RESEARCH_V1','generated_at':datetime.now(timezone.utc).isoformat(),
      'python_version':platform.python_version(),'platform':platform.platform(),'commands':commands,
      'deterministic_output_matches':matches,'source_sha256':{name:sha(ROOT/name) for name in sources},
      'passed':all(c['exit_code']==0 for c in commands) and all(matches.values()),
      'status':'OFFLINE_SYNTHETIC_ONLY','market_observations':0,'observed_fills':0,
      'empirical_performance_evidence':False,'orders_enabled':False}
    (OUT/'FINAL_REPRODUCTION_RECEIPT_V1.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'passed':receipt['passed'],'receipt':'verification/FINAL_REPRODUCTION_RECEIPT_V1.json'},indent=2))
    return 0 if receipt['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
