"""Independent reviewer regressions; run against a frozen source directory argument."""
import unittest,sys,copy,math,json,hashlib,random
from pathlib import Path
SOURCE=Path(sys.argv.pop(1)).resolve(); sys.path.insert(0,str(SOURCE))
from harvester import assess,management,capital_ledger
from make_fixtures import fixture
class ReviewRegressions(unittest.TestCase):
 def result(self, mutate=lambda f:None):
  f=fixture();mutate(f);return assess(f)
 def test_impossible_iv_availability(self):
  r=self.result(lambda f:[x.update(available_at='2000-01-01T00:00:00Z') for x in f['volatility']['history']]);self.assertEqual(r['decision'],'WAIT')
 def test_spot_security_bound(self):self.assertEqual(self.result(lambda f:f['underlying_quote'].update(security_id='OTHER'))['decision'],'WAIT')
 def test_stock_bars_security_bound(self):self.assertEqual(self.result(lambda f:f['bars'][1].update(security_id='OTHER'))['decision'],'WAIT')
 def test_market_bars_security_bound(self):self.assertEqual(self.result(lambda f:f['market_bars'][1].update(security_id='OTHER'))['decision'],'WAIT')
 def test_future_bar_payload_cannot_change_old_decision(self):
  a=self.result();f=fixture();b=copy.deepcopy(f['bars'][-1]);b.update(available_at='2026-10-09T14:01:00Z',security_id='OTHER',open=-1,high=-1,low=-2,close=-1,revision_id='future');f['bars'].append(b);r=assess(f)
  self.assertEqual((a['decision'],a['features']),(r['decision'],r.get('features')))
 def test_future_iv_revision_cannot_change_old_decision(self):
  a=self.result();f=fixture();v=copy.deepcopy(f['volatility']['history'][-1]);v.update(available_at='2026-10-09T14:01:00Z',security_id='OTHER',value=8,revision_id='future');f['volatility']['history'].append(v);r=assess(f);self.assertEqual((a['decision'],a['iv_percentile']),(r['decision'],r['iv_percentile']))
 def test_equal_instant_conflict_is_order_invariant(self):
  f=fixture();b=copy.deepcopy(f['bars'][-1]);b.update(available_at='2026-10-08T16:01:00-04:00',close=80.,open=80.,low=79.,high=81.,revision_id='conflict');f['bars'].append(b);a=assess(f);f['bars'].reverse();r=assess(f)
  self.assertEqual(a['decision'],'WAIT');self.assertEqual((a['decision'],a['reason']),(r['decision'],r['reason']))
 def test_impossible_csp_credit_no_crash(self):self.assertEqual(self.result(lambda f:f['chain'][0].update(bid=90.014,ask=90.02))['decision'],'WAIT')
 def test_impossible_both_leg_marks_reject(self):
  f=fixture();f['portfolio']['ownership_approved']=False;f['chain'][0].update(bid=90.014,ask=90.02);f['chain'][1].update(bid=85.01,ask=85.02);self.assertEqual(assess(f)['decision'],'WAIT')
 def test_known_event_preserved_beyond_embargo(self):
  r=self.result(lambda f:f['events']['items'].append({'date':'2026-10-20','kind':'MACRO','available_at':f['decision_at']}));self.assertEqual(r['decision'],'CSP');self.assertTrue(all(a['canonical_receipt']['eventRisk']=='EVENT_IN_WINDOW' for a in r['alternatives'] if 'canonical_receipt' in a))
 def test_indicative_cannot_upgrade_with_executable_flag(self):
  r=self.result(lambda f:[q.update(quote_kind='INDICATIVE',executable=True) for q in f['chain']]);self.assertEqual(r['decision'],'WAIT')
 def test_synthetic_authority_preserved(self):
  r=self.result();self.assertFalse(r['execution_authority']);self.assertEqual(r['evidence'],'SYNTHETIC_INVENTED')
  for a in r['alternatives']:
   self.assertFalse(a['execution_authority']);self.assertEqual(a['evidence'],'SYNTHETIC_INVENTED')
   if 'canonical_receipt' in a:
    self.assertNotIn('EXECUTABLE_BID',json.dumps(a));e=a['canonical_receipt'];self.assertFalse(e['research_context']['execution_authority']);self.assertEqual(e['research_context']['evidence'],'SYNTHETIC_INVENTED');self.assertEqual(e['expectedValueUsd']['state'],'UNKNOWN')
 def test_chain_permutation_preserves_alternatives(self):
  a=self.result();b=self.result(lambda f:f['chain'].reverse());self.assertEqual(a['alternatives'],b['alternatives'])
 def test_management_unknown_flags(self):
  p={'structure':'PUT_CREDIT_SPREAD','short_quantity':2,'long_quantity':2,'original_credit':200.,'opening_fees':2.};o={'assignment_status':'NONE','quote_complete':True,'dte':20,'confirmed_close_debits':0.,'confirmed_close_fees':0.,'residual_liquidation_debit':95.,'residual_close_fees':2.,'mandatory_exit':False,'event_within_2_calendar_days':False,'thesis_broken':False}
  for k in ('mandatory_exit','event_within_2_calendar_days','thesis_broken'):
   c=dict(o);del c[k];self.assertEqual(management(p,c),'UNKNOWN_EXIT_STATE_RETAIN_EXPOSURE')
 def test_management_bad_quantities(self):
  p={'structure':'PUT_CREDIT_SPREAD','short_quantity':2,'long_quantity':2};o={'assignment_status':'NONE'}
  for n in (-1,True,None,'2'):
   c=dict(p);c['long_quantity']=n;self.assertEqual(management(c,o),'UNKNOWN_TOPOLOGY_RECONCILE')
  del p['long_quantity'];self.assertEqual(management(p,o),'UNKNOWN_TOPOLOGY_RECONCILE')
 def test_partial_fill_uses_original_denominator(self):
  p={'structure':'PUT_CREDIT_SPREAD','short_quantity':1,'long_quantity':1,'original_credit':200.,'opening_fees':2.};o={'assignment_status':'NONE','quote_complete':True,'dte':20,'confirmed_close_debits':40.,'confirmed_close_fees':1.,'residual_liquidation_debit':60.,'residual_close_fees':1.,'mandatory_exit':False,'event_within_2_calendar_days':False,'thesis_broken':False};self.assertEqual(management(p,o),'OBSERVE_NO_ROLL')
 def test_same_budget_does_not_equalize_loss(self):
  f=fixture();a,b,w=assess(f)['alternatives'];self.assertEqual(a['gross_assignment_funding'],b['gross_assignment_funding']);self.assertGreater(a['terminal_max_loss_with_cost_scenario'],20*b['terminal_max_loss_with_cost_scenario']);self.assertFalse(a['risk_equivalence_claim']);self.assertFalse(b['risk_equivalence_claim'])
 def test_payoff_maxloss_oracle(self):
  f=fixture();c=f['costs']
  for a in assess(f)['alternatives'][:2]:
   q=a['quantity'];legs=2 if a['long_id'] else 1;strike=90-(85 if legs==2 else 0);gross=150 if legs==1 else 100
   expected=q*(strike*100-gross+legs*(c['opening_per_leg']+c['closing_per_leg']+c['extra_slippage_per_leg']));self.assertAlmostEqual(expected,a['terminal_max_loss_with_cost_scenario'])
 def test_200_cash_ledger_oracles(self):
  rng=random.Random(20261009)
  for i in range(200):
   B=rng.uniform(1000,50000);R=rng.uniform(0,B*.9);C=rng.uniform(1,1000);F0=rng.uniform(0,10);F1=rng.uniform(0,20);L=rng.uniform(0,R);days=rng.randrange(1,60);rates={'reserved':rng.uniform(0,.05),'free':rng.uniform(0,.06),'wait':rng.uniform(0,.06)};t=days/365
   a=capital_ledger(B,R,C,F0,F1,L,days,rates);expected=C-F0-F1-L+R*rates['reserved']*t+(B+C-F0-R)*rates['free']*t-B*rates['wait']*t;self.assertAlmostEqual(expected,a['difference_vs_wait'],places=8)
if __name__=='__main__':unittest.main(verbosity=2)
