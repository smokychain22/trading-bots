# Harvester v0.1.1 independent acceptance

PASS for offline structural research only. The exact source and author manifest are identified in FINAL_REVIEW_RECEIPT.json. All24 author-manifest entries match their recorded SHA-256 and byte counts.

The initial68-test suite passed despite7 independently reproduced defects. A92-test revision corrected those but left2 residual cases. Final v0.1.1 passes94 author tests,19 separate reviewer tests (including200 seeded cash-ledger oracles), and the author payoff grid of310 invented rows/620 checks. All9 findings are corrected. Frozen initial, intermediate and final sources preserve the correction trail.

The corrected tests cover measurement/publication causality, security identity, future-revision invisibility, normalized timestamp ties, quote authority, impossible contract marks and sizing denominators, honest event context, unknown management/inventory, partial-close denominator, common-budget versus tail-risk separation, payoff arithmetic and cash interest counted once.

The frozen canonical function byte-matches archived source and Git blob identity. Static inspection found no imported module, network, filesystem or top-level operational behavior in that dependency. The bridge only invokes the arithmetic function on JSON. No repository modification, provider access, account, broker, paid data, publication or activation was performed by this review.

The base invented comparison independently verifies USD17,702.80 CSP versus USD805.60 intact spread terminal loss under the stated cost scenario; each has USD18,000 gross short assignment funding and USD20,000 initial cash. Limited zero-liability advantages over WAIT are USD246.27845 and USD192.09115. They are scenarios, not expected profits.

Remaining limits: zero qualified historical option episodes; zero qualified live capsules; no calibrated fills or complete assignment/stock ledger; producer attestation remains unauthenticated by this offline validator; no empirical or OOS edge, tail adequacy, capacity or production readiness. Per-leg strike-price limits are conservative supported-input restrictions, not asserted universal pricing theorems. Passing this review authorizes no publication or execution.

Reproducibility: use final/source for the frozen reviewed implementation, final/reproduce.log for reproduced author workflow, review_regressions.py for independent tests, and final/independent_regressions.log for the passing result. Initial and intermediate failures remain in INITIAL_REVIEW.md and their corresponding snapshots/probes.

## Prose-only amendment

A later exact diff clarifies that65 completed daily sessions supply the EWMA input and252 sessions/year is the volatility annualization convention, not a forecast horizon or history length. Only the strategy-contract prose and corresponding manifest hash changed; all23 other author-manifest files remain byte-identical. The updated final receipt binds the current document and manifest. No test was rerun and no new research evidence was added. The frozen final/source_sha256.txt remains the original tested-snapshot record; the current contract hash is in FINAL_REVIEW_RECEIPT.json.
