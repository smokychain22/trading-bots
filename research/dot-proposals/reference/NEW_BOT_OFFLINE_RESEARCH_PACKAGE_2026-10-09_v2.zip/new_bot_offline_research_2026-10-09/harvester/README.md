# Harvester future-bot incubator

A separate offline research prototype for regime-adaptive CSP/spread/WAIT comparisons on oversold, stabilizing liquid common stocks. All settings and every supplied fixture are hypotheses or invented values. No validated return claim, broker access, order authority, production change or THETA registration.

Read STRATEGY_CONTRACT_v0.1.1.md and SHADOW_READINESS_v0.1.1.md first. The code handles entry observations and symbolic lifecycle intents; a full executable-quote historical replay and assignment ledger are still missing.

## Reproduce

Requirements: Python 3.12+ and Node 24+ already installed. No package download or network access required. From this folder:

    python reproduce.py

For one supplied capsule:

    python harvester.py fixtures/base_synthetic.json --output evidence/example.json

The reproduction checks the exact frozen canonical arithmetic dependency, generates three invented capsules, executes the tests, runs CSP/spread/WAIT cases and checks a bounded zero-rate payoff grid. It writes exact receipts and hashes under evidence/. Tests establish implemented logic and accounting identities only. They are not market observations, fill evidence or proof of profitability.

## Files

- harvester.py: independent offline gate, matching, arithmetic adapter, scalar-cap comparison, cash scenarios and management intents.
- vendor/canonical-strategy-economics.ts: unchanged existing pure arithmetic, not an integration. Owner-authorized frozen reference only; approved later integration imports the canonical module, never this vendored snapshot.
- canonical_bridge.mjs: file-local arithmetic invocation only.
- test_harvester.py: deterministic synthetic and malformed-input regressions.
- make_fixtures.py: explicit invented fixture producer; the weekday calendar is not a real exchange calendar.
- reproduce.py: relative-path reproducibility runner.
- STRATEGY_CONTRACT_v0.1.1.md: complete hypothesis, matching, sizing, lifecycle, OOS and veto rules.
- SHADOW_READINESS_v0.1.1.md: truthful missing-data and observation gates.
- evidence/: current results, source identity, input qualification and prior defective run history. No account data.

The controlling code is the reviewed version identified by the final manifest. Archived pre-review code and logs exist only to preserve the correction trail and must never be imported or used as current evidence.

No UI changed. Reticle was not applicable to this file-only CLI prototype.
