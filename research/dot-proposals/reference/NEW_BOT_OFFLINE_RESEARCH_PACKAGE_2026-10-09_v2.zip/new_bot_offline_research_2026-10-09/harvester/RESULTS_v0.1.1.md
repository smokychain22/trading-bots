# Harvester v0.1.1: tangible result and next decision

## Result

The offline prototype runs. In invented fixtures it selects CSP in a calm market, a put credit spread in caution, and WAIT when event coverage is missing. The current suite passes 94 tests; an independent payoff grid checks 310 invented cases and 620 identities/bounds. These are correctness checks, not successful trades or evidence of profit. No qualified historical option episode or live capsule has been admitted.

The genuinely new hypothesis is causal stabilization plus regime-dependent structure choice. Existing Q cost/delta selection, cash-yield accounting and assignment/partial-fill safety concepts are reused and identified as prior work. The canonical economics function is called directly from a frozen byte-identical dependency, without creating a new THETA registry schema or execution engine.

## What the invented comparison exposes

Both alternatives start with $20,000 and choose two contracts under the same externally supplied research caps:

- CSP: $18,000 strike reserve; $17,702.80 zero-spot expiration loss including the stated cost scenario.
- Spread: $1,000 full-width research reserve; $805.60 intact expiration loss including that scenario.
- Both: $18,000 gross short-leg assignment funding, separately constrained.

The positive zero-liability wealth advantages over WAIT are about $246.28 and $192.09 under the invented cash-rate/fee assumptions. Those figures are ceilings for that limited scenario, not expected profit or a ranking of investment attractiveness. The same initial cash emphatically does not create the same tail risk. A spread's smaller terminal loss does not remove short-leg funding or failed-close risk.

## Honest boundaries

The code implements causal observations, deterministic matching, arithmetic and sizing comparisons, plus management intentions. It does not implement an executable historical fill replay, full assignment ledger, real portfolio optimizer, data collection or order routing. It does not automatically roll or sell covered calls after assignment. A signal cannot release capital or erase inventory.

The available UCI dataset was inspected: 750 weekly underlying rows, 30 names, 25 dates, median date spacing seven days. It was rejected for this daily point-in-time design. No future option labels were invented, no unrelated weekly result was relabeled a Harvester test, and no profitability statistic was reported.

## First falsification work

1. Source qualification: can a bounded legitimate source provide archived first-known daily bars, event/IV vintages and real synchronized BBO? If not, keep WAIT and observation-blocked status.
2. Gate ablation: compare the fixed eligible CSP baseline with and without stabilization under identical costs, timestamps, contracts and common horizons. Failure to show a meaningful untouched-holdout after-cost benefit rejects the addition.
3. Structure ablation: compare regime choice against always-CSP, always-spread and WAIT under the same initial budget and separate tail/funding caps. Gains achieved only by greater risk or missing loser outcomes reject the claim.
4. Execution/lifecycle stress: failed mandatory closes, partial fills, early assignment and lost protection must retain obligations. A paper profit target without completion evidence cannot count as a win.

The complete decision rules, deterministic ties, no-roll policy, rejection rules, OOS design and promotion vetoes are in STRATEGY_CONTRACT_v0.1.1.md. The smallest prospective observation requirements are in SHADOW_READINESS_v0.1.1.md. No current THETA parameter or position was changed.
