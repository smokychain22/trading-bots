// Exact pure canonical receipt reuse. No registry, adapters, accounts or orders.
import {buildStrategyEconomicsReceipt} from './vendor/canonical-strategy-economics.ts';
let text=''; for await (const chunk of process.stdin) text+=chunk;
process.stdout.write(JSON.stringify(JSON.parse(text).map(buildStrategyEconomicsReceipt)));
