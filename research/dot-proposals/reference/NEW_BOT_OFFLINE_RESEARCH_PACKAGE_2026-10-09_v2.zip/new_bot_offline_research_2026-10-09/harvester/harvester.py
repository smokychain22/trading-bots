"""Harvester 0.1.0. Offline observation/research only; never an execution authority.
All policy constants are unvalidated hypotheses. No network/account dependencies.
"""
from __future__ import annotations
import hashlib, json, math, subprocess
from datetime import datetime, date, timedelta
from pathlib import Path
from statistics import mean
from zoneinfo import ZoneInfo
ROOT = Path(__file__).resolve().parent
VERSION = 'harvester-research-0.1.1'

class Reject(ValueError): pass

def need(ok, reason):
    if not ok: raise Reject(reason)

def finite(v): return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)
def positive(v): return finite(v) and v > 0

def ts(v):
    need(isinstance(v,str), 'TIMESTAMP_MISSING')
    try: t=datetime.fromisoformat(v.replace('Z','+00:00'))
    except ValueError as e: raise Reject('TIMESTAMP_INVALID') from e
    need(t.tzinfo is not None, 'TIMESTAMP_NAIVE')
    return t

def digest(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def fresh(row, at, seconds, prefix):
    known, observed=ts(row['available_at']),ts(row['observed_at'])
    need(observed<=known<=at, prefix+'_FUTURE_OR_BAD_CLOCK')
    need(0 <= (at-observed).total_seconds() <= seconds, prefix+'_STALE')
    need(bool(row.get('source_id')),prefix+'_SOURCE_MISSING')

def causal_bars(rows, expected_sessions, at, symbol, security_id):
    """Latest eligible revision per session, exactly one consistent as-of 65-session window."""
    need(len(expected_sessions)>=65 and expected_sessions==sorted(set(expected_sessions)), 'CALENDAR_INCOMPLETE')
    need(expected_sessions[-1] < at.astimezone(ZoneInfo('America/New_York')).date().isoformat(), 'CURRENT_DAY_BAR_FORBIDDEN')
    selected={}
    seen={}
    for b in rows:
        need(isinstance(b,dict),'BAR_MALFORMED')
        if ts(b['available_at']) > at: continue
        need(b.get('symbol')==symbol and b.get('security_id')==security_id,'BAR_IDENTITY_MISMATCH')
        if b['session'] not in expected_sessions: continue
        need(ts(b['close_at']) <= ts(b['available_at']), 'BAR_PUBLISHED_BEFORE_CLOSE')
        need(b.get('frequency')=='1d' and b.get('adjustment')=='PIT_SPLIT_ONLY', 'BAR_FREQUENCY_OR_ADJUSTMENT')
        need(bool(b.get('revision_id')) and bool(b.get('source_id')), 'BAR_LINEAGE_MISSING')
        k=(b['session'],ts(b['available_at']))
        need(k not in seen or seen[k]==b, 'BAR_REVISION_CONFLICT')
        seen[k]=b
        if b['session'] not in selected or ts(b['available_at'])>ts(selected[b['session']]['available_at']): selected[b['session']]=b
    need(set(selected)==set(expected_sessions), 'BAR_SESSION_GAP')
    bars=[selected[s] for s in expected_sessions]
    for b in bars:
        need(all(positive(b.get(x)) for x in ['open','high','low','close']), 'BAR_PRICE_INVALID')
        need(b['low']<=min(b['open'],b['close'])<=max(b['open'],b['close'])<=b['high'], 'BAR_OHLC_INVALID')
        need(finite(b.get('volume')) and b['volume']>=0,'BAR_VOLUME_INVALID')
        need(ts(b['close_at']).astimezone(ZoneInfo('America/New_York')).date().isoformat()==b['session'],'BAR_SESSION_CLOCK_MISMATCH')
    return bars

def rsi14(c):
    changes=[b-a for a,b in zip(c[-15:-1],c[-14:])]
    ups=sum(max(x,0) for x in changes); downs=sum(max(-x,0) for x in changes)
    return 50. if ups+downs==0 else 100*ups/(ups+downs)

def features(bars):
    c=[b['close'] for b in bars]
    returns=[math.log(b/a) for a,b in zip(c,c[1:])]
    # Forecast, not future realized outcome. EWMA, zero-mean daily variance, fixed lambda.
    v=mean([r*r for r in returns[:20]])
    for r in returns[20:]: v=.94*v+.06*r*r
    rv=max(.05,math.sqrt(252*v))
    prior_oversold=any(c[i]/c[i-5]-1<=-.04 and rsi14(c[:i+1])<=45 for i in range(len(c)-6,len(c)-1))
    stabilizing=c[-1]>=c[-2]>=c[-3] and bars[-1]['low']>=bars[-2]['low'] and c[-1]>=mean(c[-5:])
    trend=c[-1]>=.90*mean(c[-60:]) and mean(c[-20:])/mean(c[-25:-5])>=.98
    return {'rv_forecast':rv,'prior_oversold':prior_oversold,'stabilizing':stabilizing,'trend_allowed':trend,
            'last_close':c[-1],'sma60':mean(c[-60:]),'ret5':c[-1]/c[-6]-1,
            'adv20_dollars':mean([b['close']*b['volume'] for b in bars[-20:]]),
            'bar_hash':digest(bars)}

def regime(f):
    if f['rv_forecast']>.50 or f['last_close']<.90*f['sma60'] or f['ret5']<-.08: return 'STRESS'
    if f['rv_forecast']<=.35 and f['last_close']>=.98*f['sma60']: return 'CALM'
    return 'CAUTION'

def known_events(capsule, expiry, at):
    ec=capsule['events'];fresh(ec,at,86400,'EVENT_COVERAGE')
    need(ec.get('coverage_complete') is True and ec.get('revision_history') is True,'EVENT_COVERAGE_UNKNOWN')
    need(date.fromisoformat(ec['coverage_through'])>=expiry+timedelta(days=3),'EVENT_HORIZON_INCOMPLETE')
    in_horizon=[]
    for e in ec['items']:
        need(ts(e['available_at'])<=at,'EVENT_FUTURE_INPUT')
        d=date.fromisoformat(e['date']); now=at.astimezone(ZoneInfo('America/New_York')).date()
        need(e['kind'] in ['EARNINGS','MACRO','CORPORATE_ACTION','EX_DIVIDEND'],'EVENT_TYPE_UNKNOWN')
        if now<=d<=expiry+timedelta(days=3):in_horizon.append(e)
        if now<=d<=expiry+timedelta(days=3) and e['kind'] in ['EARNINGS','CORPORATE_ACTION']: raise Reject('EVENT_HOLDING_WINDOW')
        if now<=d<=now+timedelta(days=2) and e['kind'] in ['MACRO','EX_DIVIDEND']: raise Reject('EVENT_NEAR_ENTRY')
    return {'known_event_in_window':bool(in_horizon),'items':in_horizon}

def validate_contract(q, at, underlying, synthetic):
    need(q.get('underlying')==underlying and q.get('right')=='PUT','CONTRACT_UNDERLYING_OR_RIGHT')
    need(q.get('currency')=='USD' and q.get('multiplier')==100 and q.get('deliverable')=='100_COMMON_SHARES','CONTRACT_NONSTANDARD')
    need(q.get('exercise_style')=='AMERICAN' and q.get('settlement')=='PHYSICAL','CONTRACT_STYLE')
    need(q.get('adjusted') is False and q.get('metadata_complete') is True,'CONTRACT_METADATA_INCOMPLETE')
    need(all(q.get(k) for k in ['contract_id','security_id','exercise_cutoff','last_trade_at','metadata_source']),'CONTRACT_IDENTITY_INCOMPLETE')
    need(ts(q['metadata_available_at'])<=at,'CONTRACT_METADATA_FUTURE')
    need(ts(q['last_trade_at']).date()>=date.fromisoformat(q['expiry']),'CONTRACT_TRADING_DEADLINE_INVALID')
    need(ts(q['exercise_cutoff'])>=ts(q['last_trade_at']),'CONTRACT_EXERCISE_CUTOFF_INVALID')
    need(q.get('quote_kind')==('SYNTHETIC_BBO' if synthetic else 'RIGHTS_CLEARED_BBO'),'QUOTE_AUTHORITY_INVALID')
    fresh(q,at,60,'QUOTE')
    need(q.get('condition')=='REGULAR' and q.get('halted') is False,'QUOTE_CONDITION_INVALID')
    need(positive(q.get('strike')) and positive(q.get('bid')) and positive(q.get('ask')) and q['bid']<=q['ask'],'QUOTE_CROSSED_OR_EMPTY')
    need(q['bid']<q['strike'] and q['ask']<=q['strike'],'PUT_PRICE_RANGE_UNSUPPORTED')
    need(all(isinstance(q.get(k),int) and q[k]>=1 for k in ['bid_size','ask_size']),'QUOTE_SIZE_MISSING')
    need((q['ask']-q['bid'])/((q['ask']+q['bid'])/2)<=.15,'QUOTE_TOO_WIDE')
    need(finite(q.get('delta')) and -1<=q['delta']<=0 and positive(q.get('iv')) and q['iv']<=5,'GREEKS_UNKNOWN_OR_UNITS')
    need(ts(q['analytics_available_at'])<=at and ts(q['analytics_observed_at'])<=ts(q['analytics_available_at']),'ANALYTICS_FUTURE')
    need((at-ts(q['analytics_observed_at'])).total_seconds()<=60,'ANALYTICS_STALE')
    need(bool(q.get('analytics_model')),'ANALYTICS_MODEL_MISSING')
    need(isinstance(q.get('open_interest'),int) and q['open_interest']>=100,'OPEN_INTEREST_INADEQUATE')
    need(ts(q['oi_available_at'])<=at and (at-ts(q['oi_available_at'])).total_seconds()<=4*86400,'OI_STALE_OR_FUTURE')

def canonical_economics(short, long, f, days, costs):
    def leg(q):
        return {k:q.get(v) for k,v in {'optionSymbol':'contract_id','strike':'strike','bid':'bid','ask':'ask','delta':'delta','iv':'iv','volume':'volume','openInterest':'open_interest'}.items()}
    credit=short['bid']-(long['ask'] if long else 0)
    inp={'candidateId':'HARVESTER:'+short['contract_id']+(':'+long['contract_id'] if long else ''),
        # Adapter-required enum is not a registry insertion or active strategy selection.
        'strategyClass':'THETA_DEFINED_RISK' if long else 'THETA_CONVENTIONAL',
        'structure':'PUT_CREDIT_SPREAD' if long else 'CASH_SECURED_PUT','underlying':short['underlying'],
        'expiration':short['expiry'],'dte':days,'multiplier':100,'shortLeg':leg(short),'longLeg':leg(long) if long else None,
        'spot':f['spot_reference'],'creditPerShare':credit,'creditBasis':'LIMIT_PRICE',
        'openingCostsUsd':costs['opening_per_leg']*(2 if long else 1),'openingCostProvenance':costs['version'],
        'realizedVolatility':f['rv_forecast'],'realizedVolatilityProvenance':'EX_ANTE_EWMA_FORECAST_NOT_REALIZED_OUTCOME',
        'ivRank':None,'eventInWindow':f['known_event_in_window'],'stressGapPct':.20,'scenarioVolatility':f['rv_forecast'],
        'scenarioVolatilityProvenance':'EX_ANTE_EWMA_FORECAST','opportunityCostAnnualRate':None}
    need(credit>0,'NONPOSITIVE_CREDIT')
    if long is None:need(credit<short['strike'],'PUT_CREDIT_GE_STRIKE')
    if long: need(credit<short['strike']-long['strike'],'SPREAD_CREDIT_GE_WIDTH')
    p=subprocess.run(['node',str(ROOT/'canonical_bridge.mjs')],input=json.dumps([inp]),text=True,capture_output=True,check=True)
    return json.loads(p.stdout)[0]

def capital_ledger(budget, reserve, credit, opening, closing, liability, days, rates):
    """Constant-reserve expiry scenario; not valid for an early close/assignment path."""
    need(all(finite(x) and x>=0 for x in [budget,reserve,credit,opening,closing,liability,days]),'LEDGER_INPUT_INVALID')
    need(reserve+opening<=budget,'LEDGER_UNFUNDED')
    need(all(finite(rates.get(k)) for k in ['reserved','free','wait']),'CASH_RATES_UNKNOWN')
    free=budget+credit-opening-reserve; t=days/365
    wealth=reserve+free+reserve*rates['reserved']*t+free*rates['free']*t-closing-liability
    wait=budget*(1+rates['wait']*t)
    return {'terminal_wealth':wealth,'wait_wealth':wait,'difference_vs_wait':wealth-wait,'free_cash_principal':free,
            'reserved_cash_principal':reserve,'classification':'CONSTANT_RESERVE_EXPIRY_SCENARIO_NOT_EV','evidence':'MODEL_SCENARIO_NOT_MARKET_OUTCOME','execution_authority':False}

def size_alternative(kind, short, long, f, days, capsule):
    p=capsule['portfolio']; c=capsule['costs']; rates=capsule['cash_rates']
    e=canonical_economics(short,long,f,days,c)
    e['research_context']={'evidence':capsule['evidence'],'execution_authority':False,'quote_reference_only':True,'strategy':VERSION}
    legs=2 if long else 1
    gross=e['grossCreditUsd']['value']; op=c['opening_per_leg']*legs
    closing=c['closing_per_leg']*legs+c['extra_slippage_per_leg']*legs
    intact_loss=e['maxLossUsd']['value']+closing
    # Research reserve convention is full strike cash or full spread width, not source BPR.
    reserve=(short['strike']-(long['strike'] if long else 0))*100
    assignment_funding=short['strike']*100 # Always separate, including for a spread.
    stress_intrinsic=max(0,short['strike']-f['spot_reference']*.8)-(max(0,long['strike']-f['spot_reference']*.8) if long else 0)
    stress=max(0,100*stress_intrinsic-gross+op+closing)
    raw_delta=100*(abs(short['delta'])-(abs(long['delta']) if long else 0))
    need(raw_delta>0,'NET_DELTA_NONPOSITIVE')
    need(all(positive(v) for v in [reserve+op,intact_loss,assignment_funding,raw_delta,short['strike']*100]),'SIZING_DIVISOR_NONPOSITIVE')
    bounds={'cash':math.floor(p['available_cash']/(reserve+op)),
            'common_budget':math.floor(p['common_budget']/(reserve+op)),
            'max_loss':math.floor(p['max_loss_remaining']/intact_loss),
            'gross_assignment_funding':math.floor(p['contingent_assignment_cash']/assignment_funding),
            'short_share_notional':math.floor(p['short_share_cap']/100),
            'delta':math.floor(p['delta_share_remaining']/raw_delta),
            'concentration':math.floor(p['underlying_notional_remaining']/(short['strike']*100)),
            'sector':math.floor(p['sector_notional_remaining']/(short['strike']*100)),
            'quote_display_size':min(short['bid_size'],long['ask_size'] if long else short['bid_size'])}
    if stress>0: bounds['gap_stress']=math.floor(p['gap_loss_remaining']/stress)
    n=max(0,min(bounds.values()))
    row={'kind':kind,'evidence':capsule['evidence'],'execution_authority':False,'short_id':short['contract_id'],'long_id':long['contract_id'] if long else None,
         'quantity':n,'bounds':bounds,'canonical_receipt':e,'canonical_adapter_authority':{'price_basis':'SYNTHETIC_SIDE_QUOTE_REFERENCE' if capsule['evidence']=='SYNTHETIC_INVENTED' else 'OBSERVED_SIDE_QUOTE_REFERENCE_NO_FILL','executable':False,'actual_limit_order':False,'note':'Canonical LIMIT_PRICE enum is an arithmetic compatibility input, not an actual order or proven execution.'},'terminal_max_loss_with_cost_scenario':n*intact_loss,
         'gross_assignment_funding':n*assignment_funding,'reserve_principal':n*reserve,'gross_short_shares':n*100,
         'net_delta_shares':n*raw_delta,'stress20_expiry_loss':n*stress,'close_cost_scenario':n*closing,
         'source_capital_proxy_per_contract':e['capitalRequiredUsd']['value'],
         'observational_only':True,'fill_status':'NOT_SIMULATED','risk_equivalence_claim':False}
    if n==0: row.update(eligible=False,reason='ZERO_SIZE_VALID');return row
    ceiling=capital_ledger(p['common_budget'],n*reserve,n*gross,n*op,n*closing,0,days,rates)
    row['premium_ceiling_vs_wait']=ceiling
    row['cost_to_credit']=(op+closing)/gross
    row['max_option_profit_per_reserved_cash_day']=(gross-op-closing)/(reserve*days)
    row['eligible']=row['cost_to_credit']<=.20 and ceiling['difference_vs_wait']>0
    row['reason']='PASS_HYPOTHESES' if row['eligible'] else 'COST_OR_CASH_CEILING'
    row['terminal_stress_wealth']=[]
    for multiplier in [1.1,1,.95,.8,.5,0]:
        spot=f['spot_reference']*multiplier
        liability=n*100*(max(0,short['strike']-spot)-(max(0,long['strike']-spot) if long else 0))
        row['terminal_stress_wealth'].append({'spot':spot,**capital_ledger(p['common_budget'],n*reserve,n*gross,n*op,n*closing,liability,days,rates)})
    return row

def assess(capsule):
    base={'version':VERSION,'evidence':capsule.get('evidence') if isinstance(capsule,dict) else None,'decision':'WAIT','reason':None,'alternatives':[],
          'execution_authority':False,'empirical_profitability':'NOT_ESTABLISHED','input_sha256':None}
    try:
        need(isinstance(capsule,dict),'CAPSULE_MALFORMED')
        base['input_sha256']=digest(capsule)
        at=ts(capsule['decision_at']);synthetic=capsule['evidence']=='SYNTHETIC_INVENTED'
        need(synthetic or capsule['evidence']=='QUALIFIED_OBSERVATION','EVIDENCE_TIER_INVALID')
        need(capsule.get('rights_verified') is True,'DATA_RIGHTS_UNKNOWN')
        need(capsule.get('calendar_verified') is True and capsule.get('calendar_source'),'CALENDAR_UNKNOWN')
        local=at.astimezone(ZoneInfo('America/New_York'))
        need(local.strftime('%H:%M')=='10:00' and local.second==0,'DECISION_CLOCK_NOT_1000_ET')
        need(capsule.get('regular_session') is True,'NOT_REGULAR_SESSION')
        need(capsule.get('universe_pit_verified') is True and capsule.get('security_id'),'UNIVERSE_UNKNOWN')
        at_date=local.date(); sessions=capsule['expected_sessions'][-65:]
        need(sessions and sessions[-1]==capsule['previous_verified_session'],'BAR_LATEST_SESSION_MISMATCH')
        need(1<=(at_date-date.fromisoformat(sessions[-1])).days<=4,'BAR_WINDOW_STALE')
        uf=features(causal_bars(capsule['bars'],sessions,at,capsule['symbol'],capsule['security_id']));mf=features(causal_bars(capsule['market_bars'],sessions,at,capsule['market_symbol'],capsule['market_security_id']))
        spot=capsule['underlying_quote']
        need(spot.get('symbol')==capsule['symbol'] and spot.get('security_id')==capsule['security_id'],'UNDERLYING_QUOTE_IDENTITY')
        fresh(spot,at,60,'UNDERLYING_QUOTE')
        need(spot.get('quote_kind')==('SYNTHETIC_BBO' if synthetic else 'RIGHTS_CLEARED_BBO'),'UNDERLYING_QUOTE_AUTHORITY')
        need(positive(spot.get('bid')) and positive(spot.get('ask')) and spot['bid']<=spot['ask'] and spot.get('halted') is False,'UNDERLYING_QUOTE_INVALID')
        need((spot['ask']-spot['bid'])/((spot['ask']+spot['bid'])/2)<=.005,'UNDERLYING_QUOTE_TOO_WIDE')
        uf['spot_reference']=(spot['bid']+spot['ask'])/2
        r=regime(mf);base.update(features=uf,market_features=mf,regime=r)
        need(r!='STRESS','MARKET_STRESS')
        need(uf['adv20_dollars']>=50_000_000,'UNDERLYING_LIQUIDITY')
        need(uf['prior_oversold'],'NOT_PREVIOUSLY_OVERSOLD')
        need(uf['stabilizing'],'NOT_STABILIZING')
        need(uf['trend_allowed'],'FALLING_TREND')
        # ATM IV snapshot must be historical/as-of, never the provider's live regime field.
        vol=capsule['volatility']
        need(vol.get('symbol')==capsule['symbol'] and vol.get('security_id')==capsule['security_id'],'VOL_IDENTITY_MISMATCH')
        fresh(vol,at,60,'VOL')
        need(abs((ts(vol['observed_at'])-ts(spot['observed_at'])).total_seconds())<=1,'VOL_SPOT_DESYNCHRONIZED')
        need(vol.get('units')=='ANNUAL_DECIMAL' and vol.get('horizon_days')==30,'VOL_UNITS_OR_HORIZON')
        need(positive(vol.get('atm_iv')) and vol['atm_iv']<=5,'VOL_LEVEL_INVALID')
        selected_iv={}; seen_iv={}
        for x in vol['history']:
            need(isinstance(x,dict),'IV_HISTORY_MALFORMED')
            if ts(x['available_at'])>at: continue
            need(x.get('symbol')==capsule['symbol'] and x.get('security_id')==capsule['security_id'],'IV_HISTORY_IDENTITY')
            need(ts(x['observed_at'])<=ts(x['available_at']),'IV_PUBLISHED_BEFORE_OBSERVATION')
            need(ts(x['observed_at']).astimezone(ZoneInfo('America/New_York')).date().isoformat()==x['session'],'IV_HISTORY_SESSION_CLOCK')
            need(bool(x.get('revision_id')) and bool(x.get('source_id')),'IV_HISTORY_LINEAGE')
            if x['session']>=at_date.isoformat(): continue
            k=(x['session'],ts(x['available_at']))
            need(k not in seen_iv or seen_iv[k]==x,'IV_REVISION_CONFLICT');seen_iv[k]=x
            if x['session'] not in selected_iv or ts(x['available_at'])>ts(selected_iv[x['session']]['available_at']):selected_iv[x['session']]=x
        hist=[selected_iv[k] for k in sorted(selected_iv)]
        need(len(hist)>=60 and len({x['session'] for x in hist})==len(hist),'IV_HISTORY_INCOMPLETE')
        need(all(positive(x.get('value')) and x['value']<=5 and x.get('vintage_verified') is True for x in hist),'IV_HISTORY_INVALID')
        need({x['session'] for x in hist[-60:]}==set(sessions[-60:]),'IV_HISTORY_SESSION_GAP')
        pct=sum(x['value']<=vol['atm_iv'] for x in hist[-60:])/60
        base['iv_percentile']=pct; base['iv_minus_forecast_rv']=vol['atm_iv']-uf['rv_forecast']
        need(pct>=.60 and vol['atm_iv']>=1.10*uf['rv_forecast'],'VOL_NOT_RICH')
        for group,fields in [('portfolio',['common_budget','available_cash','max_loss_remaining','contingent_assignment_cash','short_share_cap','delta_share_remaining','underlying_notional_remaining','sector_notional_remaining','gap_loss_remaining']),('costs',['opening_per_leg','closing_per_leg','extra_slippage_per_leg'])]:
            obj=capsule[group]; need(all(finite(obj.get(k)) and obj[k]>=0 for k in fields),group.upper()+'_UNKNOWN')
            need(bool(obj.get('version')) and ts(obj['available_at'])<=at,group.upper()+'_LINEAGE')
        need(capsule['portfolio'].get('caps_pit_verified') is True,'PORTFOLIO_CAPS_UNVERIFIED')
        fresh(capsule['portfolio'],at,60,'PORTFOLIO')
        need(capsule['costs'].get('complete') is True,'FEES_INCOMPLETE')
        need(all(finite(capsule['cash_rates'].get(k)) for k in ['reserved','free','wait']) and capsule['cash_rates'].get('version'),'CASH_RATES_UNKNOWN')
        need(ts(capsule['cash_rates']['available_at'])<=at,'CASH_RATES_FUTURE')
        valid=[];rejects=[]
        for q in capsule['chain']:
            need(isinstance(q,dict),'CONTRACT_RECORD_MALFORMED')
            try:
                validate_contract(q,at,capsule['symbol'],synthetic)
                need(q['security_id']==capsule['security_id'],'CONTRACT_SECURITY_MISMATCH')
                need(abs((ts(q['observed_at'])-ts(spot['observed_at'])).total_seconds())<=1,'OPTION_SPOT_DESYNCHRONIZED')
                d=(date.fromisoformat(q['expiry'])-at_date).days
                if 30<=d<=45: valid.append(q)
            except (Reject,KeyError,TypeError,ValueError) as e: rejects.append({'id':q.get('contract_id'),'reason':str(e)})
        base['contract_rejects']=rejects
        need(len({x['contract_id'] for x in valid})==len(valid),'DUPLICATE_CONTRACT')
        need(valid,'NO_QUALIFIED_CHAIN')
        expiry=min({x['expiry'] for x in valid},key=lambda x:(abs((date.fromisoformat(x)-at_date).days-38),x))
        ev=known_events(capsule,date.fromisoformat(expiry),at);base['event_context']=ev;uf['known_event_in_window']=ev['known_event_in_window']
        same=[x for x in valid if x['expiry']==expiry]
        shorts=[x for x in same if .20<=abs(x['delta'])<=.25]
        need(shorts,'NO_DELTA_MATCH')
        short=min(shorts,key=lambda x:(round(abs(abs(x['delta'])-.225),12),x['strike'],x['contract_id']))
        longs=[x for x in same if x['strike']<short['strike'] and .02<= (short['strike']-x['strike'])/uf['spot_reference']<=.10]
        long=min(longs,key=lambda x:(round(abs((short['strike']-x['strike'])/uf['spot_reference']-.05),12),short['strike']-x['strike'],x['contract_id'])) if longs else None
        days=(date.fromisoformat(expiry)-at_date).days
        base.update(expiry=expiry,dte=days,short_contract=short['contract_id'],long_contract=long['contract_id'] if long else None)
        alternatives=[]
        for kind,protect in [('CSP',None),('PUT_CREDIT_SPREAD',long)]:
            if kind=='PUT_CREDIT_SPREAD' and protect is None:
                alternatives.append({'kind':kind,'eligible':False,'reason':'NO_LONG_MATCH','quantity':0});continue
            if protect and abs((ts(short['observed_at'])-ts(protect['observed_at'])).total_seconds())>1:
                alternatives.append({'kind':kind,'eligible':False,'reason':'LEG_QUOTE_DESYNCHRONIZED','quantity':0});continue
            try: alternatives.append(size_alternative(kind,short,protect,uf,days,capsule))
            except Reject as e: alternatives.append({'kind':kind,'eligible':False,'reason':str(e),'quantity':0})
        alternatives.append({'kind':'WAIT','evidence':capsule['evidence'],'execution_authority':False,'eligible':True,'quantity':0,'budget':capsule['portfolio']['common_budget'],
                             'terminal_cash':capsule['portfolio']['common_budget']*(1+capsule['cash_rates']['wait']*days/365)})
        base['alternatives']=alternatives
        csp,spread=alternatives[:2]
        ownership=capsule['portfolio'].get('ownership_approved') is True
        # Fixed regime rule; no argmax of premium ceilings and no expected-return claim.
        chosen=(csp if r=='CALM' and ownership and csp['eligible'] else spread if spread['eligible'] else None)
        if chosen is None: base['reason']='NO_POLICY_ELIGIBLE_STRUCTURE'
        else: base.update(decision=chosen['kind'],quantity=chosen['quantity'],reason='RESEARCH_HYPOTHESIS_ONLY')
        return base
    except (Reject,KeyError,TypeError,ValueError,OverflowError,AttributeError) as e:
        base['reason']=str(e);return base


def management(position, obs):
    """Priority-ordered symbolic research intent. It cannot change inventory or send orders."""
    if not isinstance(position,dict) or not isinstance(obs,dict):return 'MALFORMED_MANAGEMENT_RECONCILE'
    if obs.get('assignment_status') not in ['NONE','CONFIRMED']: return 'FREEZE_RECONCILE'
    if obs.get('assignment_status')=='CONFIRMED': return 'ASSIGNMENT_EXCEPTION_NO_NEW_RISK'
    if position.get('structure') not in ['CSP','PUT_CREDIT_SPREAD']:return 'UNKNOWN_STRUCTURE_RECONCILE'
    if not all(isinstance(position.get(k),int) and not isinstance(position[k],bool) and position[k]>=0 for k in ['short_quantity','long_quantity']):return 'UNKNOWN_TOPOLOGY_RECONCILE'
    if position['structure']=='CSP' and position['long_quantity']!=0:return 'TOPOLOGY_BREACH_RECONCILE'
    if position['structure']=='PUT_CREDIT_SPREAD' and position['short_quantity']!=position['long_quantity']:return 'TOPOLOGY_BREACH_RECONCILE'
    if position['short_quantity']==0:return 'OPTIONS_FLAT_CHECK_STOCK_LEDGER'
    flags=[obs.get(k) for k in ['mandatory_exit','event_within_2_calendar_days','thesis_broken']]
    if any(x is True for x in flags):return 'CLOSE_REQUIRED_NOT_FILLED'
    if not isinstance(obs.get('dte'),int) or isinstance(obs['dte'],bool) or obs['dte']<0:return 'UNKNOWN_DEADLINE_RETAIN_EXPOSURE'
    if obs['dte']<=7:return 'CLOSE_REQUIRED_NOT_FILLED'
    if not all(isinstance(x,bool) for x in flags):return 'UNKNOWN_EXIT_STATE_RETAIN_EXPOSURE'
    if obs.get('quote_complete') is not True: return 'UNKNOWN_CLOSEABILITY_RETAIN_EXPOSURE'
    values=[position.get('original_credit'),position.get('opening_fees'),obs.get('confirmed_close_debits'),obs.get('confirmed_close_fees'),obs.get('residual_liquidation_debit'),obs.get('residual_close_fees')]
    if not all(finite(x) and x>=0 for x in values): return 'UNKNOWN_PNL_RETAIN_EXPOSURE'
    credit,opening,paid,paidfees,residual,resfees=values
    net=credit-opening
    if net<=0:return 'INVALID_OPENING_NET_CREDIT'
    pnl=net-paid-paidfees-residual-resfees
    if pnl>=.50*net: return 'NET50_CLOSE_SIGNAL_NOT_FILLED'
    if pnl<=-net: return 'NET_CREDIT_LOSS_CLOSE_SIGNAL_NOT_FILLED'
    return 'OBSERVE_NO_ROLL'

if __name__=='__main__':
    import argparse
    a=argparse.ArgumentParser();a.add_argument('capsule');a.add_argument('--output');ns=a.parse_args()
    result=assess(json.loads(Path(ns.capsule).read_text()));out=json.dumps(result,indent=2,allow_nan=False)+'\n'
    if ns.output:Path(ns.output).write_text(out)
    else:print(out,end='')
