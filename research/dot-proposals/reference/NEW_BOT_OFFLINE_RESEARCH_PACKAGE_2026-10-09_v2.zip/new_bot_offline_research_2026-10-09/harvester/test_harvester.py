import copy,json,unittest,math
from datetime import timedelta
from harvester import *
from make_fixtures import fixture

class HarvesterTests(unittest.TestCase):
    def setUp(self): self.f=fixture()
    def result(self):return assess(self.f)
    def wait(self,reason):
        r=self.result();self.assertEqual(r['decision'],'WAIT');self.assertEqual(r['reason'],reason)
    def test_nonfinite_input_wait(self):self.f['costs']['opening_per_leg']=float('nan');self.assertEqual(self.result()['decision'],'WAIT')
    def test_latest_session_required(self):self.f['previous_verified_session']='2026-10-07';self.wait('BAR_LATEST_SESSION_MISMATCH')
    def test_stale_portfolio(self):self.f['portfolio']['observed_at']='2026-10-09T13:58:00Z';self.wait('PORTFOLIO_STALE')
    def test_iv_history_permutation_invariance(self):
        a=self.result();self.f['volatility']['history'].reverse();self.assertEqual(a['decision'],self.result()['decision'])
    def test_current_spot_used(self):
        self.f['underlying_quote'].update(bid=96.99,ask=97.01);r=self.result();self.assertAlmostEqual(r['features']['spot_reference'],97.);self.assertEqual(r['features']['last_close'],96.)
    def test_iv_availability_cannot_precede_observation(self):
        for x in self.f['volatility']['history']:x['available_at']='2000-01-01T00:00:00Z'
        self.wait('IV_PUBLISHED_BEFORE_OBSERVATION')
    def test_iv_known_revision_causal(self):
        b=copy.deepcopy(self.f['volatility']['history'][-1]);b.update(available_at='2026-10-09T13:00:00Z',value=.40,revision_id='new');self.f['volatility']['history'].append(b)
        self.assertAlmostEqual(self.result()['iv_percentile'],59/60)
    def test_iv_future_revision_ignored(self):
        a=self.result();b=copy.deepcopy(self.f['volatility']['history'][-1]);b.update(available_at='2026-10-09T15:00:00Z',value=.40,revision_id='future');self.f['volatility']['history'].append(b)
        self.assertEqual(a['iv_percentile'],self.result()['iv_percentile'])
    def test_iv_revision_conflict(self):
        b=copy.deepcopy(self.f['volatility']['history'][-1]);b['value']=.4;self.f['volatility']['history'].append(b);self.wait('IV_REVISION_CONFLICT')
    def test_stock_bar_identity_bound(self):self.f['bars'][0]['security_id']='OTHER';self.wait('BAR_IDENTITY_MISMATCH')
    def test_market_bar_identity_bound(self):self.f['market_bars'][0]['symbol']='OTHER';self.wait('BAR_IDENTITY_MISMATCH')
    def test_stock_quote_identity_bound(self):self.f['underlying_quote']['security_id']='OTHER';self.wait('UNDERLYING_QUOTE_IDENTITY')
    def test_vol_identity_bound(self):self.f['volatility']['security_id']='OTHER';self.wait('VOL_IDENTITY_MISMATCH')
    def test_synthetic_not_executable(self):
        r=self.result();a=r['alternatives'][0];self.assertFalse(a['canonical_adapter_authority']['executable']);self.assertNotIn('EXECUTABLE',json.dumps(a['canonical_receipt']))
    def test_nonobject_capsule(self):self.assertEqual(assess([])['reason'],'CAPSULE_MALFORMED')
    def test_nondict_contract(self):self.f['chain'].append('oops');self.wait('CONTRACT_RECORD_MALFORMED')
    def test_equivalent_bar_timestamp_conflict_order_independent(self):
        b=copy.deepcopy(self.f['bars'][-1]);b.update(available_at='2026-10-08T16:01:00-04:00',close=80.,open=80.,low=79.,high=81.,revision_id='conflict');self.f['bars'].append(b);self.wait('BAR_REVISION_CONFLICT');self.f['bars'].reverse();self.wait('BAR_REVISION_CONFLICT')
    def test_equivalent_iv_timestamp_conflict(self):
        b=copy.deepcopy(self.f['volatility']['history'][-1]);b.update(available_at='2026-10-08T16:01:00-04:00',value=.4,revision_id='conflict');self.f['volatility']['history'].append(b);self.wait('IV_REVISION_CONFLICT')
    def test_put_credit_above_strike_rejected(self):
        self.f['chain'][0].update(bid=90.014,ask=90.02);r=self.result();self.assertEqual(r['decision'],'WAIT');self.assertEqual(r['reason'],'NO_DELTA_MATCH');self.assertEqual(r['contract_rejects'][0]['reason'],'PUT_PRICE_RANGE_UNSUPPORTED')
    def test_zero_loss_divisor_rejected(self):
        self.f['chain'][0].update(bid=89.9999999,ask=90.);self.f['costs'].update(opening_per_leg=0.,closing_per_leg=0.,extra_slippage_per_leg=0.);r=self.result();self.assertEqual(r['decision'],'WAIT');self.assertEqual(r['alternatives'][0]['reason'],'SIZING_DIVISOR_NONPOSITIVE')
    def test_future_macro_preserved_in_economics(self):
        self.f['events']['items']=[{'kind':'MACRO','date':'2026-10-20','available_at':self.f['decision_at']}];r=self.result();self.assertEqual(r['decision'],'CSP');self.assertEqual(r['alternatives'][0]['canonical_receipt']['eventRisk'],'EVENT_IN_WINDOW')
    def test_every_main_receipt_synthetic_context(self):
        r=self.result()
        for a in r['alternatives']:self.assertEqual(a['evidence'],'SYNTHETIC_INVENTED');self.assertFalse(a['execution_authority'])
        for a in r['alternatives'][:2]:self.assertEqual(a['canonical_receipt']['research_context']['evidence'],'SYNTHETIC_INVENTED');self.assertEqual(a['premium_ceiling_vs_wait']['evidence'],'MODEL_SCENARIO_NOT_MARKET_OUTCOME')
    def test_future_wrong_identity_bar_is_invisible(self):
        a=self.result();b=copy.deepcopy(self.f['bars'][-1]);b.update(available_at='2026-10-09T14:01:00Z',security_id='OTHER',revision_id='future');self.f['bars'].append(b);r=self.result();self.assertEqual(a['decision'],r['decision']);self.assertEqual(a['features'],r['features'])
    def test_two_unsupported_leg_marks_cannot_form_spread(self):
        self.f['portfolio']['ownership_approved']=False;self.f['chain'][0].update(bid=90.014,ask=90.02);self.f['chain'][1].update(bid=85.01,ask=85.02);self.wait('NO_QUALIFIED_CHAIN')
    def test_calm_csp(self):self.assertEqual(self.result()['decision'],'CSP')
    def test_caution_spread(self):
        for i,b in enumerate(self.f['market_bars']):
            c=100-.07*i;b.update(open=c,close=c,low=c-1,high=c+1)
        self.assertEqual(self.result()['decision'],'PUT_CREDIT_SPREAD')
    def test_market_stress_wait(self):
        b=self.f['market_bars'][-1];b.update(open=80.,close=80.,low=79.,high=81.)
        self.wait('MARKET_STRESS')
    def test_no_assignment_mandate_spread(self):
        self.f['portfolio']['ownership_approved']=False;self.assertEqual(self.result()['decision'],'PUT_CREDIT_SPREAD')
    def test_future_bar_revision_not_visible(self):
        a=self.result();b=copy.deepcopy(self.f['bars'][-1]);b.update(available_at='2026-10-09T14:01:00Z',close=2.,open=2.,low=1.,high=3.,revision_id='future');self.f['bars'].append(b)
        self.assertEqual(a['features'],self.result()['features'])
    def test_known_revision_changes_feature(self):
        a=self.result();b=copy.deepcopy(self.f['bars'][-1]);b.update(available_at='2026-10-09T13:00:00Z',close=80.,open=80.,low=79.,high=81.,revision_id='revision');self.f['bars'].append(b)
        self.assertNotEqual(a['features']['bar_hash'],self.result()['features']['bar_hash']);self.wait('NOT_STABILIZING')
    def test_conflicting_revision_wait(self):
        b=copy.deepcopy(self.f['bars'][-1]);b['close']-=1;self.f['bars'].append(b);self.wait('BAR_REVISION_CONFLICT')
    def test_current_daily_bar_forbidden(self):
        self.f['expected_sessions'][-1]='2026-10-09';self.f['previous_verified_session']='2026-10-09';self.wait('BAR_WINDOW_STALE')
    def test_missing_session_wait(self):self.f['bars'].pop(30);self.wait('BAR_SESSION_GAP')
    def test_weekly_rejected(self):self.f['bars'][0]['frequency']='1w';self.wait('BAR_FREQUENCY_OR_ADJUSTMENT')
    def test_final_adjustment_rejected(self):self.f['bars'][0]['adjustment']='CURRENT_TOTAL_RETURN';self.wait('BAR_FREQUENCY_OR_ADJUSTMENT')
    def test_publish_before_close(self):self.f['bars'][0]['available_at']=self.f['bars'][0]['session']+'T19:00:00Z';self.wait('BAR_PUBLISHED_BEFORE_CLOSE')
    def test_no_oversold(self):
        for b in self.f['bars']:b.update(close=100.,open=100.,low=99.,high=101.)
        self.wait('NOT_PREVIOUSLY_OVERSOLD')
    def test_no_stabilization(self):
        b=self.f['bars'][-1];b.update(open=92.,close=92.,low=91.,high=93.);self.wait('NOT_STABILIZING')
    def test_illiquid_underlying(self):
        for b in self.f['bars']:b['volume']=100
        self.wait('UNDERLYING_LIQUIDITY')
    def test_earnings_wait(self):
        self.f['events']['items']=[{'date':'2026-10-20','kind':'EARNINGS','available_at':self.f['decision_at']}];self.wait('EVENT_HOLDING_WINDOW')
    def test_corporate_event_wait(self):
        self.f['events']['items']=[{'date':'2026-11-14','kind':'CORPORATE_ACTION','available_at':self.f['decision_at']}];self.wait('EVENT_HOLDING_WINDOW')
    def test_macro_wait(self):
        self.f['events']['items']=[{'date':'2026-10-10','kind':'MACRO','available_at':self.f['decision_at']}];self.wait('EVENT_NEAR_ENTRY')
    def test_event_coverage_missing(self):self.f['events']['coverage_complete']=False;self.wait('EVENT_COVERAGE_UNKNOWN')
    def test_event_horizon_short(self):self.f['events']['coverage_through']='2026-10-20';self.wait('EVENT_HORIZON_INCOMPLETE')
    def test_iv_not_rich(self):self.f['volatility']['atm_iv']=.10;self.wait('VOL_NOT_RICH')
    def test_iv_units(self):self.f['volatility']['units']='PERCENT';self.wait('VOL_UNITS_OR_HORIZON')
    def test_iv_history_missing(self):self.f['volatility']['history']=self.f['volatility']['history'][-59:];self.wait('IV_HISTORY_INCOMPLETE')
    def test_iv_history_future_ignored(self):
        self.f['volatility']['history'][-1]['available_at']='2026-10-09T15:00:00Z';self.wait('IV_HISTORY_SESSION_GAP')
    def test_provider_live_regime_irrelevant(self):
        a=self.result();self.f['provider_live_regime']='PANIC';b=self.result();self.assertEqual(a['regime'],b['regime'])
    def test_missing_cash_rate(self):self.f['cash_rates']['wait']=None;self.wait('CASH_RATES_UNKNOWN')
    def test_missing_fees(self):self.f['costs']['closing_per_leg']=None;self.wait('COSTS_UNKNOWN')
    def test_missing_caps(self):self.f['portfolio']['max_loss_remaining']=None;self.wait('PORTFOLIO_UNKNOWN')
    def test_zero_size_wait(self):self.f['portfolio']['available_cash']=10.;self.wait('NO_POLICY_ELIGIBLE_STRUCTURE')
    def test_funding_cap_applies_spread(self):
        self.f['portfolio']['contingent_assignment_cash']=8000.;self.wait('NO_POLICY_ELIGIBLE_STRUCTURE')
    def test_cash_ceiling_can_reject(self):self.f['cash_rates']['wait']=2.;self.wait('NO_POLICY_ELIGIBLE_STRUCTURE')
    def test_stale_quotes(self):
        for q in self.f['chain']:q['observed_at']='2026-10-09T13:58:00Z'
        self.wait('NO_QUALIFIED_CHAIN')
    def test_indicative_quotes(self):
        for q in self.f['chain']:q['quote_kind']='INDICATIVE'
        self.wait('NO_QUALIFIED_CHAIN')
    def test_nonstandard_contract(self):
        for q in self.f['chain']:q['deliverable']='ADJUSTED_BASKET'
        self.wait('NO_QUALIFIED_CHAIN')
    def test_incomplete_contract(self):
        for q in self.f['chain']:q.pop('exercise_cutoff')
        self.wait('NO_QUALIFIED_CHAIN')
    def test_crossed_quotes(self):
        for q in self.f['chain']:q['bid']=q['ask']+.01
        self.wait('NO_QUALIFIED_CHAIN')
    def test_duplicate_contract(self):self.f['chain'].append(copy.deepcopy(self.f['chain'][0]));self.wait('DUPLICATE_CONTRACT')
    def test_chain_permutation_invariance(self):
        a=self.result();self.f['chain'].reverse();b=self.result();self.assertEqual(a['alternatives'],b['alternatives'])
    def test_delta_tie_lower_strike(self):
        self.f['chain'][0]['delta']=-.20
        q=copy.deepcopy(self.f['chain'][0]);q.update(contract_id='OTHER',strike=91.,delta=-.25);self.f['chain'].append(q)
        self.assertEqual(self.result()['short_contract'],'MOCK_P90')
    def test_expiry_tie_earlier(self):
        for q in copy.deepcopy(self.f['chain']):
            q.update(contract_id=q['contract_id']+'_LATER',expiry='2026-11-19',last_trade_at='2026-11-19T21:00:00Z',exercise_cutoff='2026-11-19T21:30:00Z');self.f['chain'].append(q)
        self.assertEqual(self.result()['expiry'],'2026-11-13')
    def test_no_delta_bucket_wait(self):self.f['chain'][0]['delta']=-.19;self.wait('NO_DELTA_MATCH')
    def test_quote_synchronization(self):
        self.f['portfolio']['ownership_approved']=False;self.f['chain'][1]['observed_at']='2026-10-09T13:59:57Z';self.wait('NO_POLICY_ELIGIBLE_STRUCTURE')
    def test_same_budget_not_same_tail(self):
        a,b,w=self.result()['alternatives'];self.assertEqual(a['quantity'],b['quantity']);self.assertGreater(a['terminal_max_loss_with_cost_scenario'],10*b['terminal_max_loss_with_cost_scenario']);self.assertEqual(a['gross_assignment_funding'],b['gross_assignment_funding'])
    def test_canonical_arithmetic_reuse(self):
        a,b,_=self.result()['alternatives'];self.assertAlmostEqual(a['canonical_receipt']['maxLossUsd']['value'],8850.65);self.assertAlmostEqual(b['canonical_receipt']['maxLossUsd']['value'],401.3)
        self.assertEqual(a['canonical_receipt']['expectedValueUsd']['state'],'UNKNOWN')
    def test_no_spread_double_count(self):
        a,b,_=self.result()['alternatives'];self.assertAlmostEqual(a['canonical_receipt']['netCreditUsd']['value'],149.35);self.assertAlmostEqual(b['canonical_receipt']['netCreditUsd']['value'],98.7)
    def test_quote_size_caps_not_fill_claim(self):
        self.f['chain'][0]['bid_size']=1;r=self.result();self.assertEqual(r['quantity'],1);self.assertEqual(r['alternatives'][0]['fill_status'],'NOT_SIMULATED')
    def test_loss_budget_caps_integer(self):
        self.f['portfolio']['max_loss_remaining']=1000.;r=self.result();self.assertEqual(r['decision'],'PUT_CREDIT_SPREAD');self.assertEqual(r['quantity'],2)
    def test_excluded_strike_not_replaced_on_bad_credit(self):
        self.f['chain'][1].update(bid=1.6,ask=1.7);self.f['portfolio']['ownership_approved']=False;self.wait('NO_POLICY_ELIGIBLE_STRUCTURE')
    def test_cash_ledger_identity(self):
        r=capital_ledger(10000,9000,150,.65,.75,0,35,{'reserved':0,'free':.03,'wait':.03})
        expected=149.35-.75-9000*.03*35/365+149.35*.03*35/365
        self.assertAlmostEqual(r['difference_vs_wait'],expected)
    def test_zero_rates_ceiling(self):
        r=capital_ledger(10000,9000,150,1,1,0,30,{'reserved':0,'free':0,'wait':0});self.assertAlmostEqual(r['difference_vs_wait'],148)
    def test_ledger_liability_retained(self):
        rates={'reserved':0,'free':0,'wait':0};a=capital_ledger(10000,9000,150,1,1,0,30,rates);b=capital_ledger(10000,9000,150,1,1,2000,30,rates);self.assertEqual(a['terminal_wealth']-b['terminal_wealth'],2000)
    def test_ledger_unknown_rates_reject(self):
        with self.assertRaises(Reject):capital_ledger(10000,9000,150,1,1,0,30,{'reserved':None,'free':0,'wait':0})

class ManagementTests(unittest.TestCase):
    def setUp(self):
        self.p={'structure':'PUT_CREDIT_SPREAD','short_quantity':2,'long_quantity':2,'original_credit':200.,'opening_fees':2.}
        self.o={'assignment_status':'NONE','mandatory_exit':False,'event_within_2_calendar_days':False,'thesis_broken':False,'quote_complete':True,'dte':20,'confirmed_close_debits':0.,'confirmed_close_fees':0.,'residual_liquidation_debit':95.,'residual_close_fees':2.}
    def test_missing_assignment_state_freezes(self):self.o.pop('assignment_status');self.assertEqual(management(self.p,self.o),'FREEZE_RECONCILE')
    def test_missing_dte_retains_exposure(self):self.o.pop('dte');self.assertEqual(management(self.p,self.o),'UNKNOWN_DEADLINE_RETAIN_EXPOSURE')
    def test_unknown_long_quantity_reconciles(self):self.p.pop('long_quantity');self.assertEqual(management(self.p,self.o),'UNKNOWN_TOPOLOGY_RECONCILE')
    def test_unknown_event_cannot_profit_take(self):self.o.pop('event_within_2_calendar_days');self.assertEqual(management(self.p,self.o),'UNKNOWN_EXIT_STATE_RETAIN_EXPOSURE')
    def test_unknown_thesis_cannot_profit_take(self):self.o.pop('thesis_broken');self.assertEqual(management(self.p,self.o),'UNKNOWN_EXIT_STATE_RETAIN_EXPOSURE')
    def test_unknown_mandatory_cannot_profit_take(self):self.o.pop('mandatory_exit');self.assertEqual(management(self.p,self.o),'UNKNOWN_EXIT_STATE_RETAIN_EXPOSURE')
    def test_bad_quantity_reconciles(self):self.p['short_quantity']='2';self.assertEqual(management(self.p,self.o),'UNKNOWN_TOPOLOGY_RECONCILE')
    def test_malformed_management_reconciles(self):self.assertEqual(management([],None),'MALFORMED_MANAGEMENT_RECONCILE')
    def test_negative_quantity_reconciles(self):self.p.update(short_quantity=-2,long_quantity=-2);self.assertEqual(management(self.p,self.o),'UNKNOWN_TOPOLOGY_RECONCILE')
    def test_net50_signal_not_fill(self):self.assertEqual(management(self.p,self.o),'NET50_CLOSE_SIGNAL_NOT_FILLED')
    def test_original_denominator_after_partial(self):
        self.o.update(confirmed_close_debits=40.,confirmed_close_fees=1.,residual_liquidation_debit=60.,residual_close_fees=1.);self.assertEqual(management(self.p,self.o),'OBSERVE_NO_ROLL')
    def test_mandatory_beats_profit(self):self.o['dte']=7;self.assertEqual(management(self.p,self.o),'CLOSE_REQUIRED_NOT_FILLED')
    def test_missing_quote_retains_risk(self):self.o['quote_complete']=False;self.assertEqual(management(self.p,self.o),'UNKNOWN_CLOSEABILITY_RETAIN_EXPOSURE')
    def test_partial_hedge_not_intact(self):self.p['long_quantity']=1;self.assertEqual(management(self.p,self.o),'TOPOLOGY_BREACH_RECONCILE')
    def test_assignment_pending_freeze(self):self.o['assignment_status']='PENDING';self.assertEqual(management(self.p,self.o),'FREEZE_RECONCILE')
    def test_assignment_no_automatic_call(self):self.o['assignment_status']='CONFIRMED';self.assertEqual(management(self.p,self.o),'ASSIGNMENT_EXCEPTION_NO_NEW_RISK')
    def test_adverse_close_signal_not_guaranteed_stop(self):self.o['residual_liquidation_debit']=500.;self.assertEqual(management(self.p,self.o),'NET_CREDIT_LOSS_CLOSE_SIGNAL_NOT_FILLED')
    def test_roll_never_output(self):self.o['residual_liquidation_debit']=150.;self.assertEqual(management(self.p,self.o),'OBSERVE_NO_ROLL')

if __name__=='__main__':unittest.main(verbosity=2)
