#!/usr/bin/env python3
"""Local-only reproduction from this directory; Python 3.12+ and Node 24+.
No network, installs, credentials, account state, registration or publication.
"""
import csv,hashlib,json,platform,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
P=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name,data):(P/'evidence'/name).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
def main():
    expected='127b701e601129c646270a91c4a8e0249b1f4556aa656998a110d89f78f0e0b0'
    vendor=P/'vendor/canonical-strategy-economics.ts'
    if not vendor.is_file() or sha(vendor)!=expected:raise SystemExit('Missing or mismatched separately authorized canonical arithmetic dependency; do not download automatically.')
    (P/'evidence').mkdir(exist_ok=True)
    subprocess.run([sys.executable,'make_fixtures.py'],cwd=P,check=True)
    run=subprocess.run([sys.executable,'-m','unittest','-v','test_harvester'],cwd=P,text=True,capture_output=True)
    (P/'evidence/unit_tests_final.log').write_text(run.stdout+run.stderr)
    if run.returncode:print(run.stderr);raise SystemExit(run.returncode)
    from harvester import assess,capital_ledger
    results={}
    for name in ['base','caution','unknown_events']:
        capsule=json.loads((P/'fixtures'/f'{name}_synthetic.json').read_text())
        result=assess(capsule);write(f'{name}_synthetic_result.json',result);results[name]=result['decision']
    if results!={'base':'CSP','caution':'PUT_CREDIT_SPREAD','unknown_events':'WAIT'}:raise AssertionError(results)
    # Independent payoff grid: zero-rate, explicit fee convention, no intermediate path.
    rows=[]
    for kind,long in [('CSP',None),('PUT_CREDIT_SPREAD',85.)]:
        for quantity in range(1,6):
            for spot in range(0,151,5):
                credit=quantity*(150 if long is None else 100);opening=quantity*(.65 if long is None else 1.30);closing=quantity*(.75 if long is None else 1.50)
                reserve=quantity*(9000 if long is None else 500);budget=50000
                short_payoff=quantity*100*max(90-spot,0);long_payoff=quantity*100*max((long or 0)-spot,0)
                ledger=capital_ledger(budget,reserve,credit,opening,closing,short_payoff-long_payoff,35,{'reserved':0,'free':0,'wait':0})
                independent_pnl=credit-opening-closing-short_payoff+long_payoff
                assert abs(ledger['terminal_wealth']-budget-independent_pnl)<1e-8
                worst=quantity*((8850+.65+.75) if long is None else (400+1.3+1.5))
                assert independent_pnl>=-worst-1e-8
                rows.append({'structure':kind,'quantity':quantity,'spot':spot,'net_pnl_synthetic':independent_pnl})
    write('payoff_grid_receipt.json',{'evidence':'INVENTED_ALGEBRA_GRID_NOT_MARKET_SAMPLE','cases':len(rows),'checks':2*len(rows),'rows':rows})
    code=[P/x for x in ['harvester.py','test_harvester.py','make_fixtures.py','canonical_bridge.mjs','reproduce.py','vendor/canonical-strategy-economics.ts']]
    write('final_run_receipt.json',{'version':'harvester-research-0.1.1','run_at_host_utc':datetime.now(timezone.utc).isoformat(),
          'python':platform.python_version(),'node':subprocess.check_output(['node','--version'],text=True).strip(),
          'command':'python reproduce.py','cwd':'new_bot_incubator/harvester','unit_suite_exit_code':run.returncode,
          'unit_test_log_sha256':sha(P/'evidence/unit_tests_final.log'),'branch_decisions':results,
          'algebra_grid_rows':len(rows),'historical_option_episodes':0,'qualified_live_capsules':0,
          'evidence':'STRUCTURAL_SYNTHETIC_ONLY','profitability':'NOT_TESTED','fills':'NOT_SIMULATED',
          'inputs_sha256':{str(x.relative_to(P)):sha(x) for x in code}})
    print(json.dumps({'status':'PASS_STRUCTURAL_ONLY','decisions':results,'algebra_rows':len(rows),'unit_log':'evidence/unit_tests_final.log'},indent=2))
if __name__=='__main__':main()
