"""Invented fixtures only. Weekday labels are a mock calendar, not certified sessions."""
import copy,json
from datetime import date,timedelta
from pathlib import Path
P=Path(__file__).resolve().parent

def fixture():
    end=date(2026,10,8); dates=[]
    while len(dates)<65:
        if end.weekday()<5: dates.append(end.isoformat())
        end-=timedelta(days=1)
    dates=list(reversed(dates))
    closes=[100.]*57+[100.,98.,96.,94.,93.,94.,95.,96.]
    def bars(closes,symbol):
        return [{'session':d,'close_at':d+'T20:00:00Z','available_at':d+'T20:01:00Z','revision_id':'initial',
                 'source_id':'INVENTED_'+symbol,'symbol':symbol,'security_id':'INVENTED_SECURITY' if symbol=='MOCK' else 'INVENTED_MARKET_SECURITY','frequency':'1d','adjustment':'PIT_SPLIT_ONLY',
                 'open':c,'high':c+1,'low':c-1,'close':c,'volume':2_000_000} for d,c in zip(dates,closes)]
    at='2026-10-09T14:00:00Z'
    def quote(cid,strike,delta,bid,ask,expiry='2026-11-13'):
        return {'contract_id':cid,'security_id':'INVENTED_SECURITY','underlying':'MOCK','right':'PUT','currency':'USD',
                'multiplier':100,'deliverable':'100_COMMON_SHARES','exercise_style':'AMERICAN','settlement':'PHYSICAL',
                'adjusted':False,'metadata_complete':True,'expiry':expiry,'exercise_cutoff':expiry+'T21:30:00Z',
                'last_trade_at':expiry+'T21:00:00Z','metadata_source':'INVENTED_METADATA','metadata_available_at':'2026-10-08T12:00:00Z',
                'quote_kind':'SYNTHETIC_BBO','observed_at':'2026-10-09T13:59:59Z','available_at':at,'source_id':'INVENTED_QUOTES',
                'condition':'REGULAR','halted':False,'strike':strike,'bid':bid,'ask':ask,'bid_size':10,'ask_size':10,
                'delta':delta,'iv':.35,'analytics_available_at':at,'analytics_observed_at':'2026-10-09T13:59:59Z',
                'analytics_model':'INVENTED_AMERICAN_MODEL','open_interest':1000,'oi_available_at':'2026-10-08T12:00:00Z','volume':200}
    return {'evidence':'SYNTHETIC_INVENTED','decision_at':at,'rights_verified':True,'calendar_verified':True,
            'calendar_source':'INVENTED_WEEKDAY_CALENDAR_NOT_REAL_EXCHANGE','regular_session':True,'universe_pit_verified':True,
            'market_symbol':'MARKET','market_security_id':'INVENTED_MARKET_SECURITY','security_id':'INVENTED_SECURITY','symbol':'MOCK','previous_verified_session':dates[-1],'expected_sessions':dates,
            'underlying_quote':{'symbol':'MOCK','security_id':'INVENTED_SECURITY','bid':95.99,'ask':96.01,'observed_at':'2026-10-09T13:59:59Z','available_at':at,'source_id':'INVENTED_STOCK_QUOTE','quote_kind':'SYNTHETIC_BBO','halted':False},'bars':bars(closes,'MOCK'),
            'market_bars':bars([100.]*65,'MARKET'),
            'volatility':{'symbol':'MOCK','security_id':'INVENTED_SECURITY','units':'ANNUAL_DECIMAL','horizon_days':30,'atm_iv':.35,'observed_at':'2026-10-09T13:59:59Z',
                          'available_at':at,'source_id':'INVENTED_IV','history':[{'session':d,'symbol':'MOCK','security_id':'INVENTED_SECURITY','value':.25,'observed_at':d+'T20:00:00Z','available_at':d+'T20:01:00Z','source_id':'INVENTED_IV','revision_id':'initial','vintage_verified':True} for d in dates]},
            'events':{'observed_at':at,'available_at':at,'source_id':'INVENTED_EVENTS','coverage_complete':True,
                      'revision_history':True,'coverage_through':'2026-11-30','items':[]},
            'portfolio':{'version':'INVENTED_PORTFOLIO_V1','available_at':at,'observed_at':at,'source_id':'INVENTED_PORTFOLIO','caps_pit_verified':True,'ownership_approved':True,
                         'common_budget':20000.,'available_cash':20000.,'max_loss_remaining':19000.,
                         'contingent_assignment_cash':19000.,'short_share_cap':500,'delta_share_remaining':200.,
                         'underlying_notional_remaining':30000.,'sector_notional_remaining':30000.,'gap_loss_remaining':19000.},
            'costs':{'version':'INVENTED_FEES_V1','available_at':at,'complete':True,'opening_per_leg':.65,'closing_per_leg':.65,'extra_slippage_per_leg':.10},
            'cash_rates':{'version':'INVENTED_SIMPLE_ACT365','available_at':at,'reserved':0.,'free':.03,'wait':.03},
            'chain':[quote('MOCK_P90',90.,-.225,1.50,1.60),quote('MOCK_P85',85.,-.10,.48,.50)]}

def main():
    f=fixture(); (P/'fixtures/base_synthetic.json').write_text(json.dumps(f,indent=2)+'\n')
    caution=copy.deepcopy(f)
    for i,b in enumerate(caution['market_bars']):
        c=100.-.07*i;b.update(open=c,high=c+1,low=c-1,close=c)
    (P/'fixtures/caution_synthetic.json').write_text(json.dumps(caution,indent=2)+'\n')
    blocked=copy.deepcopy(f);blocked['events']['coverage_complete']=False
    (P/'fixtures/unknown_events_synthetic.json').write_text(json.dumps(blocked,indent=2)+'\n')
if __name__=='__main__':main()
