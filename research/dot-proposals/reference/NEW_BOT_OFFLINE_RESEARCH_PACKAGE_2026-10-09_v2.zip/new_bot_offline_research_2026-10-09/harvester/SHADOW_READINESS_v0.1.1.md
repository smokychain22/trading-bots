# Market-open observation readiness

Verdict: OFFLINE_FORMAT_READY / LIVE_OBSERVATION_BLOCKED. No run was scheduled, no producer was accessed, and no broker/account/credential permission is implied. All capsules currently in fixtures/ are invented.

The first useful market-open result is a source-qualified observation/rejection receipt, not a trade. A safe bounded initial capture would cover at most five previously frozen liquid names, one 10:00 ET decision per name, the selected expiry and nearby short/long candidates (at most eight contracts/name), followed by 15:00 management observations on existing research episodes. This is a proposed future capture budget, not authorization to create an archive or subscribe to data. Observations must use already approved and entitled sources, or wait for approval.

## Required before a qualified capsule

1. Rights and actual entitlement for a real BBO source, rather than modified indicative prices. No broker/account credentials are to be requested by this prototype. Optionomics session analytics alone are insufficient for current executable quote assumptions.
2. Trusted exchange calendar and actual previous session; correctly available PIT daily adjusted OHLCV for at least 65 sessions for the security and broad-market reference. Official Optionomics price_history currently documents 60 sessions, below this prototype's 65-session minimum; a single response cannot silently satisfy it. Overlapping authenticated histories, if later authorized, require first-known/revision handling rather than retrospectively filled snapshots.
3. Archived first-known 30-day ATM IV definition, 60-session history, synchronized delta/model analytics, rates/dividends and adjustment metadata. IV history cannot be reconstructed from today's surface.
4. Explicit event coverage through expiry+3 calendar days, revision snapshots, earnings, macro, ex-dividend and corporate-action schedules, preserving information clocks.
5. Standard contract identity, exercise/last-trade deadlines and deliverables. Capture current underlying and option BBO with exchange/source timestamps and conditions; require synchronization. No assumption that displayed size equals executable package size.
6. A hypothetical research portfolio/capital mandate with caps and separate contingent assignment capacity. Do not pull real account state. Fee and cash-yield scenarios must be explicitly declared and distinguish modeled from known.
7. Trusted producer attestation and admission review. Boolean flags in a JSON file are not external proof of rights, source correctness or historical availability.
8. A separate native-package/close/assignment feasibility design for later replay. Current code is a receipt generator, not a fill simulator or full ledger replay.

## Read-only procedure after authorization and data qualification

At 09:35 ET verify calendars, rights, files and previous bar vintages; failures produce WAIT receipts with exact missing field. At 10:00 ET capture the bounded capsule including rejected contracts. Run python harvester.py capsule.json --output receipt.json, retain exact input/output/code hashes and as-of times. Never retry with future data while preserving the original decision timestamp. A later observation is a new receipt. At 15:00 ET capture only outstanding research episode observations, recording close signals without calling them fills.

Daily checks: original capsules immutable; no future availability; quote/underlying/IV synchronization; normalized units; source versions; rejected opportunities retained; option and stock liabilities retained after close signals. Stop observation promotion on a source/rights failure or schema drift; preserve already captured receipts.

First observation window: ten verified trading sessions can test coverage, staleness and rejection behavior only. Its end does not certify profitability. Subsequent lifecycle collection runs through every admitted episode's original common horizon. Profitability inference remains blocked until the preregistered OOS and tail-coverage requirements are met.

## Current admission decision

- Code and invented fixtures: available and locally testable.
- Qualified historical option episodes: 0.
- Qualified live observation capsules: 0.
- Existing UCI public data: weekly final-vintage underlying bars, rejected for this daily causal option design.
- Historical first-known events/IV/BBO and full assignment paths: absent.
- Provider eligibility/entitlement and native spread closeability: unverified.
- Scheduling, data collection, paper execution, live execution, publishing: not performed.
