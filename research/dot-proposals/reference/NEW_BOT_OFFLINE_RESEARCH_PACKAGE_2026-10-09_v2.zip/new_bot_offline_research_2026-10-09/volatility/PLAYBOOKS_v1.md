# Volatility Arbitrageur research prototypes v1

Status: **offline structural prototype, not a trading system or empirical finding**. Two candidate rules execute on invented inputs. Term, skew and event variants remain diagnostics/deferred. No market backtest, historical P&L, fill calibration, probability-of-profit estimate, broker action, registry admission or deployment is established. No 80% win-rate claim follows from delta, positive IV-minus-RV, or these tests.

## What is new and what is reused

The earlier `THETA_INCUBATOR_IV_INFORMATION_20261009_V2` asks whether ATM term IV adds physical-variance forecast information. This packet adds concrete candidate selection, synchronized-leg economics, risk-budget sizing, refusal reasons, exit signals and inventory-state oracles. It does not relabel that forecast experiment as profitable trading evidence.

Source-pinned THETA economics keeps gross credit, costs, maximum profit and unknown EV separate. Existing D research establishes that removing a protective long invalidates the original package loss bound. Both are preserved here. Production source is unchanged. These pure Python contracts are an offline handoff, not a competing router, execution engine, database model or canonical proposal. `execution_authorized` is always false; `canonical_validator_run` is always false. Native integration would require a separately reviewed typed adapter and existing THETA authority, lifecycle and risk gates.

## Common instrument and clock contract

- Initial instrument: SPY standard, unadjusted, American, physically settled options, multiplier 100 shares. No single-name extrapolation, adjusted deliverables, index-settlement substitution or calendar spreading.
- Decision: 15:30 America/New_York on full regular sessions, persisted as UTC seconds. Historical exchange calendar and series/venue schedule must be first-known by origin. Early-close origin rows remain in the ledger as excluded.
- Expiry: exact scheduled last-option-trade endpoint nearest 35 elapsed calendar days among 30–45 elapsed days; equal-distance tie picks earlier endpoint. Nearest maturity is selected before liquidity checks. An unavailable chosen series causes WAIT, not opportunistic fallback to another term.
- Quote/spot: observed within 2 seconds, first-available by decision, valid at decision, required option legs and ATM pair within a 1-second synchronization span. Strict positive bid, ask >= bid; per-leg absolute spread <= $0.20/share and relative spread <=20% of midpoint; positive integer displayed sizes. Qualification uses verified NBBO metadata, never an `executable=true` label alone. Sizes cap a hypothetical quantity, not a fill promise.
- Contracts retain identity, strike, maturity, model, provider, payload hash, first-known times, deliverable and quote class. IV is annual decimal volatility, delta signed unitless, gamma delta-change/$1 underlying, vega $/share per **one IV percentage point**. All are model outputs, not exercise probabilities.
- ATM IV proxy: mean call and put IV at the same nearest-forward strike of the chosen expiry, tie lower strike. Both types and a common documented American/dividend model are required. Forward/carry inputs must be source-vintaged, valid and available at origin; latest rate/dividend forecast curve must have valuation on origin or prior exchange session. Declared dividends may be older but need amendment coverage. The executable prototype trusts qualified carry/schedule attestations; it cannot authenticate them or fetch a calendar.
- An IV annualization label and model terminal must exactly match ACT/365 and the chosen target. Unknown conventions cause WAIT. Replacing SPY IV with VIX, `IV/sqrt(252)`, historical RV20, or another expiry is forbidden.
- Known CPI, FOMC decision, major scheduled macro release, SPY distribution/ex-date, corporate/series adjustment or market-closure event within the next two exchange sessions triggers embargo. Complete first-known coverage is required; unknown coverage causes WAIT. This is a conservative research choice, not a fitted event threshold. Unscheduled shocks remain possible.

## Causal physical variance forecast

For target [decision t, scheduled option terminal T], tau=(T−t)/(365×24×60×60). Realized price QV is the sum of squared log midpoint returns on a vintaged expected grid: 5-minute regular-session returns; exactly one regular-close-to-next-regular-open gap for each nonterminal night; and final 5-minute segments after regular close through the verified terminal cutoff if applicable. For a 16:15 terminal, the last three segments are 16:00–16:05, 16:05–16:10, 16:10–16:15. Do not count extended-session returns inside an already counted overnight gap. No next-open substitution or stale endpoint fill. Split-adjusted, price-only series retains ex-distribution price moves; this limits interpretation as diffusion variance.

Annual target Y=QV/tau. The executable `realized_qv` checks exact expected-grid equality, endpoint continuity, contemporaneous endpoint prices, first-availability and maturity. The grid itself must come from verified series/calendar history. Label availability is no earlier than every constituent arrival and computation completion. Missing grid data means unavailable label, not zero variance.

Each past session interval ends at min(15:30, that session's regular close), preserving shortened-session rows and exact elapsed calendar time. Need 22 contiguous complete intervals with matched prices and session indices. v_j=QV_j/tau_j. The feature `mean22_interval_annual_variance` is the equal-session arithmetic mean of these annualized interval variances, not pooled sum(QV)/sum(tau). Weekend-length intervals therefore have equal model weight but different ACT365 denominators. This is a predeclared modeling choice, not an assertion that the measures are equivalent. `ewma_forecast` implements normalized weights 0.94^i across the latest 22 v_j observations; its constant annual variance forecast over [t,T] implies expected QV=f×tau. It is a causal transparent **research baseline**, not claimed optimal or calibrated. The synthetic receipt uses deliberately constant 0.04 variance (20% volatility), demonstrating scale and horizon arithmetic.

The stronger HAR-plus-trend and HAR-plus-IV forecasting experiment remains the prior versioned design: 756 matured training rows, expanding refits every 21 exchange sessions, log-target OLS with training-only smearing, 252 development origins and >=504 holdout origins plus >=20 nonoverlapping target windows. Only training origins, completed targets and available labels preceding the fit can enter. A future implementation must seal solver/rank tolerance and reproduce that design; this packet does not claim to have fitted it. Empirical candidate input requires independently reviewed out-of-sample forecast lineage; the prototype's hash/status fields are necessary metadata, not validation by assertion.

Use these names precisely:
- ATM implied variance proxy = IV_ATM²
- forecast-relative variance gap = IV_ATM² − f
- matched total variance gap = (IV_ATM² − f)×tau

The first is not model-free risk-neutral integrated variance; their difference is not a measured variance-swap premium. Positive gap cannot determine put-spread or condor EV, because physical tails, skew, direction, path, assignment and costs matter. `expected_value_usd` and `profit_probability` stay null.

## Playbook 1: forecast-relative positive-gap put credit spread

Hypothesis: after cost and tail controls, selecting a defined-risk put spread when matched ATM implied variance exceeds a causal physical-variance forecast improves incremental whole-episode utility relative to simple price/IV controls and WAIT. The research name “forecast-relative VRP” is shorthand; the receipt explicitly says it is not true measured VRP.

1. Require common qualification above.
2. Regime: five-interval normalized momentum z5=log(P_t/P_(t−5))/sqrt(sum of the five QVs) >=−1, and latest annualized interval variance / mean last-22 annualized variances <=2. No dealer-position or sign inference.
3. Gap >=0.01 annual variance units and IV_ATM/sqrt(f) >=1.10. Thresholds are unoptimized v1 assumptions and must not be tuned on holdout. A positive 0.005 gap alone fails.
4. Select short OTM put with absolute delta 0.15–0.25 nearest 0.20, tie lower strike then contract ID. Buy same-expiry put exactly $5 lower. No ratio or uncovered residual leg. If that long is absent, WAIT; do not alter width or delta ad hoc.
5. Nominate only if the all-in roundtrip cost proxy / midpoint-entry credit <=25%, nominal intact-package risk budget fits, the gross assignment funding proxy fits, exposures fit, and displayed size fits. These checks are necessary research feasibility conditions, not positive EV.

Synthetic example only: short480P at bid1.30, long475P at ask0.50. Natural gross credit $80, modeled entry fee/slippage $3.30, net entry credit $76.70. Reserve another $3.30 for closing. Terminal intact loss bound with that reserve is $426.60; favorable terminal net P&L is $73.40. Entry midpoint credit $87.50; half-spread crossing $7.50; same-spread roundtrip implicit spread proxy $15 plus explicit costs $6.60, total $21.60. All-in cost ratio=24.6857%. Crossing is not subtracted again from the already natural-price P&L.

## Playbook 2: range-bound IV/RV-dislocation iron condor

Hypothesis: adding a matched defined-risk call credit wing improves risk-budget-normalized utility during objectively quiet/range-bound origins. Flat price action is an input filter, not evidence that the next month will stay flat.

1. Common maturity, quote, event and forecast rules identical to Playbook1.
2. Stricter regime: |z5|<=0.5 and latest variance / 22-interval mean <=1.25.
3. Same gap>=0.01 and IV/forecast-vol>=1.10 thresholds.
4. Put wing as above. Sell OTM call delta 0.15–0.25 nearest0.20, tie lower strike then ID; buy call exactly $5 higher. All four contracts share terminal, multiplier, underlying/deliverable, exercise and settlement. Short put <short call. Equal one-to-one quantities.
5. Equal $5 wings: terminal maximum intrinsic liability is **max(put width, call width)×100**, not sum of widths. Net credit subtracts from this terminal loss; both sides cannot be simultaneously in the money at one terminal stock price. This does not guarantee a synchronized close or prevent both sides losing in path-dependent management.

Synthetic four-leg example adds short520C1.30/long525C0.50. Gross credit $160; entry cost $6.60; net entry credit $153.40; close reserve $6.60. Intact terminal loss with reserve $353.20; favorable terminal net $146.80. Four-leg spread/fee exposure doubles; same proportional all-in cost proxy is 24.6857%. No fill at mid is assumed.

## Shared risk sizing and economics

Price/cost cash math uses Decimal USD. One structural unit is one contract of each leg. Explicit fee is $0.65/contract each way; additional adverse slippage is $0.01/share each way. Both are illustrative research assumptions, not a broker fee quote or empirical fill estimate. Natural bid/ask crossing is separately visible. The exit-spread proxy assumes current spreads persist solely for admission; actual stress close costs can be much larger.

Quantity=floor of the minimum allowed quantities across: five-unit hard cap; 0.5% equity per episode; 2% equity all-package risk; 1% equity SPY risk; 50% equity assignment-funding proxy; 20% equity gross absolute delta-dollars; 0.2% equity gross absolute vega $/vol-point; 0.1% equity gross absolute second-order 1% move gamma loss; and leg-side displayed sizes. Subtract all existing risk/reserves/pending obligations first. No diversification or cross-position Greek offset is presumed. Portfolio input must include Q/H/D/A/C or other simultaneous exposure if later integrated; no additional risk pool is created for this bot.

Gross funding proxy=sum(short strikes×100), including a deliberately conservative call-delivery funding proxy. It is not broker margin and does not make call assignment safe. A $100k invented portfolio can support one illustrated put spread under this proxy but zero illustrated condors. Actual share delivery, borrow, exercise cutoffs, liquidity and settlement reserves remain unresolved. Economic width-based risk and gross funding are different constraints.

Do not annualize maximum premium as expectancy or compound a 35-day credit yield. Report actual net cash P&L, capital-dollar-time, mark-to-liquidate tail exposure and reserve-release timestamps. Expected P&L remains unknown without a calibrated physical/path and execution model.

## Exits and execution limitations

Priority: assignment/exercise uncertainty → reconciliation; then mandatory close signal; then loss/profit signal; then hold diagnostic. Mandatory close when <=7 calendar DTE, held>=21 calendar days, or known embargo event approaching. Profit signal when hypothetical close net P&L reaches50% of the **original net entry credit**. Loss signal at loss of100% of that original credit (cost-inclusive close debit>=2×net entry credit). No roll, widening, averaging down, replacement new risk, or automatic stock disposal.

These are signals, not guaranteed exits or stop-loss bounds. A gap can skip the threshold. Missing close quotes cannot label the position closed. The separate function requires supplied cost-inclusive close debit; this packet does not produce authoritative closing orders.

Only synchronized complete package research fills may be credited. A native complex-order quote is preferable if independently authorized/available; leg NBBOs do not establish a complex fill. The offline prototype makes no order and has no assumed broker atomicity. Entry NO_FILL has zero credited cash and no position. Partial complete-package fill owns only confirmed filled packages; unbalanced entry belongs in existing reconciliation and cannot be modeled as a filled spread.

Partial complete-package close leaves remaining intact packages and retains exposure. Partial leg close, protective-long sale first, cancellation uncertainty, rejected short close or unresolved assignment blocks new risk/capital release. The state oracle reports BROKEN_HEDGE_RECONCILE or RECONCILE_BLOCK. It conservatively treats even a fully closed one-wing condor as needing exposure recomputation. Even when every leg is flat, a separate confirmed reserve-release receipt is required before capital_release_allowed can become true; the default is false. Recompute residual risk using canonical lifecycle; never carry the original loss bound forward automatically.

American assignment can occur before expiry, including while trading is halted. A long option does not automatically fund or exercise itself against short assignment. Short-call ex-dividend risk, deep-ITM put assignment, pin/contrary-exercise behavior and after-hours gaps need explicit episode accounting. Width-minus-credit is an intact same-deliverable terminal payoff bound, not a bound on arbitrary asynchronous share-delivery, financing or broken-hedge outcomes. The current prototype cannot certify those tails.

## Playbook 3: term structure / skew / event volatility

**Defer trading; retain executable diagnostics.** There is no defensible inference from a steep IV curve, a positive25-delta put-minus-call IV difference, or expected post-event IV crush to positive after-cost calendar/event EV. Different expiries expose intervening assignment, term/delta/vega changes and exercise/settlement mismatches. The current offline primitives do not supply a validated physical event-jump distribution or reliable multileg path fills.

- Term diagnostic uses W(T)=IV(T)^2×tau(T), then [W(T2)−W(T1)]/[tau(T2)−tau(T1)] at the same underlying and declared forward moneyness/model basis. It does not difference annual IV levels to call the result forward volatility. Negative result marks an inconsistent proxy; because ATM strike/moneyness can move and this is not model-free variance, it is not asserted to be a tradable arbitrage.
- Skew diagnostic requires same-expiry qualified put/call around absolute0.25 delta (±0.025), common IV model, matched observed clock; output is decimal IV difference. It does not translate skew into crash probability or a short-put edge.
- Event research requires first-known event revisions, same clock/basis surfaces before/after the event, physical jump calibration, carry/borrow, qualified complex execution, pathwise assignment and matched no-event controls. No event-volatility trade is nominated. Front-expiry expected move cannot silently label a1-day/5-day event forecast.

Reconsider only after these gaps are closed and a separate preregistered validation beats both simple filters and WAIT after costs and tail risk. Keeping an unsupported variant deferred is part of this result.

## Primary-source reading

Mechanics: [OIC put credit spread](https://www.optionseducation.org/strategies/all-strategies/bull-put-spread-credit-put-spread), [OIC assignment FAQ](https://www.optionseducation.org/referencelibrary/faq/options-assignment), and [Cboe Options Institute condor guide](https://www.fidelity.com/learning-center/investment-products/options/options-strategy-guide/short-iron-condor-spread). Variance conventions: [Cboe mathematics methodology](https://cdn.cboe.com/api/global/us_indices/governance/Cboe_Volatility_Index_Mathematics_Methodology.pdf). These references support mechanics and limitations; the rules, thresholds and synthetic calculations here are new research choices, not claims endorsed or validated by those organizations. Source access and prior-work hashes are in sources_v1.json and SOURCE_REUSE_v1.json.
