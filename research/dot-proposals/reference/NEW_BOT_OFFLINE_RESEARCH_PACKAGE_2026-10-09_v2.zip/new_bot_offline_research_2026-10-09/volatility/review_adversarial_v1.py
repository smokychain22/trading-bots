"""Independent offline review. No accounts, market downloads, execution or publication.

The main suite's invented market fixture supplies inputs only. Expected payoff,
budget and chronology assertions below are independently calculated. Run with:
python -m unittest -v review_adversarial_v1
"""
import math
import unittest
from dataclasses import replace
from decimal import Decimal as D

import volatility_prototype_v1 as v
from test_volatility_v1 import fixture


class IndependentReview(unittest.TestCase):
    def setUp(self):
        self.m, self.b = fixture()

    def reject_market(self, m, b=None):
        # An uncaught parsing error also fails this contract: nominations should
        # emit a fail-closed research receipt for malformed supplied evidence.
        r = v.nominate(m, self.b if b is None else b)
        self.assertEqual(r['status'], 'WAIT', r)
        self.assertEqual(r['quantity'], 0)
        self.assertIs(r['execution_authorized'], False)

    def mutate_quote(self, **kw):
        q = list(self.m.quotes)
        q[0] = replace(q[0], **kw)
        return replace(self.m, quotes=tuple(q))

    def test_truthy_false_pit_is_rejected(self):
        self.reject_market(replace(self.m, spot_stamp=replace(self.m.spot_stamp, pit='FALSE')))

    def test_unknown_event_coverage_is_rejected(self):
        self.reject_market(replace(self.m, event_coverage_complete='UNKNOWN'))

    def test_unknown_series_schedule_is_rejected(self):
        self.reject_market(replace(self.m, series_schedule_known='UNKNOWN'))

    def test_unknown_full_session_is_rejected(self):
        self.reject_market(replace(self.m, full_regular_session='UNKNOWN'))

    def test_none_delta_fails_closed(self):
        self.reject_market(self.mutate_quote(delta=None))

    def test_unhashable_iv_method_fails_closed(self):
        self.reject_market(self.mutate_quote(iv_method={'id': 'malformed'}))

    def test_decimal_forecast_variance_has_explicit_contract(self):
        # Decimal may be rejected or normalized, but never escape as mixed-type
        # arithmetic after being accepted by the generic numeric validator.
        f = replace(self.m.forecast, annual_variance=D('.04'))
        r = v.nominate(replace(self.m, forecast=f), self.b)
        self.assertIn(r['status'], ('WAIT', 'RESEARCH_CANDIDATE'))
        self.assertIs(r['execution_authorized'], False)

    def test_nan_strike_fails_closed(self):
        self.reject_market(self.mutate_quote(strike=D('NaN')))

    def test_none_forecast_hash_fails_closed(self):
        self.reject_market(replace(self.m, forecast=replace(self.m.forecast, model_hash=None)))

    def test_fractional_forecast_fit_clock_rejected(self):
        f = replace(self.m.forecast, fit_at=self.m.decision_at-.5,
                    latest_training_label_available_at=self.m.decision_at-1)
        self.reject_market(replace(self.m, forecast=f))

    def test_infinite_training_label_clock_rejected(self):
        f = replace(self.m.forecast, latest_training_label_available_at=float('-inf'))
        self.reject_market(replace(self.m, forecast=f))

    def test_nonfinite_derived_features_rejected_on_common_mask(self):
        rows = tuple(replace(r, qv=1e308) for r in self.m.intervals)
        r = v.nominate(replace(self.m, intervals=rows), self.b, arm='IV_ONLY')
        self.assertEqual(r['status'], 'WAIT', r)
        self.assertEqual(r['quantity'], 0)

    def test_nonhex_hash_rejected(self):
        self.reject_market(replace(self.m, forecast=replace(self.m.forecast, model_hash='z' * 64)))

    def test_none_provenance_hash_fails_closed(self):
        self.reject_market(replace(self.m, spot_stamp=replace(self.m.spot_stamp, payload_hash=None)))

    def test_nan_closed_cash_rejected(self):
        with self.assertRaises(v.Unqualified):
            v.lifecycle_oracle(1, [1, 1], D('NaN'))

    def test_infinite_close_cash_rejected(self):
        with self.assertRaises(v.Unqualified):
            v.lifecycle_oracle(1, [1, 1], D(80), D('Infinity'))

    def test_nonunit_leg_sides_rejected(self):
        legs = v.choose_legs(self.m.quotes, self.m.forecast.target_end, 'CONDOR', 500)
        legs = tuple((q, -2 if side < 0 else side) for q, side in legs)
        with self.assertRaises(v.Unqualified):
            v.economics(legs)

    def test_mismatched_terminal_economics_rejected(self):
        legs = list(v.choose_legs(self.m.quotes, self.m.forecast.target_end, 'PUT_SPREAD', 500))
        legs[1] = (replace(legs[1][0], terminal=self.m.forecast.target_end + 86400), 1)
        with self.assertRaises(v.Unqualified):
            v.economics(tuple(legs))

    def test_inverted_call_wing_rejected(self):
        short, long = self.m.quotes[2:4]
        long = replace(long, strike=short.strike - 5)
        with self.assertRaises(v.Unqualified):
            v.economics(((short, -1), (long, 1)))

    def test_put_and_call_credit_vertical_exact(self):
        for qs in (self.m.quotes[0:2], self.m.quotes[2:4]):
            legs = ((qs[0], -1), (qs[1], 1))
            econ = v.economics(legs)
            for spot in (0, 474, 475, 478, 480, 500, 520, 523, 525, 526, 10**8):
                raw = D(0)
                for q, side in legs:
                    intrinsic = max(D(0), q.strike - D(spot)) if q.kind == 'P' else max(D(0), D(spot) - q.strike)
                    raw += D(side) * 100 * intrinsic
                expected = D('80') - D('6.60') + raw
                self.assertEqual(v.package_terminal_pnl(legs, spot, econ), expected)
                self.assertGreaterEqual(expected, -D('426.60'))

    def test_asymmetric_condor_maximum_width_bound(self):
        short_put, long_put, short_call, long_call = self.m.quotes[:4]
        for put_width in (2, 5, 7, 20):
            for call_width in (2, 5, 7, 20):
                legs = ((short_put, -1), (replace(long_put, strike=short_put.strike-put_width), 1),
                        (short_call, -1), (replace(long_call, strike=short_call.strike+call_width), 1))
                e = v.economics(legs)
                expected_risk = D(max(put_width, call_width) * 100) - D('160') + D('13.20')
                self.assertEqual(e['intact_terminal_loss_with_cost_reserve_usd'], expected_risk)
                worst = min(v.package_terminal_pnl(legs, s, e) for s in (0, 470, 480, 500, 520, 530, 10**8))
                self.assertEqual(worst, -expected_risk)

    def test_exact_delta_vega_gamma_units(self):
        legs = v.choose_legs(self.m.quotes, self.m.forecast.target_end, 'PUT_SPREAD', 500)
        _, e = v.size_candidate(legs, v.economics(legs), self.b, 500)
        self.assertEqual(e['delta_dollars'], D(3500))
        self.assertEqual(e['vega_usd_per_vol_point'], D(4))
        self.assertEqual(e['gamma_loss_usd_one_pct'], D('2.5'))

    def test_each_budget_dimension_never_overspent(self):
        for shape in ('PUT_SPREAD', 'CONDOR'):
            legs = v.choose_legs(self.m.quotes, self.m.forecast.target_end, shape, 500)
            e = v.economics(legs)
            for equity in (10000, 100000, 1000000):
                b = replace(self.b, equity=D(equity))
                n, x = v.size_candidate(legs, e, b, 500)
                for per, frac in ((e['intact_terminal_loss_with_cost_reserve_usd'], v.POLICY.trade_risk_fraction),
                                  (e['gross_assignment_funding_proxy_usd'], v.POLICY.assignment_funding_fraction),
                                  (x['delta_dollars'], v.POLICY.delta_dollars_fraction),
                                  (x['vega_usd_per_vol_point'], v.POLICY.vega_fraction),
                                  (x['gamma_loss_usd_one_pct'], v.POLICY.gamma_fraction)):
                    self.assertLessEqual(n * per, D(equity) * frac)

    def test_any_partial_close_blocks_capital_release(self):
        for opened in (1, 2, 5):
            for a in range(opened+1):
                for b in range(opened+1):
                    r = v.lifecycle_oracle(opened, [a, b], D(80*opened), D(-20*(a+b)),
                                           reserve_release_confirmed=True)
                    self.assertEqual(r['capital_release_allowed'], a == b == opened)
                    if a != b:
                        self.assertIs(r['original_package_bound_valid'], False)

    def test_assignment_and_pending_cancel_never_release(self):
        for kw in ({'assignment_uncertain': True}, {'cancel_pending': True}):
            self.assertIs(v.lifecycle_oracle(2, [2, 2], reserve_release_confirmed=True,
                                             **kw)['capital_release_allowed'], False)

    def test_all_legs_flat_does_not_confirm_reserve_release(self):
        for closed in ([2, 2], [2, 2, 2, 2]):
            r = v.lifecycle_oracle(2, closed, D(160), D(-40))
            self.assertIs(r['all_option_legs_flat'], True)
            self.assertIs(r['reserve_release_confirmed'], False)
            self.assertIs(r['capital_release_allowed'], False)
            with self.assertRaises(v.Unqualified):
                v.lifecycle_oracle(2, closed, reserve_release_confirmed='TRUE')

    def test_no_execution_or_ev_in_any_arm(self):
        for shape in ('PUT_SPREAD', 'CONDOR'):
            for arm in ('WAIT', 'FORECAST_VRP', 'IV_ONLY', 'PRICE_ONLY', 'PRICE_PLUS_IV'):
                r = v.nominate(self.m, self.b, shape, arm)
                self.assertIs(r['execution_authorized'], False)
                self.assertIsNone(r['expected_value_usd'])
                self.assertIs(r['canonical_validator_run'], False)

    def qv_args(self, p0=100., p1=101.):
        start, end = 100, 400
        stamp = lambda t: v.Stamp(t, t, t+1, 'INVENTED_REVIEW_ENDPOINT', 'a'*64)
        seg = v.QVSegment(start, end, p0, p1, stamp(start), stamp(end), 'REGULAR_5M')
        return start, end, [seg], [(start, end, 'REGULAR_5M')], 500

    def test_realized_qv_exact_and_historical_validity(self):
        out = v.realized_qv(*self.qv_args())
        expected = math.log(101/100) ** 2
        self.assertAlmostEqual(out['qv'], expected, places=14)
        self.assertAlmostEqual(out['annual_variance'], expected * 365 * 86400 / 300, places=12)
        self.assertEqual(out['target_available_at'], 500)

    def test_realized_qv_fractional_stamp_rejected(self):
        args = list(self.qv_args())
        s = args[2][0]
        args[2] = [replace(s, start_stamp=replace(s.start_stamp, observed_at=99.5))]
        with self.assertRaises(v.Unqualified):
            v.realized_qv(*args)

    def test_realized_qv_overflow_never_accepted(self):
        try:
            out = v.realized_qv(*self.qv_args(1e-308, 1e308))
        except v.Unqualified:
            return
        self.assertTrue(math.isfinite(out['qv']))
        self.assertTrue(math.isfinite(out['annual_variance']))

    def test_realized_qv_underflow_never_uncaught(self):
        try:
            out = v.realized_qv(*self.qv_args(1e308, 1e-308))
        except v.Unqualified:
            return
        self.assertTrue(math.isfinite(out['qv']))

    def test_skew_mixed_evidence_rejected(self):
        put = replace(self.m.quotes[0], delta=-.25)
        call = replace(self.m.quotes[2], delta=.25, quote_class='VERIFIED_NBBO')
        with self.assertRaises(v.Unqualified):
            v.skew_diagnostic(put, call, self.m.decision_at)

    def test_term_math_independent_total_variance(self):
        t = self.m.decision_at
        r = v.term_diagnostic(.2, .3, t+30*86400, t+60*86400, t)
        self.assertAlmostEqual(r['forward_variance_proxy'], (.09*60-.04*30)/30, places=14)


if __name__ == '__main__':
    unittest.main(verbosity=2)
