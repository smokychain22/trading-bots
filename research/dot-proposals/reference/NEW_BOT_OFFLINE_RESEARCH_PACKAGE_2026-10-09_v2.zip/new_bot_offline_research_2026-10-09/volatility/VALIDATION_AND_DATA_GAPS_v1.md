# Validation plan, provider boundaries and market-open requirements

## Current result and claim boundary

No qualified market observations were acquired for these new strategies. Input prices, IV, QV, displayed sizes, portfolio and cash flows are invented. Executable mechanics and adversarial tests are structural evidence only. The run cannot establish expectancy, a return distribution, 80% wins, assignment incidence, actual slippage, market capacity or a deployment-ready configuration. No strategy is added to the current THETA registry.

## Same-origin controls

For each shape, compare FORECAST_VRP against PRICE_ONLY, IV_ONLY, PRICE_PLUS_IV and WAIT.

- Price-only uses that shape's exact z5/RV-expansion filter.
- IV-only uses ATM IV>=0.20; it does not sneak in the forecast-relative gap or price filter.
- Price-plus-IV uses both transparent filters.
- FORECAST_VRP uses the playbook price filter and matched forecast gap/ratio.
- WAIT opens nothing and earns zero incremental trading P&L in the primary cash benchmark. Report separately an opportunity-cost comparison using only a qualified, already-known cash rate; missing rate does not become a fictional Treasury yield.

All non-WAIT arms require the same forecast, ATM pair, series metadata, interval features, quote quality, event coverage, cost policy and whole-portfolio budget, even when an arm does not use a qualified feature in its signal. Thus the primary paired estimand does not conflate forecast coverage with selection. Report a secondary practical-coverage analysis separately, never silently allow the simple arm a different dataset in the primary comparison. WAIT is present on every ledger row and needs no quotes; score paired comparisons on the predeclared common eligibility mask while also reporting the whole-calendar ledger. It receives the same comparison horizon and cash/risk starting budget.

Candidate construction, expiry/strike tie breaks, side crossing, fee assumptions, position size, closure policy and embargo are frozen across signal arms. Each arm has a separate counterfactual ledger starting from the same capital; its own earlier actions consume risk budget. Do not reuse the challenger's freed cash selectively for a control, or compare unlimited per-trade bets. Daily signals do not imply unlimited overlapping entries.

## Walk-forward and leakage controls

1. Preserve the prior forecast experiment: >=756 matured training labels, 252 development origins, >=504 untouched future holdout origins, >=20 greedy nonoverlapping expiry windows. These are minimum sample gates, not sufficient statistical power. Need calendar coverage in addition to complete cases. The newly implemented EWMA22 is a simple benchmark; HAR fitting is not implemented here.
2. Seal dataset start, development/holdout boundary, fit schedule, candidate/exit thresholds, strategies, exclusions, cost assumptions and inference before inspecting strategy holdout outcomes. Fit any model only on earlier-origin targets whose endpoint and first-label availability are <=fit cutoff. Overlapping future labels cannot enter training early.
3. Refit expanding forecast models only on the predeclared 21-session schedule. Earlier holdout labels may enter later prequential fits only after they mature; holdout P&L may not select thresholds, models or exclusions. No random train/test split across overlapping option lives. If model/threshold selection is added, nest it inside a training-only walk-forward and record a new version.
4. Each full calendar origin retains eligibility/rejection reasons, all candidate IDs, selected/fallback/no-trade result, source hashes, available-at times, no-fill/partial-fill state, exposure and timing. Retain excluded and early-close rows for lag arithmetic and coverage. Missing data are not zero or removed to create adjacent sessions.
5. Mark outcomes to a common prespecified evaluation endpoint. The normal policy attempts mandatory exit after21 elapsed days or by7 DTE, whichever is earlier. A failed exit remains a liability; it does not create a closed winner. Align paired wealth at the common endpoint using qualified liquidation marks for all residuals and then follow actual liability reconciliation separately. If mark/reconciliation is unavailable, report censored outcome and conservative bounds; do not discard failed losers or call them zero. Report time-to-liquidation and capital-dollar-time through actual reserve release.

## Economic and tail metrics

Primary hypothesis per shape: incremental net common-budget terminal wealth versus PRICE_PLUS_IV, including all explicit/implicit costs and conservatively valued residual liabilities. To retain a strategy, lower95% paired confidence bound on improvement must be positive, and it must beat WAIT after costs with acceptable tail loss. Predeclare a tail noninferiority limit before market data; absent that owner-approved research limit, no graduation decision can be made. Other controls are secondary. Neither higher hit rate nor higher raw premium is sufficient.

Report full net P&L distribution, drawdown, mean loss/mean win, expected shortfall with uncertainty, worst gap stress, assignment/borrow/financing and forced-close costs, net return per capital-dollar-day, entry/close no-fill rates, fill-conditioned versus intention-to-trade outcomes, active exposure, event stratum outcomes and censored/residual inventory counts. Do not estimate reliable 1% expected shortfall from a handful of episodes. A high win rate can coexist with negative expectancy; maintain numerator/denominator for fully reconciled whole episodes and count pending episodes separately.

Inference: paired moving blocks of63 consecutive exchange-calendar session rows, 2000 draws, seed20261009, preserving all arms and missingness within each block. Do not compress to63 successful trades. Group entire expiry/episode and overlapping liability exposure, with expiry-cluster and nonoverlapping-origin sensitivity. State block/effective sample counts and widen/withhold claims when clusters are scarce. Apply Holm adjustment across the two primary shape comparisons. Blocks are a design choice to test via longer-block sensitivity, not an independence proof. Report results by fixed trend/RV/event strata without post-hoc discovery claims.

For forecast information itself, retain paired QLIKE Y/f−log(Y/f)−1, variance MSE and calibration. Improved QLIKE is not automatically improved option P&L. Physical distribution, skew, tail and fill validation is a separate gate.

## Concrete data gaps and provider refusal rules

1. No complete PIT 5-minute SPY midpoint grid, terminal post-close grid, long history of first-seen timestamps, historical source rights or revision vintages. Daily OHLC cannot substitute for the declared QV label.
2. No qualified same-clock, same-maturity ATM/wing chain, American-model IV conventions, rate/dividend forecast vintages, historical series schedule or NBBO execution-quality evidence. Public end-of-day VIX is an aggregate index, not a SPY option chain or matched forecast label.
3. No validated physical tail/event model or OOS forecast-calibration receipt. A self-written status/hash cannot certify predictive accuracy. Real-data nomination is therefore not presently demonstrated.
4. No order-book queue/fill process, complex-order quotes, firm executable sizes, cancel/replace latency or partial close reconciliation. Natural prices are conservative deterministic scenarios, not fills.
5. No broker/account/credential access, fee schedule, margin, exercise cutoff, assignment cash/share ledger, borrow/financing reserve or correlated live-portfolio snapshot. None is requested or accessed by this packet.
6. Optionomics documentation says session-ingested research/analytics, not realtime execution. Its historical quote response carries a **live** regime even when an earlier date is requested. Never import that regime as historical PIT. Numeric IV strings are decimal; `iv_per_trading_day=IV/sqrt(252)` does not establish ACT365 total variance. Null legacy VRP is unknown, not zero. A zero GEX field may be missing calculation, not neutral dealer exposure. Front-expiry expected move and fixed-session forecasts need separate horizon and provenance. These fields are not used by this prototype.
7. Alpaca indicative modified quotes cannot become verified NBBO by `executable=true`. The offline qualifier explicitly rejects INDICATIVE_MODIFIED and SESSION_RECORDED_RESEARCH. No entitlement purchase or authenticated API was made. Provider metadata never proves realized fill quality.

## Market-open shadow evaluation checklist (requires qualified lawful inputs)

Before a future shadow observation, verify rights and source availability, without purchases or access expansion under this authorization. Freeze the decision/series clock and collect only the small required snapshot: SPY quote, candidate and ATM legs, rate/dividend/event provenance, 22 complete feature intervals and a qualified forecast with exact target. Preserve actual observed/first-available timestamps, payload hash, model convention and all refusal reasons. Do not fabricate a missing timestamp from retrieval time.

Run offline nomination on the frozen snapshot; record candidate and all simple-arm alternatives plus WAIT in the same budget ledger. Canonical THETA T0 and candidate identity/economics can be referenced only through a later reviewed adapter. A research receipt cannot authorize a live or Paper opening, new management action or mutation of AEGIS/sizing. Absent feed, forecast, schedule or event qualification, the correct market-open output remains WAIT with a concrete reason.

To assess hypothetical execution, record naturally observed subsequent qualified quotes under a preregistered fill model and bounds. Do not claim that touching a limit implies fill. No order submission, free paper account creation, credential entry or broker mutation is authorized here. Shadow receipts should include spread widening, disappearance, no-fill, complete-package partial size, asymmetric close, assignment stress and reserve release. This collection is a requirement list, not an active monitor or promise to gather unavailable data.

## Reuse map to canonical THETA

- Reuse underlying/option identity, multiplier, signed positions, source and PIT evidence concepts.
- Reuse canonical opening-cost and candidate economics without overwriting net EV with credit. Actual package/close costs require their own verified units and lineage.
- Reuse existing AEGIS, account inventory, portfolio sizing, order lifecycle and D assignment/partial-close handling when separately integrated; never bypass them with this standalone risk budget.
- Do not map gap to generic IV or cost fraction to LIQUIDITY. The inspected Dot scalar consumer does not automatically verify those derived semantics or per-candidate relationships.
- Preserve the exact prior forecast design and D lifecycle oracles as reference; no repeated synthetic checks are added to historical counts and no prior claimed performance is inherited.

Provider limitations were checked against the public [Optionomics API reference](https://www.optionomics.ai/docs/api) and [Alpaca options-data documentation](https://docs.alpaca.markets/us/docs/historical-option-data) on2026-10-09. [Cboe's public index history page](https://www.cboe.com/tradable-products/vix/vix-historical-data) describes index closing data, which cannot fill the contract-level quote gap. No account or authenticated data request was made.
