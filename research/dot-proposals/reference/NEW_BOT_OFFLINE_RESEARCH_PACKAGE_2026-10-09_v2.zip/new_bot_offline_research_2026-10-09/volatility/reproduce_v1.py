#!/usr/bin/env python3
"""Run only local stdlib mechanics/tests and write auditable structural receipts. No network."""
from pathlib import Path
from dataclasses import asdict,fields,replace
from decimal import Decimal
import hashlib,io,json,platform,unittest
import volatility_prototype_v1 as v
from test_volatility_v1 import fixture
ROOT=Path(__file__).resolve().parent

def serial(x):
    if isinstance(x,Decimal): return str(x)
    raise TypeError(type(x).__name__)

def write(name,obj):
    (ROOT/name).write_text(json.dumps(obj,default=serial,sort_keys=True,indent=2,allow_nan=False)+'\n')

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()

m,b=fixture()
write('fixture_inputs_v1.json',{'evidence_class':'INVENTED_STRUCTURAL_INPUTS','market':asdict(m),'budget':asdict(b),'all_sources_are_fixture_labels_not_real_feeds':True})
contract={'id':v.VERSION,'status':'RESEARCH_ONLY_OFFLINE_NOT_CANONICAL_PROPOSAL','version':1,
 'units':{'timestamps':'integer Unix UTC seconds','price':'Decimal USD per share','money':'Decimal USD','iv':'annual decimal volatility ACT365','variance':'annualized squared log-return QV ACT365','qv':'dimensionless sum squared log returns','delta':'signed unitless','gamma':'delta change per USD','vega':'USD/share per ONE IV percentage point','position':'integer equal packages; 100-share standard deliverable'},
 'policy':asdict(v.POLICY),
 'dataclass_fields':{c.__name__:{f.name:str(f.type) for f in fields(c)} for c in (v.Stamp,v.Interval,v.Forecast,v.Quote,v.Market,v.Budget,v.QVSegment)},
 'closed_states':['NO_FILL','OPEN_INTACT','PARTIAL_CLOSE_INTACT','BROKEN_HEDGE_RECONCILE','RECONCILE_BLOCK','CLOSED'],
 'shape_ids':['PUT_SPREAD','CONDOR'],'signal_arms':['FORECAST_VRP','PRICE_ONLY','IV_ONLY','PRICE_PLUS_IV','WAIT'],
 'source_document':'PLAYBOOKS_v1.md','validation_document':'VALIDATION_AND_DATA_GAPS_v1.md',
 'trust_boundary':'Typed supplied attestations and hashes are necessary only; prototype does not authenticate provider/calendar/forecast-validation claims.',
 'unsupported':['live or paper orders','registry mutation','forecast fit calibration','empirical positive EV','assignment pricing','complex fill simulation','adaptive threshold optimization'],
 'code_sha256':digest(ROOT/'volatility_prototype_v1.py')}
write('contracts_v1.json',contract)
scenarios={
 'eligible_invented':(m,b),
 'missing_forecast':(replace(m,forecast=None),b),
 'mismatched_forecast_terminal':(replace(m,forecast=replace(m.forecast,target_end=m.forecast.target_end+1)),b),
 'unknown_event_coverage':(replace(m,event_coverage_complete=False),b),
 'event_embargo':(replace(m,high_impact_event_within_2_sessions=True),b),
 'negative_variance_gap':(replace(m,forecast=replace(m.forecast,annual_variance=.10)),b),
 'indicative_not_bbo':(replace(m,quotes=tuple(replace(q,quote_class='INDICATIVE_MODIFIED',executable_flag=True) for q in m.quotes)),b),
 'small_funding_budget':(m,replace(b,equity=Decimal(100000))),
}
rows=[]
for scenario,(market,budget) in scenarios.items():
    for shape in contract['shape_ids']:
        for arm in contract['signal_arms']:
            rows.append({'scenario':scenario,'origin':market.decision_at,'common_comparison_target':m.forecast.target_end,
                         'initial_equity_usd':str(budget.equity),'result':v.nominate(market,budget,shape,arm)})
write('synthetic_nomination_receipts_v1.json',{'classification':'STRUCTURAL_SYNTHETIC','market_observations':0,'scenario_count':len(scenarios),'rows':rows})
write('lifecycle_diagnostics_v1.json',{'classification':'STRUCTURAL_SYNTHETIC','states':{
 'no_fill':v.lifecycle_oracle(0,[0,0]),
 'partial_intact':v.lifecycle_oracle(2,[1,1],Decimal('153.40'),Decimal('-40')),
 'protective_long_removed':v.lifecycle_oracle(1,[0,1]),
 'assignment_uncertain':v.lifecycle_oracle(1,[1,1],assignment_uncertain=True),
 'full_close_pending_reserve_release':v.lifecycle_oracle(1,[1,1],Decimal('76.70'),Decimal('-40')),
 'full_close_released':v.lifecycle_oracle(1,[1,1],Decimal('76.70'),Decimal('-40'),reserve_release_confirmed=True)},
 'term':v.term_diagnostic(.2,.3,m.decision_at+30*86400,m.decision_at+60*86400,m.decision_at),
 'skew':v.skew_diagnostic(replace(m.quotes[0],delta=-.25,iv=.35),replace(m.quotes[2],delta=.25),m.decision_at)})
checks=[]
for module in ('test_volatility_v1','review_adversarial_v1'):
    suite=unittest.defaultTestLoader.loadTestsFromName(module)
    stream=io.StringIO(); result=unittest.TextTestRunner(stream=stream,verbosity=0).run(suite)
    checks.append({'module':module,'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'passed':result.wasSuccessful(),'source_sha256':digest(ROOT/(module+'.py'))})
    if not result.wasSuccessful(): print(stream.getvalue())
receipt={'schema':'theta.incubator.volatility.reproduction.v1','classification':'STRUCTURAL_SYNTHETIC','python':platform.python_version(),
 'test_suites':checks,'passed':all(c['passed'] for c in checks),'unit_test_methods':sum(c['tests_run'] for c in checks),
 'synthetic_scenarios':len(scenarios),'synthetic_signal_rows':len(rows),'market_observations':0,'forecast_fits':0,'historical_backtests':0,'broker_fills':0,'orders':0,
 'canonical_validator_run':False,'publication_performed':False,'performance_claim':'NONE','reticle':'NOT_APPLICABLE_OFFLINE_CLI_NO_UI',
 'source_hashes':{f:digest(ROOT/f) for f in ['volatility_prototype_v1.py','test_volatility_v1.py','review_adversarial_v1.py','contracts_v1.json','fixture_inputs_v1.json','reproduce_v1.py']},
 'interpretation':'Unit methods contain subcase loops; counts are not independent observations. Original61 output retained, not added to final count.'}
write('reproduction_receipt_v1.json',receipt)
public_names=[
 'README.md','PLAYBOOKS_v1.md','VALIDATION_AND_DATA_GAPS_v1.md','volatility_prototype_v1.py','test_volatility_v1.py',
 'review_adversarial_v1.py','reproduce_v1.py','contracts_v1.json','fixture_inputs_v1.json',
 'synthetic_nomination_receipts_v1.json','lifecycle_diagnostics_v1.json','reproduction_receipt_v1.json',
 'sources_v1.json','SOURCE_REUSE_v1.json','review_combined_final_results.txt','review_adversarial_final_results.txt','review_receipt_v1.json','REVIEW_HISTORY_PUBLIC_v1.json','clean_reproduction_receipt_v1.json']
public_files={n:{'sha256':digest(ROOT/n),'bytes':(ROOT/n).stat().st_size} for n in public_names if (ROOT/n).is_file()}
review_current=False
if (ROOT/'review_receipt_v1.json').is_file():
    review=json.loads((ROOT/'review_receipt_v1.json').read_text())
    review_current=all((ROOT/n).is_file() and digest(ROOT/n)==h for n,h in review.get('sha256',{}).items())
write('PUBLIC_SAFE_MANIFEST_v1.json',{'schema':'theta.incubator.volatility.public_safe.v1','relative_reproduction_entrypoint':'python3 reproduce_v1.py',
 'classification':'STRUCTURAL_SYNTHETIC','publication_authorized':False,'final_review_hashes_current':review_current,
 'explicit_whitelist':public_files,'exclusions':['all unlisted files','raw failure/retest logs with machine paths','owner brief and account data','parent workspace paths','production source copies','credentials','__pycache__'],
 'private_historical_logs_preserved_locally':True,'manifest_excludes_itself':True})
manifest={p.name:{'sha256':digest(p),'bytes':p.stat().st_size} for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='MANIFEST_SHA256_v1.json'}
write('MANIFEST_SHA256_v1.json',{'schema':'theta.incubator.volatility.manifest.v1','files':manifest,'manifest_excludes_itself':True})
print(json.dumps({'passed':receipt['passed'],'test_methods':receipt['unit_test_methods'],'synthetic_signal_rows':len(rows),'market_observations':0,'artifact_dir':str(ROOT)},indent=2))
raise SystemExit(0 if receipt['passed'] else 1)
