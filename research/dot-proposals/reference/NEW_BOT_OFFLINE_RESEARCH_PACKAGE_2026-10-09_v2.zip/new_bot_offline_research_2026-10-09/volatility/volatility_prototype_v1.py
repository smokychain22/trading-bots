"""Offline, stdlib-only research nomination and exact payoff oracles. No execution API.
All defaults are preregistered research choices, not empirically optimal parameters.
"""
from dataclasses import dataclass, replace
from decimal import Decimal as D
from math import isfinite, log, sqrt, floor
from typing import Optional

VERSION = 'theta.incubator.volatility.v1'
YEAR_SECONDS = 365 * 24 * 60 * 60
DAY_SECONDS = 86400

class Unqualified(ValueError):
    pass

def require(ok, reason):
    if not ok:
        raise Unqualified(reason)

def finite(x):
    try:
        return isinstance(x, (int, float, D)) and not isinstance(x, bool) and isfinite(x)
    except (TypeError, ValueError, OverflowError):
        return False

def hash_ok(x):
    return isinstance(x,str) and len(x)==64 and all(c in '0123456789abcdef' for c in x)

def boolean(x):
    return type(x) is bool

def decimal(x):
    require(finite(x), 'NONFINITE_NUMBER')
    return D(str(x))

def tau(start, end):
    require(type(start) is int and type(end) is int and end > start, 'BAD_CLOCK')
    return (end - start) / YEAR_SECONDS

@dataclass(frozen=True)
class Stamp:
    observed_at: int
    available_at: int
    valid_until: int
    source: str
    payload_hash: str
    pit: bool = True
    def check(self, decision, max_age=None):
        require(all(type(x) is int for x in (self.observed_at,self.available_at,self.valid_until)), 'CLOCK_TYPE')
        require(self.pit is True and self.observed_at <= self.available_at <= decision < self.valid_until, 'PIT_INVALID')
        require(isinstance(self.source,str) and bool(self.source) and hash_ok(self.payload_hash), 'PROVENANCE_MISSING')
        if max_age is not None:
            require(decision-self.observed_at <= max_age, 'STALE_QUOTE')

@dataclass(frozen=True)
class Interval:
    session_index: int
    start: int
    end: int
    qv: float                         # sum of squared log price returns; dimensionless
    start_price: float
    end_price: float
    stamp: Stamp
    complete: bool = True
    def variance(self):
        return self.qv / tau(self.start,self.end)

@dataclass(frozen=True)
class Forecast:
    decision_at: int
    target_end: int
    annual_variance: float
    method: str
    fit_at: int
    latest_training_label_available_at: int
    stamp: Stamp
    qualification: str               # SYNTHETIC_FIXTURE or PIT_VALIDATED_RESEARCH
    model_hash: str
    validation_receipt_hash: Optional[str]
    basis: str = 'ACT365_PRICE_QV'

@dataclass(frozen=True)
class Quote:
    contract_id: str
    kind: str
    strike: D
    terminal: int
    bid: D
    ask: D
    bid_size: int
    ask_size: int
    delta: float
    gamma: float                    # change of delta per USD underlying
    vega: float                     # USD/share per one percentage-point IV increase
    iv: float                       # annual decimal volatility
    stamp: Stamp
    multiplier: int = 100
    underlying: str = 'SPY'
    deliverable: str = '100_SPY_SHARES'
    exercise: str = 'AMERICAN'
    settlement: str = 'PHYSICAL'
    iv_basis: str = 'ACT365'
    iv_terminal: Optional[int] = None
    iv_method: str = 'DECLARED_AMERICAN_MODEL_V1'
    quote_class: str = 'SYNTHETIC_FIXTURE'
    executable_flag: bool = False    # informational only; never upgrades quote_class
    def check(self, decision):
        self.stamp.check(decision,2)
        require(self.kind in ('P','C') and isinstance(self.contract_id,str) and bool(self.contract_id) and type(self.terminal) is int, 'BAD_CONTRACT')
        require(self.underlying == 'SPY' and type(self.multiplier) is int and self.multiplier == 100 and self.deliverable == '100_SPY_SHARES', 'DELIVERABLE_UNSUPPORTED')
        require(self.exercise == 'AMERICAN' and self.settlement == 'PHYSICAL', 'SERIES_UNSUPPORTED')
        require(all(finite(x) for x in (self.strike,self.bid,self.ask,self.delta,self.gamma,self.vega,self.iv)), 'NONFINITE_QUOTE')
        require(self.strike>0 and 0 < self.bid <= self.ask, 'CROSSED_OR_ZERO_QUOTE')
        require(type(self.bid_size) is int and type(self.ask_size) is int and min(self.bid_size,self.ask_size)>0, 'SIZE_UNAVAILABLE')
        require((self.kind=='P' and -1<=self.delta<=0) or (self.kind=='C' and 0<=self.delta<=1), 'DELTA_UNITS')
        require(all(isinstance(x,(int,float)) and not isinstance(x,bool) for x in (self.iv,self.delta,self.gamma,self.vega)), 'GREEK_NUMERIC_TYPE')
        require(0 < self.iv <= 5 and self.gamma>=0 and self.vega>=0, 'GREEK_UNITS')
        require(self.iv_basis=='ACT365' and self.iv_terminal == self.terminal and isinstance(self.iv_method,str) and bool(self.iv_method), 'IV_HORIZON_OR_METHOD_MISMATCH')
        require(self.quote_class in ('SYNTHETIC_FIXTURE','VERIFIED_NBBO'), 'NOT_BBO_RESEARCH_ONLY')
        require(self.ask-self.bid <= D('.20') and (self.ask-self.bid)/((self.ask+self.bid)/2) <= D('.20'), 'ILLIQUID_LEG')

@dataclass(frozen=True)
class Market:
    decision_at: int
    spot: float
    forward: float
    spot_stamp: Stamp
    carry_stamp: Stamp
    intervals: tuple
    quotes: tuple
    forecast: Optional[Forecast]
    event_stamp: Stamp
    high_impact_event_within_2_sessions: bool
    event_coverage_complete: bool
    series_schedule_known: bool
    full_regular_session: bool
    synthetic: bool = True

@dataclass(frozen=True)
class Budget:
    equity: D
    used_package_risk: D
    used_underlying_risk: D
    used_assignment_funding: D
    absolute_delta_dollars: D
    absolute_vega_dollars_per_vol_point: D
    absolute_gamma_loss_one_pct: D
    # Gross absolute aggregation is conservative: no assumed offsets between positions.

@dataclass(frozen=True)
class Policy:
    width: D = D('5')
    fee_per_leg_each_way: D = D('.65')
    slippage_per_share_each_way: D = D('.01')
    variance_gap: float = .01
    iv_to_forecast_vol: float = 1.10
    roundtrip_cost_fraction: D = D('.25')
    trade_risk_fraction: D = D('.005')
    portfolio_risk_fraction: D = D('.02')
    underlying_risk_fraction: D = D('.01')
    assignment_funding_fraction: D = D('.50')
    delta_dollars_fraction: D = D('.20')
    vega_fraction: D = D('.002')
    gamma_fraction: D = D('.001')
    contracts_cap: int = 5

POLICY=Policy()

def interval_features(m):
    rows=m.intervals
    require(len(rows)==22, 'NEED_22_COMPLETE_INTERVALS')
    for i,r in enumerate(rows):
        r.stamp.check(m.decision_at)
        require(r.complete is True and type(r.start) is int and type(r.end) is int and r.end <= m.decision_at and r.start<r.end and r.stamp.observed_at>=r.end, 'INTERVAL_INCOMPLETE_OR_FUTURE')
        require(all(finite(x) and x>0 for x in (r.qv,r.start_price,r.end_price)), 'BAD_INTERVAL')
        require(type(r.session_index) is int, 'SESSION_INDEX_INVALID')
        if i:
            require(r.session_index==rows[i-1].session_index+1 and r.start==rows[i-1].end and r.start_price==rows[i-1].end_price, 'MISSING_SESSION_OR_ENDPOINT')
    require(rows[-1].end==m.decision_at, 'FEATURE_ENDPOINT_MISMATCH')
    require(rows[-1].end_price==m.spot,'SPOT_FEATURE_ENDPOINT_MISMATCH')
    v=[r.variance() for r in rows]
    require(all(finite(x) and x>0 for x in v),'NONFINITE_INTERVAL_VARIANCE')
    mean=sum(x/22 for x in v); q5=sum(r.qv for r in rows[-5:])
    require(finite(mean) and mean>0 and finite(q5) and q5>0,'NONFINITE_FEATURE_AGGREGATE')
    z5=(log(rows[-1].end_price)-log(rows[-5].start_price))/sqrt(q5)
    ratio=v[-1]/mean
    require(finite(z5) and finite(ratio),'NONFINITE_REGIME_FEATURE')
    return {'mean22_interval_annual_variance':mean,'rv1_rv22_ratio':ratio, 'z5':z5}

def ewma_forecast(m, terminal):
    """Concrete causal simple forecast. Not fitted HAR, validated EV or calibrated tail law."""
    interval_features(m)
    weights=[.94**i for i in range(22)]
    value=sum(w*r.variance() for w,r in zip(weights,reversed(m.intervals)))/sum(weights)
    require(finite(value) and value>0,'NONFINITE_EWMA_FORECAST')
    available=max(r.stamp.available_at for r in m.intervals)
    stamp=Stamp(m.decision_at,available,m.decision_at+1,'EWMA22_INPUT_LEDGER','e'*64)
    return Forecast(m.decision_at,terminal,value,'EWMA22_ACT365_V1',m.decision_at,available,stamp,
                    'SYNTHETIC_FIXTURE' if m.synthetic else 'UNVALIDATED', 'f'*64,None)

def choose_legs(quotes, terminal, shape, spot, policy=POLICY):
    pool=[q for q in quotes if q.terminal==terminal]
    puts=[q for q in pool if q.kind=='P' and q.strike<decimal(spot) and .15<=abs(q.delta)<=.25]
    require(puts,'NO_SHORT_PUT')
    sp=min(puts,key=lambda q:(abs(abs(q.delta)-.20),q.strike,q.contract_id))
    lp=[q for q in pool if q.kind=='P' and q.strike==sp.strike-policy.width]
    require(len(lp)==1,'NO_UNIQUE_PUT_WING')
    legs=[(sp,-1),(lp[0],1)]
    if shape=='CONDOR':
        calls=[q for q in pool if q.kind=='C' and q.strike>decimal(spot) and .15<=q.delta<=.25]
        require(calls,'NO_SHORT_CALL')
        sc=min(calls,key=lambda q:(abs(q.delta-.20),q.strike,q.contract_id))
        lc=[q for q in pool if q.kind=='C' and q.strike==sc.strike+policy.width]
        require(len(lc)==1 and sp.strike<sc.strike,'NO_UNIQUE_CALL_WING')
        legs.extend([(sc,-1),(lc[0],1)])
    return tuple(legs)

def economics(legs, policy=POLICY):
    validate_package(legs)
    validate_policy(policy)
    n=len(legs); mult=D(100)
    gross=sum((q.bid if side<0 else -q.ask)*mult for q,side in legs)
    one_way=D(n)*(policy.fee_per_leg_each_way + policy.slippage_per_share_each_way*mult)
    require(gross>0,'NONPOSITIVE_CREDIT')
    widths=[abs(legs[0][0].strike-legs[1][0].strike)]
    if n==4: widths.append(abs(legs[2][0].strike-legs[3][0].strike))
    require(gross<max(widths)*mult,'CREDIT_EXCEEDS_WIDTH')
    net=gross-one_way
    risk=max(widths)*mult-net+one_way
    funding=sum(q.strike*mult for q,s in legs if s<0) # intentionally includes call delivery funding proxy
    return {'gross_credit_usd':gross,'entry_cost_usd':one_way,'close_cost_reserve_usd':one_way,
            'net_entry_credit_usd':net,'roundtrip_cost_usd':one_way*2,
            'entry_midpoint_credit_usd':sum((q.bid+q.ask)/2*D(-side)*mult for q,side in legs),
            'entry_spread_crossing_usd':sum((q.ask-q.bid)/2*mult for q,side in legs),
            'all_in_roundtrip_cost_proxy_usd':one_way*2+sum((q.ask-q.bid)*mult for q,side in legs),
            'intact_terminal_loss_with_cost_reserve_usd':risk,
            'gross_assignment_funding_proxy_usd':funding,
            'expected_value_usd':None,'profit_probability':None}

def package_terminal_pnl(legs, terminal_spot, e):
    validate_package(legs)
    require(isinstance(e,dict) and all(k in e and finite(e[k]) for k in ('net_entry_credit_usd','close_cost_reserve_usd')), 'ECONOMICS_INVALID')
    s=decimal(terminal_spot); require(s>=0,'NEGATIVE_UNDERLYING')
    payoff=sum(D(side)*max(D(0),q.strike-s if q.kind=='P' else s-q.strike)*100 for q,side in legs)
    # Conservatively charges close reserve even for worthless expiry; no assignment cost model implied.
    return e['net_entry_credit_usd']+payoff-e['close_cost_reserve_usd']

def size_candidate(legs,e,b,spot,p=POLICY):
    validate_policy(p)
    vals=tuple(b.__dict__.values())
    require(all(isinstance(x,D) and finite(x) and x>=0 for x in vals) and b.equity>0,'BUDGET_INVALID')
    risk=e['intact_terminal_loss_with_cost_reserve_usd']; funding=e['gross_assignment_funding_proxy_usd']
    delta=abs(sum(D(str(q.delta))*side*100*decimal(spot) for q,side in legs))
    vega=abs(sum(D(str(q.vega))*side*100 for q,side in legs))
    gamma=abs(sum(D(str(q.gamma))*side*100 for q,side in legs))*D('.5')*(decimal(spot)*D('.01'))**2
    limits=[p.contracts_cap, int(b.equity*p.trade_risk_fraction//risk),
            int(max(D(0),b.equity*p.portfolio_risk_fraction-b.used_package_risk)//risk),
            int(max(D(0),b.equity*p.underlying_risk_fraction-b.used_underlying_risk)//risk),
            int(max(D(0),b.equity*p.assignment_funding_fraction-b.used_assignment_funding)//funding)]
    for per,used,frac in [(delta,b.absolute_delta_dollars,p.delta_dollars_fraction),(vega,b.absolute_vega_dollars_per_vol_point,p.vega_fraction),(gamma,b.absolute_gamma_loss_one_pct,p.gamma_fraction)]:
        if per>0: limits.append(int(max(D(0),b.equity*frac-used)//per))
        elif used>b.equity*frac: limits.append(0)
    limits.append(min(q.bid_size if side<0 else q.ask_size for q,side in legs))
    return max(0,min(limits)), {'delta_dollars':delta,'vega_usd_per_vol_point':vega,'gamma_loss_usd_one_pct':gamma}

def nominate(m,b,shape='PUT_SPREAD',arm='FORECAST_VRP',p=POLICY):
    receipt={'schema':VERSION,'shape':shape,'arm':arm,'decision_at':m.decision_at,
             'status':'WAIT','reason':None,'quantity':0,'execution_authorized':False,
             'evidence_class':'STRUCTURAL_SYNTHETIC' if m.synthetic else 'PIT_SHADOW_UNVALIDATED',
             'canonical_validator_run':False,'expected_value_usd':None}
    if arm=='WAIT':
        receipt['reason']='PREDECLARED_WAIT_ARM'; return receipt
    try:
        validate_policy(p)
        require(type(m.decision_at) is int and all(boolean(x) for x in (m.synthetic,m.full_regular_session,m.series_schedule_known,m.event_coverage_complete,m.high_impact_event_within_2_sessions)), 'MARKET_FLAG_OR_CLOCK_TYPE')
        require(shape in ('PUT_SPREAD','CONDOR') and arm in ('FORECAST_VRP','IV_ONLY','PRICE_ONLY','PRICE_PLUS_IV'),'UNKNOWN_STRATEGY')
        require(m.full_regular_session and m.series_schedule_known,'SCHEDULE_UNKNOWN_OR_EARLY_CLOSE')
        m.spot_stamp.check(m.decision_at,2); m.carry_stamp.check(m.decision_at); m.event_stamp.check(m.decision_at)
        require(finite(m.spot) and m.spot>0 and finite(m.forward) and m.forward>0,'BAD_SPOT_OR_FORWARD')
        require(m.event_coverage_complete,'EVENT_COVERAGE_UNKNOWN')
        require(not m.high_impact_event_within_2_sessions,'EVENT_EMBARGO')
        features=interval_features(m)
        require(all(isinstance(q,Quote) and isinstance(q.contract_id,str) and q.kind in ('P','C') and isinstance(q.strike,D) and finite(q.strike) and q.strike>0 and finite(q.delta) and type(q.terminal) is int for q in m.quotes), 'MALFORMED_CHAIN')
        require(len({q.contract_id for q in m.quotes})==len(m.quotes),'DUPLICATE_CONTRACT')
        terminals=sorted({q.terminal for q in m.quotes if 30 <= (q.terminal-m.decision_at)/DAY_SECONDS <=45})
        require(terminals,'NO_30_45_DTE_SERIES')
        terminal=min(terminals,key=lambda t:(abs((t-m.decision_at)/DAY_SECONDS-35),t))
        legs=choose_legs(m.quotes,terminal,shape,m.spot,p)
        pool=[q for q in m.quotes if q.terminal==terminal]
        strikes=sorted({q.strike for q in pool})
        atm_k=min(strikes,key=lambda k:(abs(k-decimal(m.forward)),k))
        atm=[q for q in pool if q.strike==atm_k]
        require(len(atm)==2 and {q.kind for q in atm}=={'P','C'},'ATM_PAIR_MISSING')
        required=list({q.contract_id:q for q in [q for q,s in legs]+atm}.values())
        for q in required: q.check(m.decision_at)
        require(max(q.stamp.observed_at for q in required)-min(q.stamp.observed_at for q in required)<=1,'LEGS_NOT_SYNCHRONIZED')
        require(len({q.iv_method for q in required})==1,'MIXED_IV_MODELS')
        require(all((q.quote_class=='SYNTHETIC_FIXTURE')==m.synthetic for q in required),'MIXED_SYNTHETIC_MARKET_EVIDENCE')
        f=m.forecast; require(f is not None,'FORECAST_UNAVAILABLE')
        require(isinstance(f,Forecast) and all(type(x) is int for x in (f.decision_at,f.target_end,f.fit_at,f.latest_training_label_available_at)), 'FORECAST_CLOCK_OR_TYPE_INVALID')
        f.stamp.check(m.decision_at)
        require(f.decision_at==m.decision_at and f.target_end==terminal and f.basis=='ACT365_PRICE_QV','FORECAST_HORIZON_MISMATCH')
        require(isinstance(f.annual_variance,(int,float)) and finite(f.annual_variance) and f.annual_variance>0,'FORECAST_INVALID')
        require(f.latest_training_label_available_at<=f.fit_at<=f.stamp.available_at<=m.decision_at,'FORECAST_TRAINING_LEAKAGE')
        require(hash_ok(f.model_hash),'FORECAST_MODEL_HASH_MISSING')
        if m.synthetic: require(f.qualification=='SYNTHETIC_FIXTURE','FORECAST_QUALIFICATION_MISMATCH')
        else: require(f.qualification=='PIT_VALIDATED_RESEARCH' and hash_ok(f.validation_receipt_hash),'FORECAST_NOT_QUALIFIED')
        iv=sum(q.iv for q in atm)/2
        gap=iv**2-f.annual_variance
        receipt.update(target_end=terminal,atm_iv_decimal=iv,forecast_annual_variance=f.annual_variance,
                       forecast_relative_variance_gap=gap,variance_gap_is_true_vrp=False,
                       total_variance_gap=gap*tau(m.decision_at,terminal),features=features)
        # Common qualification set for all non-WAIT arms. Only signal definitions vary.
        price_ok=(features['z5']>=-1 and features['rv1_rv22_ratio']<=2) if shape=='PUT_SPREAD' else (abs(features['z5'])<=.5 and features['rv1_rv22_ratio']<=1.25)
        simple_iv_ok=iv>=.20
        signal=({'FORECAST_VRP':price_ok and gap>=p.variance_gap and iv/sqrt(f.annual_variance)>=p.iv_to_forecast_vol,
                 'IV_ONLY':simple_iv_ok,'PRICE_ONLY':price_ok,'PRICE_PLUS_IV':price_ok and simple_iv_ok})[arm]
        require(signal,'SIGNAL_NOT_MET')
        e=economics(legs,p)
        require(e['all_in_roundtrip_cost_proxy_usd']/e['entry_midpoint_credit_usd']<=p.roundtrip_cost_fraction,'COST_BUDGET_EXCEEDED')
        quantity,exposure=size_candidate(legs,e,b,m.spot,p)
        require(quantity>0,'ZERO_RISK_BUDGET_OR_SIZE')
        receipt.update(status='RESEARCH_CANDIDATE',reason='SYNTHETIC_RULE_EXERCISED' if m.synthetic else 'RESEARCH_ONLY_NEEDS_STRATEGY_VALIDATION',
                       quantity=quantity,contracts=[{'id':q.contract_id,'side':s,'strike':str(q.strike)} for q,s in legs],
                       economics={k:str(v) if isinstance(v,D) else v for k,v in e.items()},
                       exposure={k:str(v) for k,v in exposure.items()})
    except Unqualified as ex:
        receipt['reason']=str(ex)
    return receipt

def lifecycle_oracle(opened,closed_per_leg,entry_cash_usd= D(0),confirmed_close_cash_usd=D(0),assignment_uncertain=False,cancel_pending=False,reserve_release_confirmed=False):
    """Classify supplied reconciled fill quantities. No state writes, orders, retries or cash inference."""
    require(all(isinstance(x,D) and finite(x) for x in (entry_cash_usd,confirmed_close_cash_usd)), 'LIFECYCLE_CASH_INVALID')
    require(boolean(assignment_uncertain) and boolean(cancel_pending) and boolean(reserve_release_confirmed), 'LIFECYCLE_FLAG_INVALID')
    require(type(opened) is int and opened>=0 and len(closed_per_leg) in (2,4),'BAD_QUANTITIES')
    require(all(type(x) is int and 0<=x<=opened for x in closed_per_leg),'BAD_QUANTITIES')
    if opened==0:
        require(all(x==0 for x in closed_per_leg) and entry_cash_usd==0 and confirmed_close_cash_usd==0,'NO_FILL_CASH_INCONSISTENT')
        return {'state':'NO_FILL','remaining_packages':0,'capital_release_allowed':False,'realized_cash_usd':'0'}
    remaining=[opened-x for x in closed_per_leg]
    uncertain=assignment_uncertain or cancel_pending
    if len(set(remaining))!=1:
        return {'state':'BROKEN_HEDGE_RECONCILE','remaining_leg_quantities':remaining,'remaining_packages':None,'original_package_bound_valid':False,'capital_release_allowed':False,'pnl_status':'INCOMPLETE'}
    n=remaining[0]
    state='RECONCILE_BLOCK' if uncertain else 'CLOSED' if n==0 else 'PARTIAL_CLOSE_INTACT' if n<opened else 'OPEN_INTACT'
    return {'state':state,'remaining_packages':n,'original_package_bound_valid':not assignment_uncertain,
            'capital_release_allowed':n==0 and not uncertain and reserve_release_confirmed,
            'all_option_legs_flat':n==0,'reserve_release_confirmed':reserve_release_confirmed,
            'realized_cash_usd':str(entry_cash_usd+confirmed_close_cash_usd),
            'pnl_status':'FINAL_CASH_ONLY' if n==0 and not uncertain else 'INCOMPLETE'}

def exit_signal(net_entry_credit,close_debit,remaining_days,held_days,event_due=False,assignment_alert=False):
    """Quoted signal only. Entry credit and close debit include their respective modeled costs."""
    require(boolean(event_due) and boolean(assignment_alert), 'EXIT_FLAG_INVALID')
    require(isinstance(net_entry_credit,D) and finite(net_entry_credit) and net_entry_credit>0 and finite(remaining_days) and finite(held_days),'BAD_EXIT_INPUT')
    if assignment_alert: return 'RECONCILE_ASSIGNMENT_FIRST'
    if event_due or remaining_days<=7 or held_days>=21: return 'MANDATORY_CLOSE_SIGNAL'
    if close_debit is None: return 'CLOSE_QUOTE_UNAVAILABLE'
    require(isinstance(close_debit,D) and finite(close_debit) and close_debit>=0,'BAD_CLOSE_DEBIT')
    pnl=net_entry_credit-close_debit
    if pnl<=-net_entry_credit: return 'LOSS_CLOSE_SIGNAL'
    if pnl>=net_entry_credit*D('.5'): return 'PROFIT_CLOSE_SIGNAL'
    return 'HOLD_RESEARCH_ONLY'

def term_diagnostic(iv_near,iv_far,t_near,t_far,decision):
    """Same-underlying same-forward-moneyness matched-basis proxy; not calendar-trade EV."""
    require(all(isinstance(x,(int,float)) and finite(x) and 0<x<=5 for x in (iv_near,iv_far)),'BAD_TERM_IV')
    require(t_far>t_near>decision,'BAD_TERM_ORDER')
    a=tau(decision,t_near); b=tau(decision,t_far)
    total_near=iv_near**2*a; total_far=iv_far**2*b
    forward=(total_far-total_near)/(b-a)
    return {'status':'DIAGNOSTIC_ONLY' if forward>=0 else 'INCONSISTENT_PROXY_REJECT',
            'near_total_variance':total_near,'far_total_variance':total_far,'forward_variance_proxy':forward,
            'trade':'DEFERRED_NO_VALIDATED_CALENDAR_SKEW_EVENT_EDGE'}

@dataclass(frozen=True)
class QVSegment:
    start: int
    end: int
    start_midpoint: float
    end_midpoint: float
    start_stamp: Stamp
    end_stamp: Stamp
    kind: str                       # REGULAR_5M, OVERNIGHT_GAP or TERMINAL_5M

def realized_qv(start,end,segments,expected_grid,computed_at):
    """Exact-grid realized price QV. Calendar/series grid must be independently vintaged.
    Return unavailable via exception on missing endpoints: no resampling/interpolation/zero fills.
    Overnight return replaces all extended-session returns for that nonterminal night.
    """
    require(all(type(x) is int for x in (start,end,computed_at)) and start<end,'LABEL_CLOCK_TYPE')
    require(segments and computed_at>=end,'LABEL_NOT_MATURED')
    require(tuple((s.start,s.end,s.kind) for s in segments)==tuple(expected_grid),'LABEL_GRID_MISMATCH')
    require(segments[0].start==start and segments[-1].end==end,'LABEL_ENDPOINT_MISMATCH')
    qv=0.; available=end
    for i,s in enumerate(segments):
        require(type(s.start) is int and type(s.end) is int, 'LABEL_CLOCK_TYPE')
        require(s.kind in ('REGULAR_5M','OVERNIGHT_GAP','TERMINAL_5M') and s.start<s.end,'LABEL_SEGMENT_INVALID')
        require(s.kind=='OVERNIGHT_GAP' or s.end-s.start==300,'NOT_FIVE_MINUTE_SEGMENT')
        if i: require(s.start==segments[i-1].end and s.start_midpoint==segments[i-1].end_midpoint,'LABEL_GAP_OR_OVERLAP')
        for price,stamp,endpoint in ((s.start_midpoint,s.start_stamp,s.start),(s.end_midpoint,s.end_stamp,s.end)):
            require(finite(price) and price>0,'LABEL_BAD_PRICE')
            require(all(type(x) is int for x in (stamp.observed_at,stamp.available_at,stamp.valid_until)), 'LABEL_CLOCK_TYPE')
            require(stamp.pit is True and stamp.observed_at<=stamp.available_at<=computed_at and endpoint<stamp.valid_until, 'LABEL_POINT_PIT_INVALID')
            require(isinstance(stamp.source,str) and bool(stamp.source) and hash_ok(stamp.payload_hash), 'PROVENANCE_MISSING')
            require(stamp.observed_at<=endpoint and endpoint-stamp.observed_at<=2,'LABEL_ENDPOINT_STALE_OR_FUTURE')
            available=max(available,stamp.available_at)
        qv+=(log(s.end_midpoint)-log(s.start_midpoint))**2
    require(finite(qv) and qv>0 and finite(qv/tau(start,end)),'NONPOSITIVE_OR_NONFINITE_LABEL')
    return {'qv':qv,'annual_variance':qv/tau(start,end),'target_end':end,'target_available_at':max(available,computed_at),'basis':'ACT365_PRICE_QV'}

def skew_diagnostic(put,call,decision):
    put.check(decision); call.check(decision)
    require(put.quote_class==call.quote_class,'SKEW_MIXED_EVIDENCE')
    require(put.kind=='P' and call.kind=='C' and put.terminal==call.terminal,'SKEW_MATURITY_OR_TYPE')
    require(put.iv_method==call.iv_method and abs(abs(put.delta)-.25)<=.025 and abs(call.delta-.25)<=.025,'SKEW_MODEL_OR_DELTA')
    require(abs(put.stamp.observed_at-call.stamp.observed_at)<=1,'SKEW_NOT_SYNCHRONIZED')
    return {'put25_minus_call25_iv':put.iv-call.iv,'status':'DIAGNOSTIC_ONLY','trade':'DEFERRED_NO_CALIBRATED_PHYSICAL_TAIL_OR_FILL_EVIDENCE'}


def validate_policy(p):
    require(isinstance(p,Policy),'POLICY_INVALID')
    money=(p.width,p.fee_per_leg_each_way,p.slippage_per_share_each_way,p.roundtrip_cost_fraction,p.trade_risk_fraction,p.portfolio_risk_fraction,p.underlying_risk_fraction,p.assignment_funding_fraction,p.delta_dollars_fraction,p.vega_fraction,p.gamma_fraction)
    require(all(isinstance(x,D) and finite(x) and x>=0 for x in money) and p.width>0,'POLICY_INVALID')
    require(0<p.trade_risk_fraction<=p.underlying_risk_fraction<=p.portfolio_risk_fraction<=1,'POLICY_RISK_INVALID')
    require(all(0<x<=1 for x in (p.roundtrip_cost_fraction,p.assignment_funding_fraction,p.delta_dollars_fraction,p.vega_fraction,p.gamma_fraction)),'POLICY_RISK_INVALID')
    require(finite(p.variance_gap) and p.variance_gap>=0 and finite(p.iv_to_forecast_vol) and p.iv_to_forecast_vol>=1 and type(p.contracts_cap) is int and p.contracts_cap>0,'POLICY_SIGNAL_INVALID')

def validate_package(legs):
    require(len(legs) in (2,4),'PACKAGE_LEG_COUNT')
    require(all(isinstance(q,Quote) and type(side) is int and side in (-1,1) for q,side in legs),'PACKAGE_RATIO_INVALID')
    require([side for q,side in legs]==[-1,1]*(len(legs)//2),'PACKAGE_SIDES_INVALID')
    require(len({q.contract_id for q,s in legs})==len(legs),'PACKAGE_DUPLICATE')
    require(len({(q.underlying,q.terminal,q.multiplier,q.deliverable,q.exercise,q.settlement) for q,s in legs})==1,'PACKAGE_IDENTITY_MISMATCH')
    require(all(type(q.multiplier) is int and q.multiplier==100 and q.underlying=='SPY' and q.deliverable=='100_SPY_SHARES' for q,s in legs),'PACKAGE_DELIVERABLE_INVALID')
    require(all(all(isinstance(x,D) and finite(x) for x in (q.strike,q.bid,q.ask)) and q.strike>0 and 0<q.bid<=q.ask for q,s in legs),'PACKAGE_PRICE_INVALID')
    for i in range(0,len(legs),2):
        short,long=legs[i][0],legs[i+1][0]
        require(short.kind==long.kind and ((short.kind=='P' and short.strike>long.strike) or (short.kind=='C' and short.strike<long.strike)),'PACKAGE_GEOMETRY_INVALID')
    if len(legs)==4:
        require(legs[0][0].kind=='P' and legs[2][0].kind=='C' and legs[0][0].strike<legs[2][0].strike,'CONDOR_GEOMETRY_INVALID')
