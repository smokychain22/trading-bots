# Volatility Arbitrageur: offline research packet v1

Start with PLAYBOOKS_v1.md, then VALIDATION_AND_DATA_GAPS_v1.md.

Run: `python3 reproduce_v1.py` from this directory. Python 3.10+ with stdlib zoneinfo and US timezone data; no packages, account access, downloads or network are used. The verification environment is recorded in the receipt. No production source is imported or edited.

Contents:
- volatility_prototype_v1.py: exact, versioned typed contracts; causal QV/EWMA; put-spread and condor nomination; sizing/payoff; exit/lifecycle and term/skew diagnostic functions
- test_volatility_v1.py: developer synthetic tests and named invented fixture
- review_adversarial_v1.py: independent adversarial tests
- contracts_v1.json and fixture_inputs_v1.json: machine-readable contract and complete invented inputs
- synthetic_nomination_receipts_v1.json and lifecycle_diagnostics_v1.json: deterministic rule receipts, not P&L evidence
- reproduction_receipt_v1.json: final pass/fail and code/input hashes
- MANIFEST_SHA256_v1.json: all-file integrity manifest, excluding itself
- sources_v1.json and SOURCE_REUSE_v1.json: public-source scope and prior-work lineage
- initial_61_test_output.txt / review initial and retest artifacts: preserve actual review progression, not additive final assertions

Results are research candidates or WAIT, never executable orders. Positive forecast-relative ATM variance gap is not demonstrated positive expectancy. Term/skew/event trading is deferred for missing physical-tail, path and fill evidence. No 80% win-rate or deployment readiness is asserted.

The complete standalone packet is local only. No publishing or canonical validator claim is made. Reticle is inapplicable: this is an offline CLI with no UI surface.
