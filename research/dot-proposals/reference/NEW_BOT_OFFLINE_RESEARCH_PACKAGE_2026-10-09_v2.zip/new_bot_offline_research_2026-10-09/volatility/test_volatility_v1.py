"""Invented structural inputs. No historical market observations or estimated probabilities."""
import unittest
from dataclasses import replace
from datetime import datetime,timedelta
from zoneinfo import ZoneInfo
from decimal import Decimal as D
from volatility_prototype_v1 import *


def fixture():
    decision=int(datetime(2026,10,8,15,30,tzinfo=ZoneInfo('America/New_York')).timestamp())
    terminal=int(datetime(2026,11,12,16,15,tzinfo=ZoneInfo('America/New_York')).timestamp())
    stamp=Stamp(decision-1,decision,decision+1,'INVENTED_SYNCHRONIZED_QUOTES','a'*64)
    days=[]; t=datetime(2026,10,8,15,30,tzinfo=ZoneInfo('America/New_York'))
    while len(days)<23:
        if t.weekday()<5: days.append(int(t.timestamp()))
        t-=timedelta(days=1)
    days=list(reversed(days))
    intervals=tuple(Interval(i,days[i],days[i+1],.04*tau(days[i],days[i+1]),500.,500.,
        Stamp(days[i+1],days[i+1],decision+1,'INVENTED_QV_INTERVAL','b'*64)) for i in range(22))
    def q(kind,k,bid,ask,delta,vega,gamma):
        return Quote('FIXTURE_'+kind+str(k),kind,D(k),terminal,D(bid),D(ask),10,10,delta,gamma,vega,.30,stamp,iv_terminal=terminal)
    chain=(q('P',480,'1.30','1.40',-.20,.20,.008),q('P',475,'.45','.50',-.13,.16,.006),
           q('C',520,'1.30','1.40',.20,.20,.008),q('C',525,'.45','.50',.13,.16,.006),
           q('P',500,'12','12.10',-.50,.6,.02),q('C',500,'12','12.10',.50,.6,.02))
    m=Market(decision,500.,500.,stamp,stamp,intervals,chain,None,stamp,False,True,True,True)
    m=replace(m,forecast=ewma_forecast(m,terminal))
    b=Budget(D(1000000),D(0),D(0),D(0),D(0),D(0),D(0))
    return m,b

class TestVolatility(unittest.TestCase):
    def setUp(self): self.m,self.b=fixture()
    def result(self,**kw): return nominate(replace(self.m,**kw),self.b)
    def mutate_quote(self,idx=0,**kw):
        qs=list(self.m.quotes); qs[idx]=replace(qs[idx],**kw); return tuple(qs)
    def test_put_candidate(self):
        r=nominate(self.m,self.b); self.assertEqual(r['status'],'RESEARCH_CANDIDATE'); self.assertEqual(r['quantity'],5); self.assertIsNone(r['expected_value_usd']); self.assertFalse(r['execution_authorized'])
    def test_condor_candidate(self):
        r=nominate(self.m,self.b,'CONDOR'); self.assertEqual(r['status'],'RESEARCH_CANDIDATE'); self.assertEqual(len(r['contracts']),4)
    def test_forecast_exact_constant_variance(self): self.assertAlmostEqual(self.m.forecast.annual_variance,.04,14)
    def test_forecast_totalvariance_matching(self):
        r=nominate(self.m,self.b); self.assertAlmostEqual(r['forecast_relative_variance_gap'],.05); self.assertAlmostEqual(r['total_variance_gap'],.05*tau(self.m.decision_at,self.m.forecast.target_end))
    def test_benchmarks_same_origin_target(self):
        rs=[nominate(self.m,self.b,arm=a) for a in ('FORECAST_VRP','PRICE_ONLY','IV_ONLY','PRICE_PLUS_IV')]
        self.assertEqual(len({r['target_end'] for r in rs}),1); self.assertTrue(all(r['quantity']==5 for r in rs))
    def test_wait(self): self.assertEqual(nominate(self.m,self.b,arm='WAIT')['quantity'],0)
    def test_missing_forecast_common_mask(self):
        for a in ('FORECAST_VRP','PRICE_ONLY','IV_ONLY','PRICE_PLUS_IV'):
            self.assertEqual(nominate(replace(self.m,forecast=None),self.b,arm=a)['reason'],'FORECAST_UNAVAILABLE')
    def test_nonmatching_horizon(self): self.assertEqual(self.result(forecast=replace(self.m.forecast,target_end=self.m.forecast.target_end+1))['reason'],'FORECAST_HORIZON_MISMATCH')
    def test_future_fit_label(self): self.assertEqual(self.result(forecast=replace(self.m.forecast,latest_training_label_available_at=self.m.decision_at+1))['reason'],'FORECAST_TRAINING_LEAKAGE')
    def test_stale_quote(self):
        self.assertEqual(self.result(quotes=self.mutate_quote(stamp=replace(self.m.quotes[0].stamp,observed_at=self.m.decision_at-3)))['reason'],'STALE_QUOTE')
    def test_future_quote(self):
        self.assertEqual(self.result(quotes=self.mutate_quote(stamp=replace(self.m.quotes[0].stamp,available_at=self.m.decision_at+1)))['reason'],'PIT_INVALID')
    def test_unsynchronized(self):
        self.assertEqual(self.result(quotes=self.mutate_quote(stamp=replace(self.m.quotes[0].stamp,observed_at=self.m.decision_at-2)))['status'],'RESEARCH_CANDIDATE')
        qs=list(self.m.quotes); qs[0]=replace(qs[0],stamp=replace(qs[0].stamp,observed_at=self.m.decision_at-2)); qs[1]=replace(qs[1],stamp=replace(qs[1].stamp,observed_at=self.m.decision_at))
        self.assertEqual(self.result(quotes=tuple(qs))['reason'],'LEGS_NOT_SYNCHRONIZED')
    def test_indicative_executable_flag_cannot_upgrade(self): self.assertEqual(self.result(quotes=self.mutate_quote(quote_class='INDICATIVE_MODIFIED',executable_flag=True))['reason'],'NOT_BBO_RESEARCH_ONLY')
    def test_session_recorded_refused(self): self.assertEqual(self.result(quotes=self.mutate_quote(quote_class='SESSION_RECORDED_RESEARCH'))['reason'],'NOT_BBO_RESEARCH_ONLY')
    def test_percent_iv_refused(self): self.assertEqual(self.result(quotes=self.mutate_quote(iv=30.0))['reason'],'GREEK_UNITS')
    def test_252_basis_refused(self): self.assertEqual(self.result(quotes=self.mutate_quote(iv_basis='SQRT252'))['reason'],'IV_HORIZON_OR_METHOD_MISMATCH')
    def test_iv_terminal_refused(self): self.assertEqual(self.result(quotes=self.mutate_quote(iv_terminal=self.m.forecast.target_end-900))['reason'],'IV_HORIZON_OR_METHOD_MISMATCH')
    def test_crossed_refused(self): self.assertEqual(self.result(quotes=self.mutate_quote(bid=D(2)))['reason'],'CROSSED_OR_ZERO_QUOTE')
    def test_unknown_size(self): self.assertEqual(self.result(quotes=self.mutate_quote(bid_size=0))['reason'],'SIZE_UNAVAILABLE')
    def test_fractional_size_refused(self): self.assertEqual(self.result(quotes=self.mutate_quote(bid_size=1.5))['reason'],'SIZE_UNAVAILABLE')
    def test_adjusted_deliverable_refused(self): self.assertEqual(self.result(quotes=self.mutate_quote(multiplier=150))['reason'],'DELIVERABLE_UNSUPPORTED')
    def test_nan_quote_refused(self): self.assertEqual(self.result(quotes=self.mutate_quote(iv=float('nan')))['reason'],'NONFINITE_QUOTE')
    def test_atm_missing(self): self.assertEqual(self.result(quotes=self.m.quotes[:-1])['reason'],'ATM_PAIR_MISSING')
    def test_duplicate_contract(self): self.assertEqual(self.result(quotes=self.m.quotes+(self.m.quotes[0],))['reason'],'DUPLICATE_CONTRACT')
    def test_no_wing(self): self.assertEqual(self.result(quotes=tuple(q for q in self.m.quotes if q.strike!=475))['reason'],'NO_UNIQUE_PUT_WING')
    def test_event_unknown(self): self.assertEqual(self.result(event_coverage_complete=False)['reason'],'EVENT_COVERAGE_UNKNOWN')
    def test_event_embargo(self): self.assertEqual(self.result(high_impact_event_within_2_sessions=True)['reason'],'EVENT_EMBARGO')
    def test_schedule_unknown(self): self.assertEqual(self.result(series_schedule_known=False)['reason'],'SCHEDULE_UNKNOWN_OR_EARLY_CLOSE')
    def test_early_close(self): self.assertEqual(self.result(full_regular_session=False)['reason'],'SCHEDULE_UNKNOWN_OR_EARLY_CLOSE')
    def test_missing_interval(self): self.assertEqual(self.result(intervals=self.m.intervals[:-1])['reason'],'NEED_22_COMPLETE_INTERVALS')
    def test_missing_session_not_compressed(self):
        rows=list(self.m.intervals); rows[2]=replace(rows[2],session_index=9)
        self.assertEqual(self.result(intervals=tuple(rows))['reason'],'MISSING_SESSION_OR_ENDPOINT')
    def test_incomplete_interval(self):
        rows=list(self.m.intervals); rows[2]=replace(rows[2],complete=False)
        self.assertEqual(self.result(intervals=tuple(rows))['reason'],'INTERVAL_INCOMPLETE_OR_FUTURE')
    def test_future_interval_available(self):
        rows=list(self.m.intervals); rows[2]=replace(rows[2],stamp=replace(rows[2].stamp,available_at=self.m.decision_at+1))
        self.assertEqual(self.result(intervals=tuple(rows))['reason'],'PIT_INVALID')
    def test_positive_gap_not_enough(self):
        self.assertEqual(self.result(forecast=replace(self.m.forecast,annual_variance=.085))['reason'],'SIGNAL_NOT_MET')
    def test_negative_gap(self): self.assertEqual(self.result(forecast=replace(self.m.forecast,annual_variance=.10))['reason'],'SIGNAL_NOT_MET')
    def test_package_loss_exact(self):
        legs=choose_legs(self.m.quotes,self.m.forecast.target_end,'PUT_SPREAD',500); e=economics(legs)
        self.assertEqual(e['gross_credit_usd'],D(80)); self.assertEqual(e['roundtrip_cost_usd'],D('6.60')); self.assertEqual(e['intact_terminal_loss_with_cost_reserve_usd'],D('426.60'))
        self.assertEqual(package_terminal_pnl(legs,400,e),D('-426.60')); self.assertEqual(package_terminal_pnl(legs,500,e),D('73.40'))
    def test_condor_max_not_sum_width(self):
        legs=choose_legs(self.m.quotes,self.m.forecast.target_end,'CONDOR',500); e=economics(legs)
        self.assertEqual(e['intact_terminal_loss_with_cost_reserve_usd'],D('353.20'))
        for s in (0,400,600,100000): self.assertEqual(package_terminal_pnl(legs,s,e),D('-353.20'))
        self.assertEqual(package_terminal_pnl(legs,500,e),D('146.80'))
    def test_terminal_bound_grid(self):
        for shape in ('PUT_SPREAD','CONDOR'):
            legs=choose_legs(self.m.quotes,self.m.forecast.target_end,shape,500); e=economics(legs)
            for s in range(1001): self.assertGreaterEqual(package_terminal_pnl(legs,s,e),-e['intact_terminal_loss_with_cost_reserve_usd'])
    def test_assignment_budget_binds(self):
        b=replace(self.b,equity=D(100000))
        self.assertEqual(nominate(self.m,b)['quantity'],1); self.assertEqual(nominate(self.m,b,'CONDOR')['quantity'],0)
    def test_portfolio_budget_binds(self): self.assertEqual(nominate(self.m,replace(self.b,used_package_risk=D(20000)))['reason'],'ZERO_RISK_BUDGET_OR_SIZE')
    def test_delta_budget_binds(self): self.assertEqual(nominate(self.m,replace(self.b,absolute_delta_dollars=D(200000)))['quantity'],0)
    def test_vega_budget_binds(self): self.assertEqual(nominate(self.m,replace(self.b,absolute_vega_dollars_per_vol_point=D(2000)))['quantity'],0)
    def test_gamma_budget_binds(self): self.assertEqual(nominate(self.m,replace(self.b,absolute_gamma_loss_one_pct=D(1000)))['quantity'],0)
    def test_negative_budget(self): self.assertEqual(nominate(self.m,replace(self.b,used_package_risk=D(-1)))['reason'],'BUDGET_INVALID')
    def test_size_at_display(self): self.assertEqual(self.result(quotes=self.mutate_quote(bid_size=1))['quantity'],1)
    def test_no_fill_zero_cash(self): self.assertEqual(lifecycle_oracle(0,[0,0])['state'],'NO_FILL')
    def test_no_fill_cannot_credit(self):
        with self.assertRaises(Unqualified): lifecycle_oracle(0,[0,0],D(80))
    def test_partial_close_retains_exposure(self):
        r=lifecycle_oracle(2,[1,1],D(160),D(-40)); self.assertEqual(r['remaining_packages'],1); self.assertFalse(r['capital_release_allowed']); self.assertEqual(r['pnl_status'],'INCOMPLETE')
    def test_protection_first_is_not_defined_risk(self):
        r=lifecycle_oracle(1,[0,1]); self.assertEqual(r['state'],'BROKEN_HEDGE_RECONCILE'); self.assertFalse(r['original_package_bound_valid'])
    def test_condor_one_wing_closed_is_reconcile(self): self.assertEqual(lifecycle_oracle(1,[1,1,0,0])['state'],'BROKEN_HEDGE_RECONCILE')
    def test_assignment_uncertainty_blocks_release(self): self.assertFalse(lifecycle_oracle(1,[1,1],assignment_uncertain=True)['capital_release_allowed'])
    def test_cancel_pending_blocks_release(self): self.assertFalse(lifecycle_oracle(1,[1,1],cancel_pending=True)['capital_release_allowed'])
    def test_all_close_release(self): self.assertTrue(lifecycle_oracle(1,[1,1],reserve_release_confirmed=True)['capital_release_allowed'])
    def test_closed_without_release_receipt(self): self.assertFalse(lifecycle_oracle(1,[1,1])['capital_release_allowed'])
    def test_exit_mandatory_precedes_profit(self): self.assertEqual(exit_signal(D(80),D(1),6,1),'MANDATORY_CLOSE_SIGNAL')
    def test_exit_profit(self): self.assertEqual(exit_signal(D(80),D(40),20,1),'PROFIT_CLOSE_SIGNAL')
    def test_exit_loss(self): self.assertEqual(exit_signal(D(80),D(160),20,1),'LOSS_CLOSE_SIGNAL')
    def test_exit_no_quote(self): self.assertEqual(exit_signal(D(80),None,20,1),'CLOSE_QUOTE_UNAVAILABLE')
    def test_exit_assignment_first(self): self.assertEqual(exit_signal(D(80),None,1,30,True,True),'RECONCILE_ASSIGNMENT_FIRST')
    def test_term_proxy(self):
        d=self.m.decision_at; r=term_diagnostic(.20,.30,d+30*86400,d+60*86400,d)
        self.assertAlmostEqual(r['forward_variance_proxy'],.14); self.assertIn('DEFERRED',r['trade'])
    def test_negative_forward_proxy(self):
        d=self.m.decision_at; self.assertEqual(term_diagnostic(.5,.1,d+30*86400,d+60*86400,d)['status'],'INCONSISTENT_PROXY_REJECT')
    def test_real_data_cannot_use_synthetic_quotes(self): self.assertEqual(self.result(synthetic=False)['reason'],'MIXED_SYNTHETIC_MARKET_EVIDENCE')

class TestRealizedQV(unittest.TestCase):
    def setUp(self):
        self.start=100000; self.end=100600
        def stamp(t): return Stamp(t,t+1,t+3,'INVENTED_GRID','c'*64)
        self.segments=(QVSegment(self.start,self.start+300,100,101,stamp(self.start),stamp(self.start+300),'REGULAR_5M'),
                       QVSegment(self.start+300,self.end,101,99,stamp(self.start+300),stamp(self.end),'TERMINAL_5M'))
        self.grid=tuple((s.start,s.end,s.kind) for s in self.segments)
    def test_qv_matches_sum_squared_logs(self):
        r=realized_qv(self.start,self.end,self.segments,self.grid,self.end+10)
        self.assertAlmostEqual(r['qv'],log(101/100)**2+log(99/101)**2)
        self.assertAlmostEqual(r['annual_variance'],r['qv']*YEAR_SECONDS/600)
        self.assertEqual(r['target_available_at'],self.end+10)
    def test_label_not_available_before_maturity(self):
        with self.assertRaisesRegex(Unqualified,'LABEL_NOT_MATURED'): realized_qv(self.start,self.end,self.segments,self.grid,self.end-1)
    def test_missing_point_no_zero_fill(self):
        with self.assertRaisesRegex(Unqualified,'LABEL_GRID_MISMATCH'): realized_qv(self.start,self.end,self.segments[:1],self.grid,self.end+10)
    def test_endpoint_quote_future_refused(self):
        segs=(replace(self.segments[0],start_stamp=replace(self.segments[0].start_stamp,observed_at=self.start+1)),self.segments[1])
        with self.assertRaisesRegex(Unqualified,'LABEL_ENDPOINT_STALE_OR_FUTURE'): realized_qv(self.start,self.end,segs,self.grid,self.end+10)
    def test_unavailable_point_refused(self):
        segs=(self.segments[0],replace(self.segments[1],end_stamp=replace(self.segments[1].end_stamp,available_at=self.end+11)))
        with self.assertRaisesRegex(Unqualified,'LABEL_POINT_PIT_INVALID'): realized_qv(self.start,self.end,segs,self.grid,self.end+10)
    def test_overnight_counted_once(self):
        a=self.segments[0]; b=replace(self.segments[1],kind='OVERNIGHT_GAP',end=self.end+86400,end_stamp=Stamp(self.end+86400,self.end+86400,self.end+86401,'INVENTED','d'*64))
        grid=((a.start,a.end,a.kind),(b.start,b.end,b.kind))
        r=realized_qv(a.start,b.end,(a,b),grid,b.end)
        self.assertAlmostEqual(r['qv'],log(101/100)**2+log(99/101)**2)
    def test_skew_deferred(self):
        m,b=fixture(); p=replace(m.quotes[0],delta=-.25,iv=.35); c=replace(m.quotes[2],delta=.25)
        self.assertAlmostEqual(skew_diagnostic(p,c,m.decision_at)['put25_minus_call25_iv'],.05)
    def test_skew_different_expiry_refused(self):
        m,b=fixture(); p=replace(m.quotes[0],delta=-.25); c=replace(m.quotes[2],delta=.25,terminal=m.quotes[2].terminal+86400,iv_terminal=m.quotes[2].terminal+86400)
        with self.assertRaisesRegex(Unqualified,'SKEW_MATURITY_OR_TYPE'): skew_diagnostic(p,c,m.decision_at)

if __name__=='__main__': unittest.main(verbosity=2)
