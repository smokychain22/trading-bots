# Three new-bot offline research prototypes

This self-contained package contains Gamma Trader, Volatility Arbitrageur and Theta Harvester research playbooks, frozen code, invented fixtures and bounded independent reviews. It establishes offline structural behavior only. It contains zero qualified option-market observations or actual fills, and supports no empirical profitability or win-rate claim. It starts no feed, account connection, broker action, monitoring workflow or production integration.

Start with `NEW_BOT_RESEARCH_OVERVIEW.md` and `review/cross_family/INTERFACE_AND_CLAIMS_REVIEW.md`. Family playbooks define different research questions and cannot be ranked by their displayed scenario returns.

## Reproduce safely

Use an ordinary disposable extracted copy. Existing Python 3.12+ and Node.js 24+ are required; all Python code uses the standard library. No package manager, network, download, credential or database is required. Missing dependencies must stop the check. Node is needed only for Harvester's explicitly whitelisted frozen pure arithmetic dependency.

From the package root, run `python3 verify_package_manifest.py` before running an entrypoint. Then run:

- Gamma: `cd gamma && python3 verify_reproduce.py`
- Volatility: `cd volatility && python3 reproduce_v1.py`
- Harvester: `cd harvester && python3 reproduce.py`

Run each line in its own shell from the package root, or return to that root between commands. The entrypoints write generated receipts in their own copied directories. This intentionally changes some copied timestamps, logs and output receipts; verify the manifest before the runs. Preserve the untouched ZIP as the original frozen evidence. Do not regenerate a family manifest and treat it as the reviewed original.

The adjacent original packaging receipt records one clean-extraction reproduction of each entrypoint. The v2 archive makes only a reviewed documentation/annualization clarification and exact review-metadata updates. A separate v2 continuity receipt verifies the new archive and proves code, tests, fixtures and generated financial outputs unchanged; the entrypoints were not run again. The original run adds no market observations, independent research tests, statistical sample or empirical validation.

The included Harvester independent harness can separately be invoked from the package root as `python3 review/harvester/review_regressions.py harvester`. It is supplied for review, and is not an additional step in the three-entrypoint packaging check. Historical review references to frozen snapshots and unsuccessful intermediate logs describe excluded audit archives; they are not missing runtime dependencies. The exact final source is in `harvester/`, matching the final review's hashes.

## Boundaries

Only explicit public-safe author/reviewer files are included. There are no owner trade briefs, private account records, credentials, proprietary source PDFs or market datasets. This new-bot package is separate from the original H proposal. The retained canonical arithmetic source is a byte-identical public-commit reference with provenance in `harvester/evidence/source_reuse_receipt.json`; it is not a replacement production engine or proof of deployed state.

All source and fixture hashes are in `MANIFEST_SHA256.json`; it excludes itself. Family manifests preserve their original scopes. Preparing or reviewing this package does not authorize its publication, live capture, integration or trading.
