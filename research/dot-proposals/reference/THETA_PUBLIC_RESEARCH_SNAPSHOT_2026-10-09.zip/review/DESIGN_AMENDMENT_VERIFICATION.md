# Design amendment verification

Verified 2026-10-08 23:13 UTC. This note follows `DESIGN_REVIEW_HISTORY.md`; it does not overwrite the original review or original designs.

## Q amendment 01

`q/THETA_Q_RESEARCH_DESIGN_V1_AMENDMENT_01.md` resolves the identified policy-estimand and timing ambiguities:
- Every presealed eligible origin remains in the comparison; rejected screened arms hold the matched cash alternative.
- Economic wealth uses a single sealed expiry-date core-equity close. Later information can complete that timestamp's label but cannot move it.
- Remaining option liabilities are valued, not assumed expired at the stock close.
- Common collateral is the sole primary sizing scheme; the four delta strata have fixed 25% weights, with no post-outcome renormalization.
- The gross FIXED_50 benchmark is pinned, while the complete mandatory-management/cash/valuation prerequisites explicitly remain unresolved.
- Premium-component ceilings remain separate from whole-chain wealth; net returns remain separate from factor alpha.

The original v1 bytes and both quoted benchmark source hashes verify. The amendment correctly retains NOT_READY_FOR_EMPIRICAL_SEAL. Detailed static-check receipt retained separately.

## Incubator version 2

`incubator/THETA_INCUBATOR_DESIGN_AMENDMENT_V2.md` and `iv_information_research_design_v2.json` resolve the identified target-clock, training-window and unnecessary-data-dependency ambiguities. They bind the actual historically applicable series schedule, explicitly measure any final post-regular-close segment, preserve early-close session indexing, define variance inputs and expanding/prequential fits, and keep missingness on the calendar. OI is ancillary; carry validity is distinct from market-quote freshness. No current general-hours rule is silently projected backward.

All three new-file hashes, the canonical JSON content hash, prior manifest hash and independently snapshotted v1 files verify. V1 remains unchanged. The controlling status is AMENDED_DESIGN_DATA_NOT_AVAILABLE_NOT_EMPIRICALLY_SEALED. Detailed static-check receipt retained separately.

## What this closes, and what remains open

These amendments resolve the specific static design ambiguities raised in independent review. They do not validate historical endpoint availability, a counterfactual execution model, an empirical consumer, forecast calibration, bootstrap coverage or profitability. The original synthetic checks do not test the amended specifications, and none was rerun or recounted here.

Both remain plain research designs. Their data and implementation prerequisites are explicit blockers before an empirical seal. The multi-year forecast remains lower priority and does not block bounded same-entry audits or existing-candidate diagnostics. Subsequent empirical reporting must retain common-origin coverage and arm-specific abstentions, so conditional forecast-loss improvement is not mistaken for full-coverage forecast superiority.
