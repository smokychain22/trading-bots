# Review history and controlling corrections

This report records the initial requested corrections. Read any later amendment verification alongside it. Q amendment 01 and IV designv2 control where they differ from v1.

# Independent review: Q cost selection, IV information and source semantics

Reviewed 2026-10-08 UTC. Original files preserved; no synthetic suite rerun, source execution/edit, market-data acquisition, publication or validator invocation. Corrections below are proposed amendments, not already implemented changes.

## Decision

Keep both proposals as **plain, offline research designs**. The source-boundary warning is accurate, and the cited research does not establish an ETF-put delta optimum, a dealer-wall strategy, or a profitable IV–RV rule. Do not seek a nominal validator pass by relabeling these features as generic IV or LIQUIDITY.

The actionable priority is a bounded same-entry/episode evidence audit and existing-candidate cost annotation. The lower-priority IV forecast can remain deferred; its multi-year dataset requirement must not become a prerequisite for all THETA work.

## Blocking corrections before any empirical run

### 1. Close the IV target's terminal-clock gap

The target ends at an option series' last-tradable timestamp, but the sampling recipe specifies underlying regular-session squares and close-to-next-open gaps. Ordinary SPY option class hours extend to 16:15 ET, whereas the underlying regular close and exercise-reference close are 16:00. The final interval can therefore be omitted by an otherwise literal implementation. [Nasdaq class hours](https://www.nasdaqtrader.com/Trader.aspx?id=optionshours), [Cboe trading versus exercise-reference FAQ](https://www.cboe.com/document/tech-spec/document/technical-specifications/equity-options-extended-trading-hours-faq).

Exact required amendment:

“Bind each origin to the selected series' historically applicable last-trade, expiration, exercise-reference and settlement calendar. Let L be the verified chosen target endpoint. Include measured underlying return intervals through L, including any segment after the underlying regular close. Use the same L in the ACT/365 denominator. If the final segment or endpoint is unavailable, the label is incomplete; do not forward-fill, omit it or silently extend the horizon. Broker exercise deadlines are separate operational fields.”

For a verified 16:15 endpoint, explicitly choose observed 16:00–16:05–16:10–16:15 returns or another sealed sampling rule. Do not infer every historical series' expiry-day cutoff solely from today's general class hours. An alternative 16:00 target is possible, but requires an explicit target version and disclosed IV-maturity mismatch.

### 2. Finish the forecast's reproducible training and feature definitions

“756 matured rows minimum” does not say rolling versus expanding, and “RV ending at 15:30” does not uniquely define partial-day versus prior-complete-session inputs. The JSON's RV terminology also needs to distinguish variance from volatility.

A concrete consistent amendment to adopt or replace before sealing:

- Refit every 21 exchange sessions using the latest 756 qualified origins whose entire target and first-available label are already known. Freeze this rolling rule; use a different named version if expanding training is intended.
- Define daily blocks from the prior full-session 15:30 cutoff to today's 15:30 cutoff, with measured regular-session pieces and intervening gaps. For each block, define variance as sum of squared log returns divided by its exact elapsed ACT/365 years. Use log of the latest block variance and log of the arithmetic mean of the last 5 and 22 block variances. Never silently supply canonical sqrt252 daily-return standard deviation instead.
- Define the five-session standardized-return input using the same sealed cutoff endpoints and specify its squared-return denominator. Missing/zero positive-required values remain unresolved as already proposed.
- Specify smearing estimation and fit-failure behavior; stamp training start/end, latest label availability and preprocessing versions on each forecast.
- Form the 63-session inference blocks on the exchange-session calendar, retaining missing-origin indicators. Do not reinterpret 63 sessions as 63 surviving observations after variable gaps.

These are registration-completion requirements, not evidence that a fitted model has failed. No model has been fitted. The current `DESIGN_READY_DATA_NOT_AVAILABLE` label should be qualified as **design requires final specification and data admission** until resolved.

### 3. Make Q's policy comparison cover the whole eligible opportunity set

The design correctly mentions a cash benchmark, but its primary metric could still be implemented as a comparison of retained-trade averages. That would not measure the effect of the screen.

Exact required amendment:

“At every presealed, hard-gate-eligible origin, evaluate the unfiltered policy and the screened policy on the same initial account budget. If the cost screen rejects a known candidate, that policy holds its designated cash benchmark to the fixed horizon. Keep this row in the paired policy result. Unknown inputs/outcomes remain typed missing or censored, never fabricated cash returns. Failed and partial execution outcomes remain included under the frozen execution model. Report conditional accepted-trade economics only as secondary diagnostics.”

Choose one primary sizing/aggregation estimand. Four delta buckets and three sizing methods otherwise supply several opportunities to declare success. A single fixed-weight primary aggregate or explicitly family-wise inference is required; other bucket/sizing results should remain secondary. Keep the 10%/30% cost-cap sensitivities subordinate to the fixed 20% primary cap. Bind the unchanged management benchmark to its existing policy/version/hash before sealing.

### 4. Fix Q's economic valuation time separately from information arrival

“Expiry settlement plus any required reconciled valuation” must not let a slow assignment confirmation shift one arm's valuation date. Define one economic timestamp T before outcomes, with the same retained-stock/liability/cash valuation convention for both arms. Separately record when the full outcome becomes knowable. A late assignment receipt may complete the label for T; it may not change T or enter an earlier fit. Unresolved inventory, cash or entitlements at T leave the label censored.

## Economic definitions: preserve these distinctions

- The 20% cost cap, capital hurdle, selected DTE targets, two-second quote window and 2% QLIKE hurdle are research choices. The cited papers do not derive their optimality. An arbitrary but sealed falsifiable threshold is acceptable for research; it is not a recommended setting or a calibrated risk limit.
- Q's opening-cost ratio is dimensionless only when contract-dollar cost is divided by contract-dollar credit. It is opening-only. The proposed round-trip reserve needs additional evidence, including which costs are already embedded in bid/ask references.
- `(C−D)/(B×H)` is an assumed option-premium-component ceiling. It is not expected return and does not bound whole-chain wealth after early assignment and retained-stock appreciation. Keep `scenario_net_premium_ceiling` separate from the primary common-horizon wealth endpoint.
- Comparing one contract, equal collateral and equal contractual maximum loss answers different questions. Equal maximum loss does not ensure assignment funding; equal premium or delta is not equal risk.
- ATM-IV squared is a named proxy. It is neither an option-strip variance-swap rate nor a physical expected variance. Better variance forecasting alone cannot justify premium selling.

## Primary citations checked: no performance transfer

- **Goyal–Saretto:** the reported delta-sort +0.22%/−0.68% and moneyness +0.38%/−0.86% monthly gross/net figures, 30% effective/quoted-spread convention, full-sample-positive orientation, daily delta hedging and dividend-window exclusion are supported. Their return denominator is based on the initial delta-hedged position, not CSP strike cash. No significant after-cost IPCA alpha does **not** mean no significant after-cost return: the paper still reports 16 significant net-return strategies. Neither finding chooses an ETF-put delta. [Published source, equation 1 and Table 1](https://academic.oup.com/rfs/article/38/6/1783/8010873).
- **Broadie–Chernov–Johannes:** the inspected 2007 draft supports the 215-month 1987–2005 futures-option sample, 28/35-day convention and finite-sample/rare-event caution. Its fixed-moneyness, option-price-denominator study is not a current cash-secured ETF replay. [Author manuscript, data section](https://business.columbia.edu/sites/default/files-efs/pubfiles/2612/broadie.pdf).
- **Christoffersen et al.:** intraday matched quotes/trades and the 2004–2012 sample are supported; the positive illiquidity premium compensates net long exposure in the authors' setting. It cannot be flipped into an automatic seller benefit. [Author manuscript](https://ruslangoyenko.com/wp-content/uploads/2019/09/illiquidity-premia-in-the-equity-options-market.pdf).
- **Carr–Wu:** the measure is based on an option strip and a 30-day synthetic variance swap; the source's realized-minus-swap sign differs from a short-variance-carry convention. Quote-availability selection and bid/ask treatment matter. This does not validate single-strike IV squared or a managed American CSP. [Published article](https://public.econ.duke.edu/~get/browse/courses/201/spr12/DOWNLOADS/WorkingPapers_Now_Published/cw_rfs_09.pdf).
- **Amaya et al. / OIC:** dealer reconstruction uses signed capacity records, whereas OI identifies outstanding paired contracts. The 3.3/6.4 volatility-point figures are model-based counterfactual maxima, not ETF-wall returns. [Working paper](https://cdn.cboe.com/resources/education/research_publications/gammasqueezes.pdf), [OIC mechanics](https://www.optionseducation.org/referencelibrary/faq/general-information).
- **Corsi / Hamilton:** the HAR paper's ARFIMA comparator uses a whole-sample fractional parameter; this limitation is explicitly acknowledged. Filtering and smoothing have different information sets. The proposed forecast is an adaptation, not a replication of either source. [Corsi](https://statmath.wu.ac.at/~hauser/LVs/FinEtricsQF/References/Corsi2009JFinEtrics_LMmodelRealizedVola.pdf), [Hamilton](https://econweb.ucsd.edu/~jhamilto/palgrav1.pdf).

These checks validate citation scope, not the papers' empirical results. Source identities must not be counted again as new research discoveries merely because a second reviewer read them.

## Practical data burden and smallest useful next step

The forecast minimum is 756+252+504 = **1,512 qualified origins**, about six complete trading years at 252 sessions/year before losses from data qualification, warm-up, stale-control support and label maturation. Its two-second option/underlying timing, historical model conventions, forward/carry/dividend vintages and measured target endpoints make ordinary EOD tables insufficient. No currently supplied dataset satisfies this burden.

OI and signed dealer inventory are unused by the one active IV forecast. Treat them as ancillary/deferred GEX evidence, not automatic forecast enrollment blockers. Apply the two-second freshness rule to quote-sensitive inputs; previously published rates/dividend schedules need valid as-of versions and a separately sealed age policy, not a newly published value every two seconds. The derived forward must identify all contributing input timestamps.

Do a bounded entitlement/schema/coverage check on an already-authorized small sample before considering a multi-year forecast run. Do not buy data or change access. If the sample lacks required vintages/endpoints, record DATA_NOT_AVAILABLE and defer the forecast. Meanwhile, same-entry episode audit and opening-cost annotations of existing sealed candidates can proceed independently. No more advanced models or paper accumulation is needed to resolve these concrete gaps.

## Source-compatible claims independently checked

Read-only inspection at supplied SHA d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba confirms:

1. CSP grossPremium uses per-share bid times multiplier; opening costs use per-contract commission/fees/slippage times leg count. Missing policy stays UNKNOWN. Capital-day yield is modeled maximum profit after opening costs divided by collateral and DTE.
2. Canonical proposal input receives `features` and evidence IDs separately from sealed T0. The qualifier checks scalar labels, timing and ID membership; it does not derive the scalar from a producer payload or enforce candidate-specific feature arithmetic.
3. Accepted scalar rules gate a whole snapshot. Candidate economics/ranks/quantities are retained; no native candidate cost-ratio, IV/RV expression or new delta-bucket selector is implemented by that path.
4. Typed soft evidence preserves provenance and fixes SOFT_RANKER/EMPIRICALLY_UNPROVEN. CURRENT_ONLY is not a historical PIT admission certificate. Existing source RV is a centered daily-return standard deviation annualized by sqrt252, not this target.

The appropriate deliverable is therefore a plain research design plus typed offline annotations, with any future adapter change separately reviewed. A syntactically accepted scalar/proposal would not prove the desired hypothesis was consumed. Upstream hashes establish content integrity, not empirical validity or verified deployment. No universal absence of external adapters or Production vulnerability is claimed.
