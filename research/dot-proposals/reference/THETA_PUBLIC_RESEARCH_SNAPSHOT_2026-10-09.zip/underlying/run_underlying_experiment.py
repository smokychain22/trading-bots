"""Ephemeral research analysis. No THETA source, broker, or external writes.
Data: Brown (2013), UCI Dow Jones Index, doi:10.24432/C5788V, CC BY 4.0.
Changes: chronological lagged feature and weekly evaluation aggregates.
"""
import csv,datetime as dt,statistics as st,random,json,hashlib,pathlib,collections
P=pathlib.Path(__file__).parent
raw=list(csv.DictReader((P/'dow_jones_index.data').open()))
# Whitelist: future-labelled columns never enter feature/outcome records.
rows=[{'stock':r['stock'],'date':dt.datetime.strptime(r['date'],'%m/%d/%Y').date(),'open':float(r['open'].replace('$','')),'close':float(r['close'].replace('$',''))} for r in raw]
assert len({(r['stock'],r['date']) for r in rows})==len(rows)
assert all(r['open']>0 and r['close']>0 for r in rows)
groups=collections.defaultdict(list)
for r in rows:groups[r['stock']].append(r)
panel=[];excluded=collections.Counter()
for stock,g in sorted(groups.items()):
 g.sort(key=lambda r:r['date'])
 for i,r in enumerate(g):
  if i<4: excluded['insufficient_lag']+=1;continue
  if i+1==len(g):excluded['no_next_observed_row']+=1;continue
  n=g[i+1];gap=(n['date']-r['date']).days
  if not 6<=gap<=8:excluded['irregular_next_week_gap']+=1;continue
  # Four consecutive weekly gaps must also pass the clock check.
  assert all(6<=(g[j]['date']-g[j-1]['date']).days<=8 for j in range(i-3,i+1))
  mom=r['close']/g[i-4]['close']-1; y=n['close']/n['open']-1
  split='development' if n['date']<dt.date(2011,4,1) else ('validation' if n['date']<dt.date(2011,6,1) else 'holdout')
  panel.append(dict(stock=stock,feature_week=str(r['date']),outcome_week=str(n['date']),momentum4=mom,regime='UP' if mom>=0 else 'DOWN',outcome_return=y,split=split,gap_days=gap))
with (P/'underlying_observations.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(panel[0]));w.writeheader();w.writerows(panel)
def mean(x):return st.mean(x) if x else None
def quant(x,p):
 x=sorted(x);q=(len(x)-1)*p;a=int(q);return x[a]+(x[min(a+1,len(x)-1)]-x[a])*(q-a)
rng=random.Random(20261009);res={};weekly=[]
for split in ['development','validation','holdout']:
 s=[r for r in panel if r['split']==split];weeks=sorted(set(r['outcome_week'] for r in s));diff=[];baskets=[]
 for week in weeks:
  wk=[r for r in s if r['outcome_week']==week];up=[r['outcome_return'] for r in wk if r['regime']=='UP'];dn=[r['outcome_return'] for r in wk if r['regime']=='DOWN']
  d=mean(up)-mean(dn) if up and dn else None
  if d is not None:diff.append(d)
  baskets.append(mean([r['outcome_return'] for r in wk]))
  weekly.append(dict(split=split,week=week,n_up=len(up),n_down=len(dn),up_mean=mean(up),down_mean=mean(dn),up_minus_down=d,all_mean=baskets[-1]))
 boot=[mean(rng.choices(diff,k=len(diff))) for _ in range(10000)] if diff else []
 res[split]={'stock_observations':len(s),'distinct_weeks':len(weeks),'by_regime':{k:{'n':sum(r['regime']==k for r in s),'mean_price_return':mean([r['outcome_return'] for r in s if r['regime']==k])} for k in ['UP','DOWN']},'weekly_paired_up_minus_down_mean':mean(diff),'weekly_paired_n':len(diff),'weekly_bootstrap_95pct':[quant(boot,.025),quant(boot,.975)] if boot else None,'all_stock_equal_weight_weekly_mean':mean(baskets),'stock_cost_sensitivity_only':{str(bp)+'bp':mean(baskets)-bp/10000 for bp in [10,25,50]},'worst_week_all_stock_mean':min(baskets)}
quality={'raw_rows':len(raw),'stocks':len(groups),'unique_dates':len(set(r['date'] for r in rows)),'start':str(min(r['date'] for r in rows)),'end':str(max(r['date'] for r in rows)),'duplicates':0,'nonpositive_prices':0,'raw_blank_cells_by_column':{k:sum(r[k]=='' for r in raw) for k in raw[0] if any(r[k]=='' for r in raw)},'excluded':dict(excluded),'admitted_exploratory_pairs':len(panel),'qualified_pit_pairs':0,'qualified_options_observations':0,'stocks_list':sorted(groups)}
(P/'underlying_results.json').write_text(json.dumps({'quality':quality,'splits':res,'weekly':weekly},indent=2)+'\n')
print(json.dumps({'quality':quality,'splits':res},indent=2))
