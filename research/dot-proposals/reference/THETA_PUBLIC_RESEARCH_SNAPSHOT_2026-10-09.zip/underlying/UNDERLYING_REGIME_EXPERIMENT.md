# Underlying-only historical regime experiment

## Verdict
INCONCLUSIVE for trend versus reversion; REJECTED for promotion into any THETA option policy. The dataset provides real, reproducible weekly stock observations but no qualified point-in-time option episode, no XLE observation, and no evidence of option profitability.

A four-week lagged trend split produced **+42.17 bp** average within-week UP-minus-DOWN difference in the June computational holdout, but only **three paired weeks** supported it; the descriptive 95% week-bootstrap interval was **−94.58 to +138.00 bp**. The row-pooled difference instead was **−40.89 bp**. Different time weights and regime imbalance reverse the sign. This is a useful falsifier of naïve row pooling, not evidence to pick a winning regime.

## Source and admission
Brown, M. (2013). *Dow Jones Index* [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5788V. Also credit the original study requested by the data README: Brown, M. S., Pelosi, M. & Dirska, H. (2013), “Dynamic-radius Species-conserving Genetic Algorithm for the Financial Forecasting of Dow Jones Index Stocks,” Machine Learning and Data Mining in Pattern Recognition, 7988, 27–41.

The official [dataset page](https://archive.ics.uci.edu/dataset/312/dow+jones+index) explicitly licenses the dataset under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). This bounded use relies on that dataset-specific grant, not on an unrelated software license. The original prices are retained unchanged; derived CSV/JSON parse dates and dollar strings, join chronological rows, and compute features/outcomes. No endorsement implied. The data are supplied without warranty. No account, paid feed or repository upload was used.

Official archive: https://archive.ics.uci.edu/static/public/312/dow%2Bjones%2Bindex.zip
35,074 bytes; SHA-256 08ad8e30915f071b46f6f5bef2b1ccdfe70aacfa31aee116117048ad2adec0bf.

## What was actually run
The protocol was saved before inspecting aggregate outcomes. Only `stock,date,open,close` were admitted to the feature frame. Momentum is close[t]/close[t−4]−1. The next observed weekly open-to-close return is the outcome. Vendor future-labelled columns, dividend countdowns and returns, and derived volume fields are not used. Four prior weekly gaps and the outcome gap must each be 6–8 calendar days. This is a weekly proxy for underlying trend, not the requested five-session momentum or H 2–5-day window.

All 750 stock-week rows span 30 supplied Dow constituents and 25 dates, January 7–June 24, 2011. There were no duplicate stock-date keys or nonpositive admitted prices. Contrary to the catalogue's general no-missing-values statement, each of the two historical-volume fields has 30 blank cells; neither enters this experiment. Four weeks of warm-up remove 120 rows and absent next rows remove 30: **600 final-vintage exploratory pairs across 20 outcome weeks** remain. There were no irregular-gap exclusions.

| Split by outcome date | Stock rows | Weeks | UP rows / DOWN rows | Row-mean UP / DOWN | Paired weekly UP−DOWN | Descriptive 95% interval |
|---|---:|---:|---:|---:|---:|---:|
| Development, through March | 210 | 7 | 114 / 96 | −6.43 / −3.83 bp | +15.50 bp, 7 weeks | −36.77 to +73.07 bp |
| Validation, April–May | 270 | 9 | 180 / 90 | +40.38 / +24.52 bp | +8.70 bp, 9 weeks | −65.72 to +85.83 bp |
| Computational holdout, June | 120 | 4 | 14 / 106 | −162.36 / −121.46 bp | +42.17 bp, 3 weeks | −94.58 to +138.00 bp |

Within-week contrasts use equal weight per paired week; row means use equal weight per stock-week. One June week has no UP stocks, so it is excluded only from the paired contrast, not from the all-stock summary. Do not silently compare these different populations. Stock observations share market shocks; 600 rows are not 600 independent temporal samples. The 10,000-draw, fixed-seed IID week bootstrap is descriptive, ignores any serial dependence, and is especially uninformative with three weeks. It is not a calibrated confidence guarantee. This ephemeral analysis is separate from the canonical THETA orchestrator; it was not admitted to its bounded manifest or claimed to comply with its separate symbol/resample caps.

The holdout all-stock weekly mean price return was −126.23 bp, with worst week −325.76 bp. Subtracting hypothetical round-trip stock costs of 10/25/50 bp gives −136.23/−151.23/−176.23 bp. These are cost sensitivities only. There are no bid/ask records, commissions, market impact or actual fills to justify an achievable return. The open-to-close outcome omits the prior close-to-next-open weekend gap and is not a full stock-holding total return.

## Why the evidence does not certify causal replay
- Weekly bar dates are period labels, not source event/receipt/availableAt timestamps. The 2014 donation date does not prove prices were known at any particular 2011 decision time.
- No first-known versions, revision history, complete split adjustment ledger, dividend cash-flow ledger, or security-identity lineage is supplied. Do not infer today's adjusted data or retrospective symbols were available then.
- This is a selected 30-stock, two-quarter 2011 panel. It cannot cover distinct crisis/volatility regimes or remove constituent-selection/survivorship concerns. It contains no XLE and is not representative of the current THETA universe.
- The site and source README disclose an all-down week in advance. June is untouched until the one-shot computation, but not an independently collected, analyst-blind test. No tuning followed the result.
- There are no option contracts, BBOs, sizes, delta/IV, expiry timestamps, assignment records, inventory, encumbrance, order/fill/cancel events, or fees.

## Useful next canonical falsifier
At the same pre-sealed opportunity timestamps, compare a fixed underlying trend/reversion classification only after recording its actual `availableAt`, quote authority and revisions. Keep option candidate economics identical. Evaluate matched within-date cohorts and report empty cells and effective independent dates. This dataset shows why an apparently favorable pooled regime statistic can be a time-weighting artifact. Do not install the regime filter on this evidence.

Reproduction: `python run_underlying_experiment.py`. The original input archive and result JSON accompany this report. The derived observation CSV is regenerated by the script rather than duplicated here; see ATTRIBUTION_AND_REPRODUCTION.md. The supplied raw future labels remain quarantined from features and were not used to fill the last missing outcome.
