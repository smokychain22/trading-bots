# Dataset attribution and reproduction

Brown, M. (2013). Dow Jones Index [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5788V.

Official catalogue: https://archive.ics.uci.edu/dataset/312/dow+jones+index
License: Creative Commons Attribution 4.0 International, https://creativecommons.org/licenses/by/4.0/.

Original study requested by the dataset README: Brown, M. S., Pelosi, M. and Dirska, H. (2013), Dynamic-radius Species-conserving Genetic Algorithm for the Financial Forecasting of Dow Jones Index Stocks, Machine Learning and Data Mining in Pattern Recognition 7988, 27–41.

The original 35,074-byte archive is included unchanged. SHA256: 08ad8e30915f071b46f6f5bef2b1ccdfe70aacfa31aee116117048ad2adec0bf. Its original notices remain inside the archive. The official catalogue's current dataset-specific CC BY 4.0 statement is the rights basis; this is not a separate certification of every upstream exchange right. No endorsement is implied.

Derived changes: parse date/dollar strings; chronological lagged features and subsequent-row returns; date split and descriptive bootstrap aggregates; separately labeled post-hoc reviewer sensitivities. No source prices were edited. The concrete retrospective KRFT identifier issue and missing historical availability/adjustment lineage remain unresolved.

To reproduce, extract this archive's dow_jones_index.data and dow_jones_index.names in this folder, preserving the original names, then run python3 run_underlying_experiment.py. It creates underlying_results.json and underlying_observations.csv. The observation CSV is deliberately omitted from this compact packet because the script reproduces it. Python standard library only; no network or account access.

Counts: 750 final-vintage rows;600 exploratory pairs; 0 PIT-qualified pairs; 0 option episodes. June has only 3 paired dates. The empirical-bootstrap endpoints are not a calibrated population confidence interval. Neither this data nor processing reproduction validates a THETA strategy.
