# Independent UCI review addendum

Reviewed 2026-10-08 UTC. This is an adversarial, post-hoc review of the fixed underlying-only experiment. It does not change its protocol, replace its registered estimates, create a new holdout, or supply option-performance evidence.

## Verdict

The published processing counts, chronological joins and aggregates reproduce. The June result remains INCONCLUSIVE and unsuitable for THETA policy promotion. This review identifies a concrete retrospective security-label problem and makes the effective sample/population problems more explicit.

## Concrete security-identity defect

The archive labels 25 January–June 2011 rows `KRFT`. The issuer's October 2, 2012 SEC-filed release describes that date as Kraft Foods Group's first day of independent trading, under KRFT. The predecessor's October 1, 2012 release states that KFT was retired and that MDLZ and KRFT would trade beginning October 2. Thus the archive's 2011 KRFT symbol cannot be treated as a contemporaneous security identifier. This establishes a retrospective or erroneous label; it does not establish which predecessor/security generated the prices, nor does it alone prove the return arithmetic is wrong.

Primary sources:
- [October 2, 2012 SEC-filed issuer release](https://www.sec.gov/Archives/edgar/data/1545158/000119312512412668/d418360dex991.htm)
- [October 1, 2012 issuer spin-off completion release](https://ir.mondelezinternational.com/news-releases/news-release-details/mondelez-international-completes-spin-its-north-american-grocery)

As a separately labeled post-hoc exclusion sensitivity, dropping this series changes June's equal-paired-week contrast from +42.17 to +40.04 bp; row pooling changes from −40.89 to −40.06 bp. The counts become 116 observations and the same three paired dates. This does not repair the other securities' missing identity, adjustment or first-known evidence. It is not a new validated universe or signal.

## June was computationally held back, but its outcomes were not secret

The [UCI catalogue](https://archive.ics.uci.edu/dataset/312/dow+jones+index) and source README describe an all-down week labeled May 27. Direct inspection finds:

- May 27 current-week open-to-close returns: 10 of 30 are negative
- May 27 vendor next-week-return labels: 30 of 30 are negative
- June 3 actual next-row open-to-close outcomes: 30 of 30 are negative

The catalogue's claim is consistent with a feature-row/future-label convention that exposes the first June outcome week, rather than the current-week returns on May 27. That interpretation is an inference from the raw rows, not a claim to have contacted the author. Keep the phrase “computational holdout, not analyst-blind independent test.” No evidence warrants resetting, re-sealing or relabeling June after observing it.

## The sign reversal has a missing-population component

Four June dates contain 120 observations, but June 17 contains no UP stocks. The following are different descriptive estimands:

| Estimator | June UP−DOWN |
|---|---:|
| All four dates, row-pooled | −40.89 bp |
| Only three paired dates, row-pooled | +11.89 bp |
| Three paired dates, equal date weight | +42.17 bp |
| Date-fixed-effect binary-regime OLS, weights nUP × nDOWN / nTotal | +79.85 bp |

Excluding the unpaired date alone changes the row-pooled sign. Hence the negative-versus-positive contrast should not be attributed solely to differing weights within a common population. The original report already warns about different populations; this decomposition quantifies that warning. None is a preferred return estimate or newly selected strategy statistic. The OLS number is an alternative descriptive weighting, without inferential standard errors.

## Three clusters do not support a convincing uncertainty statement

The paired-date effects are +138.00, +83.10 and −94.58 bp. Sampling three dates with replacement yields only 27 equally likely ordered resamples and 10 distinct mathematical means. Each all-identical extreme draw has probability 1/27, or 3.70%, greater than either 2.5% tail probability. Consequently the exact empirical-bootstrap inverse-CDF 2.5% and 97.5% quantiles are simply the observed minimum and maximum. They reproduce the reported −94.58 to +138.00 bp endpoints.

Ten thousand Monte Carlo draws do not create additional independent dates. The result describes this three-atom empirical distribution; it is not a calibrated population confidence interval, and it does not address serial dependence or unobserved regimes. Applying a linearly interpolated sample-percentile formula directly to the 27-item enumeration produces different numbers; that is not the inverse CDF of the exact discrete bootstrap law. The receipt records the quantile convention explicitly.

Leave-one-paired-week-out checks further show the result's fragility:
- Drop June 3: −5.74 bp
- Drop June 10: +21.71 bp
- Drop June 24: +110.55 bp

These are post-hoc sensitivity descriptions, not additional holdouts.

## What was actually verified

An isolated copy of the script regenerates both the 600-row observation ledger and results JSON bit-for-bit. A separate Decimal-based reconstruction verifies every feature/outcome join and four-week feature value; the 750 raw rows are unique by supplied symbol and date. Features precede outcome rows. The four historical feature gaps plus forward gap pass the existing range checks on this archive. No vendor future labels enter the original feature frame. Missing-volume fields are irrelevant to the selected features.

The catalogue's current CC BY 4.0 statement was independently inspected. Dataset attribution: Brown, M. (2013). *Dow Jones Index* [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5788V. Derived changes consist of chronology checks, return recomputation and explicitly post-hoc sensitivity calculations. No source endorsement is implied.

No first-known/revision lineage, timestamp-qualified option quotes, actual fills, assignment chain or performance sample was added. Qualified PIT pairs remain zero; qualified option observations remain zero. The review cannot independently establish the claimed ordering of local protocol creation and first result inspection from file contents alone. Treat preregistration chronology as author-declared unless an independently time-sealed run receipt is supplied.
