# Controlling specification

Read this original design together with THETA_Q_RESEARCH_DESIGN_V1_AMENDMENT_01.md. Amendment 01 controls the single primary estimand, all-origin cash arms, fixed economic horizon and benchmark; one-contract and maximum-loss comparisons are secondary. The original source version is preserved separately.

# THETA Q cost and strike selection research design

Prepared 9 October 2026 PKT. Research design only. No orders, account reads, Production changes, publishing or paid data. Candidate ID: THETA_Q_COST_CAPITAL_MATCHED_DELTA_20261009_V1. Status: SAVE_AS_RESEARCH_CANDIDATE; empirical verdict INCONCLUSIVE; no executable proposal or calibrated settings.

## Recommendation

Test a **cost-to-credit and collateral-time screen before imposing a higher delta floor**. Compare approximately 0.10, 0.20, 0.25 and 0.30 absolute-delta puts at the same underlying, decision time, expiry, eligibility and common outcome horizon. A smaller delta may deliver less premium relative to fixed fees and cash locked; a larger delta increases directional/assignment exposure. Neither is intrinsically superior, and delta is not a real-world probability of profit.

No new primary source inspected here establishes an optimal delta for conventional cash-secured sector-ETF puts. Published option-premium returns, delta-hedged returns and factor alphas must not be relabeled as Q return on reserved cash. The proposed filter is falsifiable and can fail by excluding the safest opportunities, selecting richer-but-riskier contracts or achieving insufficient net benefit after costs.

## Four newly inspected primary source identities

These four identities were checked against the supplied 99-entry source index and are absent. They are not four independent strategy validations. The GEX/VRP researcher confirmed no overlap with its five new identities. Abstract-only Büchner/Kelly was investigated as a lead but is not counted or used as an inspected full-method source.

### QSEL01 Broadie Chernov Johannes

[Understanding Index Option Returns, author-hosted manuscript](https://business.columbia.edu/sites/default/files-efs/pubfiles/2612/broadie.pdf). Inspected version is **May 3, 2007**, 51 PDF pages, preceding the 2009 Review of Financial Studies publication (DOI 10.1093/rfs/hhp032); do not claim the versions are identical. The sample is 215 months of S&P 500 futures options, August 1987–June 2005, generally 28/35-day maturities and fixed strike/spot moneyness. It compares observed return statistics with model-generated finite-sample distributions. Large OTM put-selling returns do not alone establish mispricing because nonlinear payoff and rare-event sampling matter. Excluding crash observations changes inference. A steep skew alone need not imply excess return. Limit: fixed moneyness is not a delta bucket, futures options are not American ETF cash-secured puts, and the inspected study is not a current executable-cost replay. Relevant sections: introduction, data pp. 6–9, inference discussion around pp. 19–24. Evidence grade: primary research, not independently replicated.

### QSEL02 Christoffersen Goyenko Jacobs Karoui

[Illiquidity Premia in the Equity Options Market, author-hosted PDF](https://ruslangoyenko.com/wp-content/uploads/2019/09/illiquidity-premia-in-the-equity-options-market.pdf). Inspected September 21, 2017 manuscript, associated with RFS 31(3), 2018, pp. 811–851. Uses S&P 500 constituent stock options, January 2004–December 2012, intraday LiveVol trades and contemporaneous NBBO, and daily delta-hedged option returns. Effective spreads help explain cross-sectional return differences. The authors relate positive buyer-side illiquidity compensation to net selling pressure absorbed by intermediaries. That sign must not be reversed into an automatic selling advantage. Large quoted premiums do not establish tradable seller profits. Limit: individual-stock, delta-hedged and intermediary-friction evidence is not an unhedged sector-ETF CSP test. Methods/data: PDF pp. 8–14; results and portfolio construction later in the manuscript. Primary source, unreplicated; proprietary historical inputs not downloaded.

### QSEL03 Goyal Saretto

[Can Equity Option Returns Be Explained by a Factor Model? IPCA Says Yes](https://academic.oup.com/rfs/article/38/6/1783/8010873), RFS June 2025, DOI **10.1093/rfs/hhae087**, published December 2024. Studies 1996–2022 individual-equity, primarily near-ATM daily delta-hedged calls, initially about 25 DTE. Table 1 delta-sort monthly returns: +0.22% gross, −0.68% after its costs; moneyness: +0.38%, −0.86%. Costs assume 30% effective/quoted spread. Full-sample-positive orientation is a hindsight convention, not a causal selector. No strategy has significant factor alpha after costs. Baseline excludes dividend holding windows. Source results are unreplicated and cannot establish low-delta ETF CSP economics. Source metadata and dates are detailed separately in the register.

### QSEL04 S&P Dow Jones Indices

[S&P U.S. Indices Methodology](https://www.spglobal.com/spdji/en/documents/methodologies/methodology-sp-us-indices.pdf), inspected **July 2026** version, 88 PDF pages. Official methodology describes sector membership based on GICS and capped market-cap weighting in the Select Sector families. Capping changes company weights within a sector; it does not remove the common sector exposure. Current composition or current methodology cannot be substituted for historical point-in-time membership. Full replication data are available by subscription; reading the methodology does not supply that history or authorize purchase. Relevant locations: index family pp. 4–6, construction, historical revisions and data availability p. 26. This is reproducible methodological context, not an option-return study. The web overview and PDF name some capped families differently; this research uses only their common sector-selection fact, not an unverified numerical cap rule.

## Economic distinctions the experiment must preserve

For an unhedged short put, approximate one-contract initial share-equivalent delta is M × |delta|. Moving from 0.10 to 0.25 increases that local sensitivity 2.5-fold at equal quantity, assuming the same multiplier. That is a local derivative, not an assignment probability, maximum-loss multiplier or guaranteed realized sensitivity. Delta changes with spot, volatility, time and model; jump exposure is not summarized by initial delta.

For strike K, multiplier M, quantity n, bid-side entry credit per share b and fees F, gross strike cash is nMK and maximum expiration option loss before fees is nM(K−b). Premium as a percentage of itself is not a capital return. Net cash-secured profit is compared with the actual cash/financing treatment under both policies. Count collateral interest only once and include a no-trade cash benchmark at the same horizon.

A deep OTM option can show a large percentage change because the denominator is small. It may simultaneously produce small dollars per cash-day, meaningful percentage spread and severe conditional loss when a crash reaches the strike. Conversely, its strike can materially reduce loss on moderately adverse paths. The research must retain both facts; a low-delta exclusion can discard real downside protection.

A higher premium caused by skew or an approaching event may compensate genuine tail risk. Neither high IV nor a steep put wing is an independent buy/sell verdict. Measure skew at synchronized same-expiry points and preserve uncertainty; do not substitute a later smoothed surface. The event/ownership/portfolio hard rules remain unchanged.

## Proposed research screen

This adds a versioned **offline soft exclusion**, never a rule that overrides canonical hard gates. In the reviewed source, conventional eligibility is broad; the new cost/capital inputs are not certified consumed runtime fields. Use a separate research record until a source-compatible adapter is reviewed.

Definitions in total dollars per proposed quantity:

- C: executable-reference entry credit, using bid-side or an explicitly validated limit-fill model.
- F0: known opening fees. F1: versioned expected or stress closing-fee schedule, identified as such.
- L: versioned adverse execution reserve beyond the price convention already used, calibrated only on prior data or explicitly an assumed scenario.
- D = F0 + F1 + L: projected friction budget for the planned management path.
- B = nMK: gross strike-cash budget; actual reserve is an additional reported field, not silently substituted.
- H: fixed planned horizon in calendar days or hours, stated consistently across candidates.
- kappa = D/C: projected cost fraction.
- ceiling = (C−D)/(B×H): maximum premium benefit per collateral-day **under that assumed friction budget**, if the option liability reaches zero by the horizon. This is not expected return or a guaranteed upper bound under a different cost path.

Minimal mathematical no-benefit test: if unavoidable known costs alone equal or exceed total credit, then even zero terminal liability leaves no positive option profit under those conditions. This is distinct from a discretionary stress-cost assumption.

Proposed primary research screen: retain only kappa ≤ 0.20 and ceiling ≥ h, where h is an explicitly versioned minimum opportunity-hurdle input fixed before outcomes are inspected. The 20% cap is an **unvalidated research constant**, not an optimized or recommended Production threshold. Sensitivities 0.10 and 0.30 are declared now and cannot replace the primary result after seeing test data. Do not silently set missing h, fees, liquidity or duration to zero. If h has no justified economic mandate, omit the capital pass/fail claim and report its ceiling distribution; cost-only testing can proceed independently.

Cost convention is critical. If C already uses the entry bid, do not subtract entry half-spread again. If the exit liability already uses the ask, do not subtract its half-spread again. Slippage is additional to that reference. A model calibrated on effective spreads cannot automatically assume passive fills at the midpoint. Future close cost and actual holding duration are unknown at entry: freeze their forecast or scenario, then score forecast error without backfilling future values into admission.

Use intended H for entry screening. Evaluate realized collateral-hours separately through closing or assignment; early exit cannot retroactively improve the entry screen. At a common outcome horizon, stock ownership and remaining liabilities stay in the wealth ledger.

## Matched comparisons and sizing

Primary descriptive pair: same underlying and 15:00 America/New_York decision clock on eligible regular sessions; choose the listed expiry closest to 45 calendar DTE within 30–45 inclusive (tie: earlier expiry). If no expiry qualifies, record no match. This narrows a research cohort only, not canonical Q eligibility. Target absolute deltas 0.10/0.20/0.25/0.30; choose minimum absolute delta error within 0.025 inclusive (tie: lower strike, then lexicographic public contract symbol). Snapshot must already be available at the decision clock; later quotes cannot be used. Common outcome horizon is that shared expiry settlement plus any required reconciled valuation of assigned shares; an early-exit arm holds released cash through the same horizon. Do not interpolate a nonexistent tradable strike. A missing target is a recorded missing pair; do not replace it after outcomes. Same contract cannot appear as two independent candidates if targets choose it.

Run three clearly separated estimands:

1. **One-contract comparison:** same quantity and management horizon, exposing the actual trade-off in premium, cash reserve and downside. Cash and maximum loss will differ.
2. **Common collateral budget:** integer quantities floor(Budget / per-contract gross strike cash), constrained by unchanged portfolio rules. Retain leftover cash with the same return convention. Contract count and share-equivalent notional can differ. Fractional quantities may appear only as a labeled diagnostic, never executable size.
3. **Common terminal maximum-loss budget:** size on nM(K−b), plus declared fee buffer. This is not the same as gross assignment funding and can fail cash capacity; enforce both. Short notional and collateral cannot generally remain fixed simultaneously. Do not call equal-delta or equal-premium sizing equal-risk.

Primary policy comparison tests the cost screen **within each delta bucket** against that bucket's unfiltered eligible baseline. This isolates cost selection from changing delta. Then report cross-bucket differences under each sizing scheme. Add a single comparator that raises the delta floor to 0.20 without cost screening, to test whether the cost feature adds value beyond that blunt change. Keep the same management benchmark, quote clock, capital horizon and no-trade alternative throughout.

Do not force reinvestment after early closes unless every arm uses the same point-in-time allocator and available opportunity set. No synthetic compounding at constant returns. Portfolio risk caps, known ownership acceptability, event exclusions, contracts/deliverables, quote quality and assignment capacity cannot be loosened to fill a cohort.

## Statistical plan

Freeze the universe and point-in-time membership before ranking. Include unselected eligible candidates, failed entries, rejects, no-fills, missing-data periods, delisted/adjusted instruments and adverse regimes. Sector ETFs form their own stratum; broad-market indices, broad ETFs and single stocks cannot be pooled as interchangeable instruments.

Primary metric: paired common-horizon net wealth difference per allocated capital, with after-cost realized/liquidation convention. Secondary metrics: net dollars/collateral-day, downside expected shortfall, drawdown, loss conditional on assignment, close feasibility, capital released and opportunity coverage. Win rate is descriptive only. Report net/gross and price-reference/cost sensitivity together.

Use chronological walk-forward estimation, purged overlapping labels, untouched holdout, and time-block/underlying-cluster inference. A bootstrap cannot invent a missing crash regime. Supplement observed-tail estimates with clearly synthetic joint spot/IV/liquidity stress. Report rare-tail uncertainty instead of claiming an adequate tail sample from many correlated contracts.

No minimum sample size is invented from a target success rate. Before data admission, define effective independent time blocks, regime coverage and a power calculation for a economically meaningful paired difference. Freeze h and all thresholds using a training-only process or economic mandate. Two predeclared sensitivity caps are robustness checks, not additional chances to win.

## Falsifiers and stopping decisions

- **Cost screen fails:** paired after-cost benefit is nonpositive or its interval remains inconclusive in untouched holdout; reject promotion even if win rate improves.
- **Risk substitution:** larger credits cause worse expected shortfall, assignment-chain losses or concentration beyond the existing risk budget; reject the selector or keep delta-specific exclusions rather than raising delta universally.
- **Coverage illusion:** improvement depends on dropping unavailable losers, widening target tolerance after the fact or treating failed closes as successful; reject the result.
- **Cost-model failure:** savings disappear under full side-crossing, reasonable adverse slippage or observed close-cost errors; reject claims of executable advantage.
- **Capital mismatch:** advantage disappears with equal collateral plus idle cash, or only appears when more short notional is silently purchased; reject the equal-risk claim.
- **Sector dependence:** pooled benefit comes from broad-index periods and fails sector-ETF holdout; reject transfer to sector ETFs.
- **Temporal leakage:** first-known timestamps, historical constituents, event dates, or surface features fail point-in-time checks; exclude contaminated episodes and rerun the frozen test without replacing its rules.
- **Tail ignorance:** observed sample lacks independent stressed periods or post-assignment outcomes; verdict remains INCONCLUSIVE, even with positive mean P&L.

## Minimum data and implementation handoff

Required: synchronized rights-cleared bid/ask/size/conditions; exact option metadata and corporate actions; first-known delta/IV and model conventions; frozen eligible/rejected opportunity sets; runtime/config provenance; contract-specific fee schedule; empirical or explicitly assumed fill/slippage model; every management checkpoint and failed close; assignment plus stock ledger; dated holdings/sector mapping; collateral and actual duration; price/rate/event vintages. Preserve missingness and never turn indicative prices into executable quotes.

No new engine is proposed. Reuse the existing research opportunity and replay contracts only after exact consumed-field review. Proposed output fields are research descriptors: friction_budget_dollars, friction_budget_method, cost_to_credit, planned_collateral_hours, scenario_net_premium_ceiling, capital_hurdle_version, target_delta, achieved_delta, matching_mode, unmatched_reason and after_cost_common_horizon_wealth. Their presence in this document does not certify schema compatibility or runtime consumption.

## Completed work and limits

Four new primary identities reviewed; no source performance independently replicated; zero historical episodes. Fourteen standard-library arithmetic checks pass in research_filter_checks.py. Synthetic examples demonstrate that a low-credit candidate can fail a cost screen while another candidate on the same collateral passes, and that missing costs/hurdles remain unscorable. They do not establish any delta-specific empirical relation. The 20% cap and 0.5 basis-point/collateral-day synthetic hurdle are arbitrary test constants only.

This design is independent of any single reported trade and supplies no position recommendation.

## Source compatible units and limits verified

At reviewed SHA **d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba**, [canonical-strategy-frontier.ts](https://github.com/smokychain22/trading-bots/blob/d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba/src/theta/canonical-strategy-frontier.ts) lines 429–472 computes modeledOpeningCosts.total from per-contract commission, fees and estimated slippage times option-leg count. Lines 735–748 use put bid in dollars/share, multiply it by the multiplier to obtain grossPremium in dollars per one structural CSP contract, and pass leg count 1 into opening-cost modeling. These are pre-allocation unit economics, not total position economics. Therefore modeledOpeningCosts.total/grossPremium is a consistent dimensionless **opening-only** diagnostic when inputs are known and positive. Do not divide contract-dollar costs by per-share premium, multiply costs twice by the multiplier, or mistake that ratio for a fully modeled round trip.

Null opening-cost policy produces UNKNOWN/null, preserved by the candidate contract. The source already exposes capitalDayYieldAfterOpeningCost using modeled maximum profit after opening costs over collateral and DTE; it is a maximum-profit scenario metric, not expected value. The proposed round-trip/management-horizon screen requires additional evidence and has no certified COST_TO_CREDIT enum or consumed candidate gate. A generic scalar feature does not prove enforcement on each sealed candidate. Keep the new screen offline and label SOURCE_GAP until that exact consumer mapping is independently approved and tested.
