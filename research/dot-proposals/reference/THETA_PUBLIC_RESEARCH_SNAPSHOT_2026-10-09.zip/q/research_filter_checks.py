"""Synthetic Q research-design arithmetic; no market observations or trading adapter."""
from decimal import Decimal as D
import json
from pathlib import Path

def assess(*,credit,fees,cost_reserve,collateral,days,cost_cap,hurdle):
    values=[credit,fees,cost_reserve,collateral,days,cost_cap,hurdle]
    if any(v is None for v in values):return {'status':'UNSCORABLE_MISSING_INPUT'}
    c,f,s,k,t,a,h=map(D,values)
    if min(c,k,t)<=0 or min(f,s,a,h)<0:raise ValueError('INVALID_RESEARCH_INPUT')
    drag=f+s
    ratio=drag/c
    ceiling=(c-drag)/(k*t)
    return {'status':'RETAIN_RESEARCH' if ratio<=a and ceiling>=h else 'EXCLUDE_RESEARCH','cost_to_credit':str(ratio),'net_profit_ceiling':str(c-drag),'net_ceiling_per_collateral_day':str(ceiling),'ceiling_is_expected_return':False}
base=dict(credit='15',fees='1',cost_reserve='3',collateral='9000',days='45',cost_cap='.20',hurdle='.00005')
tests=[]
def check(name,condition):
    assert condition,name
    tests.append({'name':name,'pass':True})
low=assess(**base)
medium=assess(**{**base,'credit':'120','fees':'2','cost_reserve':'4','collateral':'9600'})
low_good=assess(**{**base,'credit':'60'})
check('low_credit_excluded_by_cost_fraction',low['status']=='EXCLUDE_RESEARCH')
check('higher_credit_passes_arbitrary_research_thresholds',medium['status']=='RETAIN_RESEARCH')
check('low_delta_cannot_be_inferred_from_exclusion',low_good['status']=='RETAIN_RESEARCH')
check('known_cost_exceeds_full_credit_excluded',assess(**{**base,'credit':'3'})['status']=='EXCLUDE_RESEARCH')
check('missing_cost_is_not_zero',assess(**{**base,'cost_reserve':None})['status']=='UNSCORABLE_MISSING_INPUT')
check('missing_capital_hurdle_is_not_zero',assess(**{**base,'hurdle':None})['status']=='UNSCORABLE_MISSING_INPUT')
check('longer_capital_lock_reduces_ceiling',D(assess(**{**base,'credit':'60','days':'90'})['net_ceiling_per_collateral_day'])<D(low_good['net_ceiling_per_collateral_day']))
check('cost_threshold_equality_passes',assess(**{**base,'credit':'20','collateral':'1000','hurdle':'0'})['status']=='RETAIN_RESEARCH')
check('ceiling_not_expectation',medium['ceiling_is_expected_return'] is False)
# Equal-dollar collateral normalization cannot preserve contract notional when strikes differ.
check('equal_cash_differs_contracts',D('10000')/D('9000')!=D('10000')/D('9600'))
check('equal_contracts_differs_cash',D('9000')!=D('9600'))
check('max_loss_differs_from_gross_cash',D('9000')-D('15')!=D('9000'))
# If price is already at bid, do not also subtract entry half-spread in cash-flow P&L.
credit_at_bid=D('15');actual_close_ask=D('7');fees=D('1')
check('bid_ask_cashflow_no_double_spread',credit_at_bid-actual_close_ask-fees==7)
try:assess(**{**base,'collateral':'0'})
except ValueError:check('zero_collateral_invalid',True)
else:check('zero_collateral_invalid',False)
result={'evidence_tier':'STRUCTURAL_SYNTHETIC','historical_episodes':0,'tests':tests,'cases':{'low_credit_case':low,'medium_credit_case':medium,'larger_credit_same_capital_case':low_good},'threshold_warning':'20% cost cap and 0.5 basis point/collateral-day hurdle are arbitrary test constants, not optimized or recommended settings. No delta or real contract data used.'}
Path(__file__).with_name('synthetic_filter_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
