# THETA Q causal audit research design

Research-only design v1. Prepared 2026-10-09 PKT. Contains no account identifiers, owner fills, private mark history or protected records. No broker authority, Production changes, paid feeds or deployment requests. This document is a research design, not an executable proposal.

## Purpose and current finding

Determine whether conventional cash-secured-put selection and management create repeatable after-cost outcomes beyond exposure to underlying direction, volatility and time. A favorable isolated mark cannot establish this. Current empirical verdict: **INCONCLUSIVE**. Qualified historical quote paths admitted in this audit: **0**. No strategy is promoted.

Separate four questions:

1. Did the deployed rules consume valid point-in-time inputs and select the recorded action?
2. Why did the marked option value change mechanically?
3. Could a policy have closed using admissible contemporaneous quotes and an explicit fill model?
4. Does the policy improve the distribution of after-cost outcomes on the complete eligible opportunity population?

A pass on one question does not answer the others.

## Exact current source compatibility

Reviewed public source SHA: **d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba**. This is a reviewed source version, not a deployed historical version.

- [Paper bootstrap runtime policy](https://github.com/smokychain22/trading-bots/blob/d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba/src/theta/paper-bootstrap-runtime-policy.ts): Q conventional DTE 25–60; delta bands [0,0.25) and [0.25,0.5), with half-open boundaries verified in the reviewed consumer; minimum open interest 50, volume 10, maximum spread fraction 0.15. Ownership floor 0.3. Candidate/finalist decision quote ages 30 seconds. Earnings exclusion field is interpreted by the documented runtime comment as five trading sessions. These are engineering/bootstrap controls, not empirical optimum claims.
- [Management frontier](https://github.com/smokychain22/trading-bots/blob/d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba/src/theta/management-action-frontier.ts): policy/structural selection takes precedence over feasible passive fallback; missing economic selection is labeled SYSTEM_HOLD_MISSING_EVIDENCE, and economicModelState remains EV_MODEL_NOT_EMPIRICALLY_READY. Feasibility is not continuation value.
- [Profit-taking definitions](https://github.com/smokychain22/trading-bots/blob/d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba/src/research/profit-taking-experiment.ts): fixed gross capture benchmarks include 5, 10, 15, 20, 25, 30, 40, 50, 60, 75 and 90 percent. FIXED_80 is absent. These benchmarks are explicitly not the canonical management policy.
- [Profit-taking replay](https://github.com/smokychain22/trading-bots/blob/d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba/src/research/profit-taking-replay.ts): demands ALPACA_EXECUTABLE_MARKET authority, close ask, fees, adverse slippage and point-in-time quote/receipt/expiry validity. Missing decisions censor the path; later quotes cannot cure an earlier unresolved exit. Estimated exits retain actualFill=false.

The authority enum is a source contract label, not permission to relabel indicative prices as OPRA or to obtain account data. Any mapping from a permitted Paper reference must satisfy the upstream evidence contract. This design does not change that mapping or any hard gate.

## Data contract

Use a bounded, rights-cleared sanitized evidence bundle. Keep private lineage mapping outside public artifacts. Every row must retain:

- Random non-identifying episode ID, exact public option contract metadata, deliverable/multiplier status and underlying.
- Decision time, exchange-local session, provider quote time, receipt time, first available time, valid-through time, source/entitlement and revision vintage.
- Opening side and standardized research entry economics; actual versus simulated status; never label an estimated entry as actual.
- Synchronized bid/ask, sizes, venue/conditions, stale/locked/crossed flags, underlying observations, mark methodology.
- Greeks, units, model version, IV, rates, dividend schedule and corporate actions as known then.
- Frozen runtime/config versions, eligible/rejected candidates, rule outcomes/defaults, policy selection reasons and size/risk constraints.
- Close attempts, delay and failure state; explicit fees/slippage, assignment, resulting stock inventory and whole-chain cash flows.

UNKNOWN differs from zero, NOT_APPLICABLE and not observed. Retrieval time is not publication time. Reject post-decision features even if their economic reference date precedes entry. Reject mismatched contracts and adjustment statuses; reject expired quotes and insufficient size. No market-data endpoint or credential is needed to run the structural checks.

## Individual-episode audit

Chronology is a table of independently sourced timestamps, not interpolation between selected screenshots. Preserve every known adverse mark. Classify each price as reported display, indicative reference, synchronized qualified quote, estimated fill or actual fill.

For short put quantity q and multiplier M:

- Gross marked P&L = qM(open premium − mark).
- Realized option P&L = qM(open premium − actual closing debit) − actual fees.
- Expiry option P&L = qM[open premium − max(strike − terminal spot,0)].
- Assignment funding = qM strike; premium is not a substitute for cash capacity.

Capital reserve, terminal maximum loss and collateral-day use are separate quantities. Carry/interest is accrued once; option premium is not re-earned on stock assignment. Preserve chain-level stock losses after transfer to A/C.

## Counterfactual policy design

Primary matched experiment: identical eligible entries and common observation horizon; compare source-supported fixed gross 10/25/50/75 benchmarks plus existing versioned time, DTE and hard-risk policies. Keep dynamic EV policies unscored when calibrated forecasts are absent. Do not introduce an 80% identifier into a validator that does not support it; an H net-80 design remains separately versioned.

A fixed fraction f triggers at close debit ≤ opening credit × (1−f), in consistent dollars. The incumbent trigger is gross; report net outcomes separately. A net-of-cost trigger is a challenger with a distinct definition and denominator, not a relabeling of the incumbent. Round order caps down to a verified legal tick if a simulation represents an executable limit.

Use the first eligible decision timestamp and conservative ask-side reference, with explicit execution latency, available size and adverse slippage. Triggering does not imply execution. Failed closes remain exposed. Stop gaps fill only under the declared later-price model, never automatically at the stop. At the first unresolved checkpoint, censor according to the source contract. Empty observation paths remain open/unresolved, not zero-return winners. A later price cannot retroactively establish earlier availability or no first touch.

Compare either matured whole-chain outcome or common-horizon wealth, clearly named. Do not mix realized expiry returns with intermediate marks. Conditional counterfactual fills remain estimates even with complete quote data.

## Attribution without causal overclaim

Report signed delta/gamma/vega/theta/rate/dividend contributions only with matched input vintages and a documented repricing method. Declare Greek units. Report interaction and model residual rather than forcing totals to fit one favored explanation. A displayed midpoint/bid/last change can differ from executable liquidation value.

The same net P&L can arise from many combinations of spot, volatility, carry and quote methodology. With missing inputs the decomposition is not identifiable. Greeks explain local exposure; a Greek decomposition does not demonstrate the incremental causal effect of strategy selection. Delta is not a calibrated real-world probability of profit.

## Population test and falsifiers

Freeze the opportunity universe before outcome inspection, including non-selected contracts, rejects, no-fills, delistings/adjustments and illiquid periods. Preserve entry eligibility and risk budget across challengers. Group correlated opportunities by decision day/underlying; do not count dozens of strikes as independent evidence.

Use chronological train/validation/test windows with an untouched final holdout and label-availability-aware purging. Choose thresholds before examining holdout results. Report paired after-cost difference, uncertainty interval, expected shortfall, maximum drawdown, assignment/stock holding losses, capital-days, fill/close-feasibility and candidate coverage. Report actual sample counts and effective dependence limits. A win-rate aspiration is not an acceptance criterion.

Falsifiers include: advantage disappears at ask-side costs; improvement depends on late data; tail losses worsen beyond a preregistered risk budget; results rely on censored losers; an entry rule only looks good after exclusions; capital efficiency disappears after assignment; dynamic EV cannot beat transparent baselines out of sample. A negative or inconclusive result is an acceptable research output.

Structural challenge cases must include missing negative-mark history, future provider time, future receipt, expired validity, null fees, indicative-only authority, quote gap before a profitable touch, legal-tick rounding, gamma gap through a stop, halt during exercise risk, adjustment mismatch, and duplicate premium on assignment. Label all such tests STRUCTURAL_SYNTHETIC.

## Official mechanics and free-data limitations

- [OIC cash-secured puts](https://www.optionseducation.org/strategies/all-strategies/cash-secured-put): cash capacity and substantial downside remain despite premium income.
- [OIC assignment FAQ](https://www.optionseducation.org/referencelibrary/faq/options-assignment): American-style exercise and assignment can occur before expiry; halts do not remove writer obligations.
- [Alpaca historical option data](https://docs.alpaca.markets/us/docs/historical-option-data): indicative prices are derived rather than actual OPRA quotations. Public documentation is capability evidence, not a rights-cleared quote history.
- [Alpaca option quote schema](https://docs.alpaca.markets/us/docs/real-time-option-data): source timestamps, prices, sizes and quote conditions are distinct fields.

An inaccessible historical page, stale issuer NAV or delayed search snippet is not a qualified option path. Keep DATA_NOT_AVAILABLE and continue mechanical/source validation rather than fabricating fills. No paid subscription or account access is proposed.

## Completion and promotion boundary

An individual audit completes when each claim has a grade, timestamps or explicit gaps, exact source/config hashes and reproducible calculations. That can be INCONCLUSIVE. Population validation requires qualified data and out-of-sample evidence. SAVE_AS_RESEARCH_CANDIDATE does not imply APPROVED_FOR_TRADING. Any later operational change remains a separate approval.
