# THETA IV forecast design amendment version 2

Prepared 2026-10-09 PKT / 2026-10-08 UTC.

## Status and scope

Version 2 supersedes the forecast specification in version 1. Every version 1 file, including its manifest, is preserved byte-for-byte. The gamma/HMM structural findings remain unchanged. This amendment resolves specification gaps identified by independent review; it does not report new model or market results.

The sole hypothesis remains whether one causal ATM term-IV proxy improves physical-variance forecasting beyond a simple HAR-style baseline. There are zero market rows, fitted models or trading episodes. No synthetic suite was rerun. The earlier 14 assertions establish their original logical distinctions only; they do not validate version 2 market-clock coverage.

The controlling machine-readable document is `iv_information_research_design_v2.json`. Status is `AMENDED_DESIGN_DATA_NOT_AVAILABLE_NOT_EMPIRICALLY_SEALED`: it still requires qualified data and a pinned implementation before any empirical run.

## Correct the terminal clock and measure the missing segment

The version 1 target named the series' last-trading time but specified only underlying regular-session returns and overnight gaps. That leaves an undefined final segment when the option trades beyond the underlying regular close.

Nasdaq currently lists SPY options through 16:15 ET. Cboe distinguishes ETF option trading through 16:15 from the underlying 16:00 exercise-reference close, and distinguishes these products from SPXW. Neither current page certifies every historical series or venue schedule. New extended-session program provisions are not projected backward. [Nasdaq class hours](https://www.nasdaqtrader.com/Trader.aspx?id=optionshours) · [Cboe clock distinctions](https://www.cboe.com/document/tech-spec/document/technical-specifications/equity-options-extended-trading-hours-faq)

At each origin, bind the selected American, physically settled SPY series to the historically applicable, then-known venue/calendar version. Record separately:

- Option series scheduled last-trading timestamp and venue/session scope
- Underlying regular close
- Exercise-determination/reference timestamp and physical delivery convention
- Broker order and exercise cutoffs
- Option IV model's terminal-time convention
- Target endpoint, observed underlying endpoint and time the complete target first became available

A scheduled cutoff is not the time of the last observed option trade. Broker cutoffs and the exercise-reference close do not redefine the forecast endpoint. This is a forecast-only study; broker cutoffs can remain explicitly unknown/not applicable until a later operational study needs them. A generic “PM expiry” label is insufficient to establish any of these fields.

Let L be the verified series scheduled last-trading endpoint known at issue time. The same L controls both the return partition and ACT/365 denominator.

For an ordinary verified 16:15 terminal date:

1. Regular-session five-minute returns end at 16:00.
2. Append measured underlying midpoint returns over 16:00–16:05, 16:05–16:10 and 16:10–16:15.
3. End the target at 16:15. Do not add a terminal close-to-next-open return.

On nonterminal nights, retain one regular-close-to-next-regular-open squared log return. Do not add separate extended-session intervals inside that same gap, which would double-count them. A verified 16:00 series endpoint would have no final extended segment; it cannot be assumed from a different product's convention. Origin and terminal dates must have full underlying regular sessions. Historical exceptions require their actual metadata; unsupported exceptions remain excluded with reasons.

At each grid instant use the last eligible underlying bid/ask midpoint with observed time no later than that instant and no more than two seconds old. Preserve the feed/session, rights, first-seen and version fields. A missing or unlicensed 16:15 endpoint makes the target incomplete. No stale-close fill, interpolation, next-day substitution or silent truncation is allowed. Preserve that forecast origin as `LABEL_UNAVAILABLE` in the ledger. A later change in the then-known series schedule is `TARGET_SCHEDULE_CHANGED_CENSORED`, rather than a retrospective endpoint change.

The target becomes available only when its first complete constituent vintage and calculation are available. Its future observation timestamps are not invented publication times. The model's IV terminal convention may still differ from L; disclose that difference. IV remains a predictive proxy, not an asserted model-free same-horizon variance swap or a measured variance premium.

## Exact trailing variance inputs

Keep every underlying exchange session in a dated ledger, including early closes. Holidays form gaps between sessions. For session j, let C_j be the earlier of 15:30 ET and that session's actual regular close. A forecast origin must itself be a full session at 15:30; earlier shortened sessions end at their verified close.

For each interval (C_(j−1), C_j], Q_j is the sum of measured regular-session squared log returns plus the intervening regular-close-to-next-open gap. Let tau_j be exact elapsed seconds divided by 365 × 24 × 60 × 60. Define v_j = Q_j / tau_j. This quantity is annualized variance, not annualized standard deviation.

The three inputs are log(v_j), log of the arithmetic mean of the last five v values, and log of the arithmetic mean of the last 22 v values. The normalized momentum input is log(P(C_j)/P(C_(j−5))) divided by the square root of the sum of the five corresponding unannualized Q values. The horizon input is log((L−decisionAt)/year_seconds).

Missing any required endpoint invalidates the corresponding window. Never compress calendar-session lag arithmetic to the last 22 surviving rows. Zero momentum remains a valid number; nonpositive variance/log inputs stay unavailable. The existing THETA sqrt252 daily-return standard deviation remains a different diagnostic and is not silently substituted.

## Expanding training and prequential holdout

Version 2 chooses an expanding training window, not a rolling window.

- First fit: at least 756 qualified earlier origins with fully matured, available labels
- Refit: every 21 actual exchange sessions, anchored to the first development origin
- Each fit uses all then-admissible earlier rows from the sealed dataset start; no trailing truncation
- Next 252 qualified origins form the development segment; the holdout requires at least 504 qualified origins and 20 greedily counted nonoverlapping expiry windows
- All date boundaries, settings and the fit calendar are sealed before holdout-loss inspection

This is prequential OOS. An earlier holdout label may enter a later scheduled fit only after its target end and availability times. The holdout cannot select features, thresholds, hyperparameters or admission rules. This distinction replaces any implication that model parameters remain frozen throughout the whole holdout.

For each arm fit log Y = X beta. The positive-scale prediction is exp(X_new beta) multiplied by the training-only arithmetic mean of exp(training residual). No other learned predictor scaling, clipping or winsorization is introduced. Rank-deficient or nonfinite fits, invalid smearing, or nonpositive/nonfinite forecasts produce a recorded abstention until the next scheduled successful fit. Do not silently add ridge, remove columns, floor values or reuse an older model. Solver/version/rank tolerance and code hashes must be sealed before execution.

Each forecast records fit time, first/last training origin, latest target end, latest label availability, training count, transform/label versions and code/input hashes. No model was fitted to test these rules in this amendment.

## Missingness and inference stay on the calendar

The 63-session moving blocks are consecutive exchange-calendar sessions, not 63 surviving forecasts. Resample the dated rows, both arms and all missing/exclusion masks together. Aggregate losses only over common valid origins while retaining coverage counts. Flag any draw with no valid scored origins. Keep the 2,000-draw count and seed 20261009.

The 70–169-session stale-IV controls also use exchange-calendar offsets, with no wraparound or compression over missing dates. The common-origin restriction and lost coverage must be reported. These controls are diagnostics, not calibrated randomization p-values. The 20-window minimum does not guarantee precise inference.

## Remove unrelated OI requirements and separate carry freshness

OI and dealer inventory are unused by this IV-only design. Missing OI does not prevent an otherwise qualified forecast; it leaves any separate GEX status unavailable. OI timing tests and the dealer-sign proof remain valid ancillary work.

The two-second decision-time rule applies to the option quote sides and underlying market reference. Compute the forward at decision using that fresh underlying reference plus known, valid carry inputs. Rates or dividend news need not have been newly published within two seconds.

Use the latest already-available rate curve with valuation date on the origin or preceding exchange session. A provider dividend forecast curve needs the same valuation-date limit. An older issuer announcement may remain valid for a declared event until superseded, provided source/version coverage and the latest known amendments are established. Historical dividend forecasts remain labeled forecasts; later realized dividends cannot replace them. No missing first-known timestamp is synthesized, and unverified validity still blocks admission.

## Dataset burden is local to this experiment

The stated minimum is 756 + 252 + 504 = 1,512 qualified origins, roughly six 252-session trading years. Feature warm-up, label delay, up to 169-session stale-control support, missingness and nonoverlapping-window coverage may demand more history. Some support windows can overlap, so these figures should not be mechanically added.

This is an incubator constraint, not a prerequisite for every THETA study. Small same-entry audits, structural checks, candidate-cost annotations and other appropriately designed horizons can proceed without satisfying this forecast's six-year minimum.

The next step remains a bounded entitlement/schema/endpoint-coverage check on an already-authorized sample. If it lacks causal vintages or terminal coverage, record `DATA_NOT_AVAILABLE` and defer this design. No paid access, new execution engine, broker permission or source change follows from the amendment.
