# Reading order

This preserves the original challenge and literature discussion. For the current forecast specification use iv_information_research_design_v2.json and its amendment. Their clock, feature, training and ancillary-data definitions supersede conflicting v1 paragraphs. No empirical run is authorized or supplied.

# THETA gamma and volatility research challenge

Prepared 2026-10-09 PKT / 2026-10-08 UTC. Research version 1.

## Decision

Keep dealer-wall trading and HMM/deep-model enhancements deferred. Reject the inference that call/put open interest identifies dealer inventory sign. Retain one narrowly framed research design: whether a point-in-time ATM term-IV proxy improves a simple physical realized-variance forecast. This is a forecast-information experiment, not a variance-selling recommendation or a new execution strategy.

Fourteen synthetic assertions pass. There are zero admitted market observations, fitted forecast models, historical strategy episodes or fills. The source review adds five research identities absent from the stable 99-source index. No broker, private feed, paid service or repository mutation was used.

## New primary evidence

1. **Amaya, Garcia-Ares, Pearson and Vasquez, 2025 working paper.** Signed trader-capacity records, not OI alone, underpin its dealer-gamma reconstruction. The counterfactual volatility study is unreplicated here and supplies no dealer-wall trading return. See sections 2.2–2.3 and Table 7. [Primary working paper](https://cdn.cboe.com/resources/education/research_publications/gammasqueezes.pdf)

2. **OIC General Information FAQ.** OI counts outstanding paired long/short contracts. Opening on both sides raises it; closing on both lowers it; a transfer leaves it unchanged. The new number follows end-of-day clearing and pairing. It does not identify directional outlook or who holds which side. This is clearing mechanics, not a data entitlement, provider availability schedule or liquidity guarantee. [Official OIC FAQ](https://www.optionseducation.org/referencelibrary/faq/general-information)

3. **Carr and Wu, 2009, Variance Risk Premiums.** Its option-strip measure, 30-day horizon and bid/ask checks establish useful measurement boundaries; they do not validate H or a retail option policy. See equations 5–9, the data section and Table 8. [Published article hosted by Duke](https://public.econ.duke.edu/~get/browse/courses/201/spr12/DOWNLOADS/WorkingPapers_Now_Published/cw_rfs_09.pdf)

4. **Corsi, 2009 HAR-RV.** The published Table 5 uses rolling AR/HAR estimation but a whole-sample fractional-integration parameter for ARFIMA. Preserve that asymmetry. Our log-variance adaptation is a proposed baseline, not a reproduction of the author's volatility target. [Published article hosted by WU Vienna](https://statmath.wu.ac.at/~hauser/LVs/FinEtricsQF/References/Corsi2009JFinEtrics_LMmodelRealizedVola.pdf)

5. **Hamilton, Regime-Switching Models.** The author’s 2005 draft, identified on his publication page as the 2008 Palgrave chapter, distinguishes filtering through date t from smoothing with observations through later T. It also cautions that few state transitions make parameters hard to estimate. This is methodological evidence only. See filtering equations 11–12 and PDF p. 7. [Author manuscript](https://econweb.ucsd.edu/~jhamilto/palgrav1.pdf)

Exact identities, access states, limitations and deduplication are in `incubator_new_sources_v1.json`. Earlier Bondarenko, Fed VRP, Gao, Baltussen and Jones–Shemesh sources receive no new-source credit. These publications were inspected, not independently replicated.

## Gamma and walls challenge

The following is an original structural argument, not an empirical finding from the papers. Let OI_i be outstanding paired contracts, D_i net dealer contracts, Γ_i long-option gamma, M_i the contract multiplier and S spot. Under the stated long-gamma model, OI alone permits D_i anywhere in [−OI_i, OI_i]. Gamma-linked option-delta notional change for a local +1% spot move is G = 0.01 S² Σ(D_i M_i Γ_i); a delta-neutral hedge adjustment is approximately −G. This local approximation is not a finite-jump loss or flow guarantee. Consequently OI gives a symmetric feasible bound [−B, B], with B = 0.01 S² Σ(OI_i M_i Γ_i); it does not identify sign. The bound covers only the observed listed universe, not omitted OTC or other positions.

The synthetic chain has 100 calls and 100 puts, the same strike, gamma 0.02, spot 100 and multiplier 100. Dealer ownership of both long sides yields +$40,000 per 1% move; both short sides yield −$40,000; customer-to-customer ownership yields zero dealer exposure. All have identical public OI and strike concentration. Long calls and long puts both have positive gamma here. Assigning positive call OI and negative put OI is an inventory assumption, not a property of put gamma.

A high-OI strike may still be a useful descriptive variable. Calling it support, resistance or a dealer wall adds an unverified mechanism. Even signed gamma does not specify hedge timing, instrument, offsets, liquidity impact, customer response or whether price pressure is profitable after entry costs. Vanna/charm calculations inherit the missing signed inventory and also depend on surface dynamics and time conventions.

**Conditions for revisiting, not a second active experiment:** independently identified signed inventory, or clearly labeled proxy status; lagged OI vintages and expiry/exercise/corporate-action treatment; incremental prediction beyond spot distance, plain strike-grid distance, RV, trend, event and liquidity controls. Random pseudo-walls matched by strike-grid distance, sign inversions and one-session OI lags must be evaluated. Reject a dealer interpretation if equally strong results arise for signed-inventory alternatives or arbitrary matched strikes. A model may predict despite a false mechanism; that would require a separately named descriptive-feature study.

## IV and variance challenge

The original synthetic examples test three distinctions. First, trailing volatility 10%, IV 20% and hypothetical future physical volatility 30% give a positive backward gap while implied variance minus expected physical variance is negative (−0.05 in annualized decimal variance). Second, a 50/50 mixture of 10% and 30% vol has mean volatility 20% but root mean variance 22.36%. Third, two paths can have equal unweighted squared-return sums and different gamma-weighted sums. None is a P&L estimate.

Therefore define the target and units before any IV–RV threshold. A raw ATM IV, smile average, model-free implied variance, trailing realized variance and forecast future realized variance are distinct quantities. A candidate-specific American-option IV squared is labeled a proxy here. It is not promoted to a risk-neutral expected variance. IV rank and percentile additionally depend on a trailing window and are not premiums in variance units.

Even an estimated positive variance premium would not prove a CSP or spread edge. Delta, skew, jumps, covariance with losses, financing, collateral duration, discrete hedge costs, vol-of-vol, assignment and stress close feasibility remain outside this forecast experiment. Heston/SABR surface fit and a rough-volatility fit also cannot supply missing quotes or establish physical-return forecasts.

## HMM and advanced models challenge

The fixed-parameter two-state synthetic HMM observes the same four-value prefix. Its filtered high-state probability is 0.10338 in both continuations. Smoothing with a quiet future gives 0.00155; with a volatile future it gives 0.89541. Only the future changed. This demonstrates leakage of future information into historical state descriptions, not predictive skill.

A filtered implementation is still invalid for real-time evaluation if it uses full-sample fitted parameters, scaling, selected state count, Viterbi paths or state labels aligned using future outcomes. A valid later HMM challenger must freeze all training choices, filter sequentially and preserve earlier outputs when future observations are altered while parameters stay fixed. State names must be assigned from training characteristics; inferential uncertainty and transition counts must be reported. A deterministic trend/RV baseline remains the first comparator. No LSTM, Transformer, VAE or latent-state search is authorized or justified by this packet.

## The one active research design

**ID:** `THETA_INCUBATOR_IV_INFORMATION_20261009_V1`.

**Hypothesis:** adding one causal ATM term-IV variance proxy reduces forecast loss for future physical realized variance beyond a HAR-style, trend and horizon baseline. Economic motivation is that option prices may carry forward information and risk compensation. The experiment separates predictive information from a claim that selling the option earns compensation.

**Universe and clock:** SPY only, full regular sessions at 15:30 America/New_York, converted through the actual exchange calendar and DST. Choose from then-listed, standard PM expiries 30–45 calendar DTE: closest to 35 DTE, earliest expiry on a tie. No eligible expiry means no forecast. Early closes are excluded and counted, not silently treated as full sessions. This is an analyst-selected research horizon, not a change to canonical Q eligibility.

**Target:** from the decision’s point-in-time underlying reference to the selected expiry’s actual last-tradable timestamp, sum five-minute regular-session log-return squares and each close-to-next-open log-return square, then divide by exact ACT/365 elapsed years. Include remaining entry-day minutes, overnight/weekend gaps and the expiry-day segment. This is a discretely sampled quadratic-variation proxy, not the unobservable true integrated variance. Use split-adjusted price-only references, with no dividend total-return back-adjustment. Scheduled ex-distribution intervals are flagged because mechanical ex-dividend price changes remain in this target; it is not pure diffusion variance. Sampling/noise/overnight and endpoint limitations must be measured and kept identical across arms. A late label or revised bar cannot enter an earlier fit.

**Baseline:** OLS for log target using log trailing 1-, 5- and 22-session RV, trailing five-session log return divided by the square root of its unannualized squared-return sum, and log horizon year fraction; intercept and training-only residual smearing return a positive variance forecast. Every trailing interval ends at the decision cutoff; today’s later close is forbidden. A fixed trailing-22 variance and fixed λ=0.94 EWMA are simple diagnostics. A zero or missing positive-required variance/log input is not repaired with a hindsight floor: reject and count it, retaining the source reason. A genuine zero trend/return remains zero; missing remains UNKNOWN.

**Challenger:** exactly the same fit plus log ATM term-IV squared. Use the selected expiry and nearest-forward strike, lower strike on a tie, average call/put IV before squaring; require contemporaneous forward/carry inputs and both sides’ model conventions. Both option sides, the underlying and forward source must be observed within two seconds before the cutoff, available by it, and valid at it. Missing latency/vintage, forward or dividend evidence blocks enrollment. This two-second study limit is prespecified and does not certify execution quality. Changing strike, event filter, DTE range, management or risk sizing is outside version 1. The label is `ATM_IMPLIED_VARIANCE_PROXY_NOT_MODEL_FREE_RISK_NEUTRAL_VARIANCE`.

**One comparison:** the challenger versus baseline on identical qualified origins. No strategy selection, no trades and no forecast-based position sizing. If this limited information hypothesis fails, stop; do not rescue it with a hidden-state or deep-model sweep.

## Data admission and lawful acquisition

No qualified dataset was obtained for this design. Academic papers do not convey licenses to their OptionMetrics, Algoseek or capacity-tagged Cboe records. Publicly readable documentation does not grant bulk collection or redistribution rights. Use only already-authorized provider access or an explicitly licensed public sample with adequate historical provenance; do not buy a subscription, use a private feed or scrape around access controls. An EOD table without contemporaneous receipt/vintage evidence can support only a separately labeled retrospective illustration, not this PIT result.

For every field, retain provider/product/entitlement, observedAt, receivedAt, first availableAt, validUntil, revision identifier, raw-record hash and transformation version. Unknown rights or timing blocks admission. Quote price authority and predictive-feature authority are separate. Indicative or research-only data cannot be relabeled executable prices.

Required market fields: contract/OCC identity; underlying; strike/right; listed-at time; exact expiry/last-trade/settlement timestamps; deliverable and multiplier; exercise style; bid/ask/size with side timestamps; underlying quote; forward/rate/dividend as-of inputs; IV method, units and day-count; observed OI date and availability. Preserve adjusted/nonstandard and expired contracts in the rejection ledger, rather than dropping them invisibly. Early exercise, expiry removals, splits and provider corrections can alter OI without identifying directional initiation. Keep the first eligible vintage; future corrected history is a separate sensitivity result.

Target fields: regular-session and gap endpoints, five-minute sampling rule, corrections, halts, corporate-action adjustments, incomplete intervals and publication timestamps. Features may use only data available by cutoff. Training may use a target only after both its end time and availability time. No interpolation through an unobserved interval is treated as measured variance. Calendar/session version and OI carry-forward age are explicit.

The smallest safe next action is an entitlement and schema check on a bounded sample, followed by a sealed data manifest. If timestamps, quote-model conventions or target bars fail, record `DATA_NOT_AVAILABLE` and stop the empirical portion. Do not infer a dealer sign or fill missing values with zero.

## Out of sample protocol and falsifiers

- Seal code, feature definitions, source manifest, exact date ranges and content hashes before inspecting evaluation losses. Train on at least 756 matured qualified origins. Use the next 252 qualified origins for development/calibration, then an untouched holdout with at least 504 qualified origins and 20 nonoverlapping expiry windows. These are preregistered minimums, not a claim of adequate power for rare tails.
- Refit every 21 sessions using only then-matured labels. Purge every training label whose end or availability crosses the fit cutoff. Freeze preprocessing, smearing and universe rules. Do not randomly split overlapping option horizons. Overlapping daily origins do not become independent samples by counting them separately.
- Primary metric: paired mean QLIKE improvement, baseline minus challenger, where QLIKE = Y/f − log(Y/f) − 1. Also report variance-scale MSE, calibration, forecast-error tails, missingness and regime-specific coverage. Trend/RV bins and event strata use training thresholds and known-at-cutoff schedules.
- Inference: paired moving blocks of 63 trading sessions, 2,000 bootstrap draws, fixed seed 20261009; report sensitivity using nonoverlapping expiry windows. All origin counts, effective/block counts and intervals accompany the result. Bootstrap failure or too few independent windows leaves it inconclusive.
- Retain only if mean QLIKE is at least 2% lower and the lower 95% interval for paired improvement is positive. This practical 2% threshold is chosen in advance, not optimized. A nonpositive upper interval rejects added predictive value at the tested horizon; an interval spanning zero is inconclusive. A positive but sub-threshold gain is insufficient for retention.
- Negative controls: append/alter future records and verify historical feature/forecast invariance; reject future revised OI, quotes, IV and future-maturing labels; compare with 100 fixed backward IV-feature shifts of 70–169 sessions on common origins. The stale-feature comparison is a diagnostic reference, not a calibrated randomization p-value. Require real improvement to exceed its 95th percentile, and preserve every attempted variant in the trial register.
- Reject causal validity if any future record changes a past eligible result. Reject a practical information gain if it disappears under the predeclared stale-feature controls, is wholly driven by invalid/revised data, or requires changing rules after holdout inspection. If event/volatility cells lack support, report that limit rather than extrapolating.

No after-cost trading comparison is run under version 1. Any later option policy must be a separate, authorized experiment through the existing THETA engine, with synchronized executable entry/exit evidence, spread crossing, commissions, rejected/partial/failed closes, collateral-time, assignment and portfolio tails. Better variance QLIKE alone cannot authorize that step.

## Canonical integration boundary

This packet is a plain research design. It has not been passed to `validateDotProposal` or `evaluateDotShadowProposal`, and it makes no claim that those interfaces support this hypothesis. Its JSON is not an executable proposal schema.

A read-only source check now pins `d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba`; five inspected file hashes match the source audit manifest. Current branch drift and deployment remain unverified. Existing historical RV is a centered population standard deviation of daily log returns, annualized with sqrt252. The cycle preserves method/unit labels, but that quantity is not the proposed ACT/365 same-expiry variance target. [RV implementation](https://github.com/smokychain22/trading-bots/blob/d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba/src/theta/underlying-features.ts#L35-L50) · [Sealed technical metadata](https://github.com/smokychain22/trading-bots/blob/d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba/src/theta/theta-shadow-cycle.ts#L1057-L1090)

The existing VRP research module already reports caller-named IV−RV, IV/RV and IV²−RV² with no trade-signal authority; reuse these labeled diagnostics rather than recreate them. Typed ATM_IV/RV20/VRP20 records contain provenance and PIT state, yet are explicitly soft-ranker inputs and empirically unproven. `CURRENT_ONLY` must not be admitted to a historical test. The separate Dot qualifier receives one scalar per feature family with snapshot/evidence/timing checks; its inspected strict schema has no horizon/unit/derivation fields and does not itself join IV to RV. This is a verified interface boundary, not proof that no external adapter could exist. [Existing arithmetic](https://github.com/smokychain22/trading-bots/blob/d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba/src/research/volatility-risk-premium.ts#L51-L68) · [Typed evidence](https://github.com/smokychain22/trading-bots/blob/d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba/src/research/qualified-soft-feature-evidence.ts#L24-L40) · [Dot qualifier](https://github.com/smokychain22/trading-bots/blob/d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba/src/lab/proposal-consumer.ts#L12-L56)

The source integration receipt is retained separately; the cited pinned source supports this limited inspection. No repository source was executed or modified, and no current baseline configuration hash or validator acceptance is asserted.

A possible future integration would need typed forecast target/horizon/units, IV-model/time-convention metadata, signed-inventory evidence status, field-level first-seen lineage, training-end/label-availability checks, and candidate/snapshot-bound hashes. An opaque scalar named IV–RV or GEX is insufficient. Return forecast diagnostics and abstentions through a research-only adapter; canonical Q/H/D/A/C action mapping, ownership, AEGIS, collateral, quote authority and mandatory lifecycle gates remain authoritative. R stays a management route. Unknown dealer sign stays UNKNOWN. No duplicate execution engine is proposed.

## Reproduce the structural result

Run `python3 synthetic_identification_checks_v1.py --output synthetic_identification_results_v1.json` from this folder. It needs only Python’s standard library, reads no market data and uses no network. The 14 assertions cover opposite gamma inventories, zero dealer exposure, option-type sign, bounds, filtered-prefix invariance, smoothing leakage, normalization, delayed OI, revision vintages, future labels, backward/forward variance confusion, Jensen’s inequality and gamma weighting.

The original v1 machine-readable specification is retained separately; the included iv_information_research_design_v2.json and amendment now control; `incubator_new_sources_v1.json` is the five-source register. The manifest hashes are artifact integrity checks only, not empirical validation or canonical source acceptance.
