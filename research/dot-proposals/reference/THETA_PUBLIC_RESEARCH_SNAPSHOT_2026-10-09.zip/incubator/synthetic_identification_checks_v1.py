#!/usr/bin/env python3
"""THETA incubator structural checks, v1. All observations are SYNTHETIC.
No network, broker, market data, fitted returns, strategy execution or dependencies.
Run: python3 synthetic_identification_checks_v1.py [--output result.json]
"""
import argparse
import hashlib
import json
import math
from datetime import datetime
from pathlib import Path


def run():
    checks = []
    def check(name, condition):
        assert condition, name
        checks.append({"name": name, "passed": True})

    # OI counts outstanding pairs; dealer net positions can have either sign.
    spot, multiplier = 100.0, 100
    chain = [{"right": "call", "strike": 100, "oi": 100, "gamma": .02},
             {"right": "put", "strike": 100, "oi": 100, "gamma": .02}]
    def dollars_per_one_percent(dealer_positions):
        return sum(d * r["gamma"] * multiplier * spot * spot * .01
                   for d, r in zip(dealer_positions, chain))
    gex = {"dealer_long_both": dollars_per_one_percent([100, 100]),
           "dealer_short_both": dollars_per_one_percent([-100, -100]),
           "dealer_flat_both": dollars_per_one_percent([0, 0]),
           "assumed_long_calls_short_puts": dollars_per_one_percent([100, -100])}
    check("same OI permits opposite dealer gamma signs", gex["dealer_long_both"] == -gex["dealer_short_both"] > 0)
    check("same OI permits zero dealer inventory", gex["dealer_flat_both"] == 0)
    check("put versus call type does not supply inventory sign", gex["assumed_long_calls_short_puts"] == 0)
    bound = sum(r['oi'] * r['gamma'] * multiplier * spot**2 * .01 for r in chain)
    check("OI-only gamma bound includes all constructed inventories", all(-bound <= x <= bound for x in gex.values()))

    # Two-state HMM: fixed known parameters, binary emissions, same prefix.
    transition = [[.99, .01], [.01, .99]]
    p_one = [.2, .8]
    def forward(y):
        prior = [.5, .5]
        out = []
        for t, obs in enumerate(y):
            predicted = prior if t == 0 else [sum(out[-1][i] * transition[i][j] for i in range(2)) for j in range(2)]
            unscaled = [predicted[j] * (p_one[j] if obs else 1-p_one[j]) for j in range(2)]
            out.append([x / sum(unscaled) for x in unscaled])
        return out
    def smooth(y):
        filtered = forward(y)
        backward = [[1., 1.] for _ in y]
        for t in range(len(y)-2, -1, -1):
            for i in range(2):
                backward[t][i] = sum(transition[i][j] * (p_one[j] if y[t+1] else 1-p_one[j]) * backward[t+1][j] for j in range(2))
            norm = sum(backward[t])
            backward[t] = [x/norm for x in backward[t]]
        return [[filtered[t][j] * backward[t][j] / sum(filtered[t][k] * backward[t][k] for k in range(2)) for j in range(2)] for t in range(len(y))]
    prefix = [0, 0, 0, 1]
    quiet_future = prefix + [0] * 12
    volatile_future = prefix + [1] * 12
    f0, f1 = forward(quiet_future), forward(volatile_future)
    s0, s1 = smooth(quiet_future), smooth(volatile_future)
    check("filtered past is invariant to appended future with fixed parameters", f0[:4] == f1[:4] == forward(prefix))
    check("smoothed state changes when only future changes", abs(s0[3][1] - s1[3][1]) > .5)
    check("filtered and smoothed probabilities are normalized", all(abs(sum(p)-1) < 1e-12 for row in [f0,f1,s0,s1] for p in row))

    # Availability and revision time differ from the economic observation date.
    def dt(x): return datetime.fromisoformat(x.replace('Z', '+00:00'))
    versions = [
        {"observedAt":"2026-01-05T21:00:00Z", "availableAt":"2026-01-06T13:00:00Z", "revision":1, "oi":100},
        {"observedAt":"2026-01-05T21:00:00Z", "availableAt":"2026-01-07T13:00:00Z", "revision":2, "oi":150}]
    def latest_asof(cutoff):
        admitted = [r for r in versions if dt(r['observedAt']) <= dt(cutoff) and dt(r['availableAt']) <= dt(cutoff)]
        return max(admitted, key=lambda r: (dt(r['availableAt']),r['revision'])) if admitted else None
    check("same-day date cannot admit tomorrow's OI", latest_asof('2026-01-05T21:01:00Z') is None)
    check("first-seen OI does not borrow later revision", latest_asof('2026-01-06T14:00:00Z')['oi'] == 100)
    check("new cutoff can admit revision explicitly", latest_asof('2026-01-07T14:00:00Z')['oi'] == 150)
    decision_cutoff = dt('2026-01-06T14:00:00Z')
    labels = [{"labelEnd":"2026-01-06T13:00:00Z","labelAvailableAt":"2026-01-06T13:30:00Z"},
              {"labelEnd":"2026-02-05T21:00:00Z","labelAvailableAt":"2026-02-05T21:10:00Z"}]
    admissible_training = [r for r in labels if dt(r['labelEnd']) <= decision_cutoff and dt(r['labelAvailableAt']) <= decision_cutoff]
    check("future-maturing training label is purged", len(admissible_training) == 1)

    # A backward IV-minus-RV spread need not have the sign of expected variance carry.
    trailing_vol, implied_vol, future_physical_vol = .10, .20, .30
    naive_spread = implied_vol - trailing_vol
    hypothetical_expected_variance_carry = implied_vol**2 - future_physical_vol**2
    check("positive backward volatility gap can coexist with negative expected variance carry", naive_spread > 0 > hypothetical_expected_variance_carry)
    mean_sigma, root_mean_variance = (.1+.3)/2, math.sqrt((.1**2+.3**2)/2)
    check("mean volatility differs from root mean variance", root_mean_variance > mean_sigma)
    squared_returns_a, squared_returns_b = [.0001,.0009], [.0009,.0001]
    weights = [10.,1.]
    weighted_a = sum(w*x for w,x in zip(weights,squared_returns_a))
    weighted_b = sum(w*x for w,x in zip(weights,squared_returns_b))
    check("equal realized variance need not imply equal gamma-weighted exposure", math.isclose(sum(squared_returns_a),sum(squared_returns_b)) and not math.isclose(weighted_a, weighted_b))
    return {
        "evidence_class":"STRUCTURAL_SYNTHETIC", "version":1,
        "market_observations":0,"fills":0,"strategies_backtested":0,"performance_claim":False,
        "assertions_passed":len(checks),"checks":checks,
        "gamma_counterexample":{"chain":chain,"spot":spot,"multiplier":multiplier,"gex_dollars_per_one_percent_move":gex,"oi_only_interval":[-bound,bound]},
        "hmm_counterexample":{"prefix":prefix,"future_length":12,"filtered_high_state_probability_at_prefix_end":f0[3][1],"smoothed_with_quiet_future":s0[3][1],"smoothed_with_volatile_future":s1[3][1],"fixed_parameters":True,"model_fitted":False},
        "variance_counterexamples":{"naive_iv_minus_trailing_vol":naive_spread,"hypothetical_expected_short_variance_carry":hypothetical_expected_variance_carry,"mean_volatility":mean_sigma,"sqrt_mean_variance":root_mean_variance,"same_unweighted_qv":sum(squared_returns_a),"gamma_weighted_a":weighted_a,"gamma_weighted_b":weighted_b},
        "limitations":["Invented observations prove logical distinctions only.","No model was fitted, no data-source quality was established, and no strategy or return was estimated.","Gamma-weighted sums illustrate path dependence; they are not a full option P&L equation."]}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output')
    args = parser.parse_args()
    result=run()
    result['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    encoded=json.dumps(result,indent=2,sort_keys=True)+'\n'
    if args.output: Path(args.output).write_text(encoded)
    print(encoded)
