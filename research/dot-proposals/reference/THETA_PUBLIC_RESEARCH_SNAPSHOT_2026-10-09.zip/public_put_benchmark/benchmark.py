#!/usr/bin/env python3
"""PUB-PUT-IDENT-002: invented standalone fixture, no historical trade mapping.
No network, broker connection, order operation, or strategy-policy import.
"""
from dataclasses import dataclass,asdict,replace
from decimal import Decimal as D, ROUND_FLOOR
from pathlib import Path
import math,itertools,json,csv,hashlib
import numpy as np
from scipy.stats import norm
from scipy.optimize import brentq
from scipy.integrate import quad
ROOT=Path(__file__).resolve().parent
@dataclass(frozen=True)
class Inputs:
 spot:float=103.0
 strike:float=92.0
 sigma:float=.32
 maturity:float=37/365
 rate:float=.045
 yield_:float=.018
 multiplier:int=100

def put(x):
 if x.maturity<=0:return max(x.strike-x.spot,0.)
 d1=(math.log(x.spot/x.strike)+(x.rate-x.yield_+.5*x.sigma**2)*x.maturity)/(x.sigma*math.sqrt(x.maturity))
 return x.strike*math.exp(-x.rate*x.maturity)*norm.cdf(-d1+x.sigma*math.sqrt(x.maturity))-x.spot*math.exp(-x.yield_*x.maturity)*norm.cdf(-d1)
def greeks(x):
 t=x.maturity;s=x.spot;v=x.sigma;r=x.rate;q=x.yield_;k=x.strike
 d1=(math.log(s/k)+(r-q+v*v/2)*t)/(v*math.sqrt(t));d2=d1-v*math.sqrt(t)
 return {'delta_dP_dS':-math.exp(-q*t)*norm.cdf(-d1),'gamma_dDelta_dS':math.exp(-q*t)*norm.pdf(d1)/(s*v*math.sqrt(t)), 'vega_dP_dSigma':s*math.exp(-q*t)*norm.pdf(d1)*math.sqrt(t),'theta_dP_dElapsedCalendarDay':(-s*math.exp(-q*t)*norm.pdf(d1)*v/(2*math.sqrt(t))+r*k*math.exp(-r*t)*norm.cdf(-d2)-q*s*math.exp(-q*t)*norm.cdf(-d1))/365}
def csvout(name,rows):
 with (ROOT/name).open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
x=Inputs();p=put(x);move=.20;checks=[]
def check(name,passed,details):
 checks.append(dict(test=name,passed=bool(passed),details=details))
 if not passed:raise AssertionError(name)
# Independent integration verifies the price used for the inverse constructions.
zmax=(math.log(x.strike/x.spot)-(x.rate-x.yield_-.5*x.sigma*x.sigma)*x.maturity)/(x.sigma*math.sqrt(x.maturity))
integral=math.exp(-x.rate*x.maturity)*quad(lambda z:(x.strike-x.spot*math.exp((x.rate-x.yield_-.5*x.sigma*x.sigma)*x.maturity+x.sigma*math.sqrt(x.maturity)*z))*norm.pdf(z),-12,zmax,epsabs=1e-11)[0]
check('independent_payoff_integral',abs(p-integral)<1e-9,{'closed_form':p,'integral':integral})
paths=[];maxres=0
for day,ds in itertools.product([0,2,4,8],[-3,0,3]):
 new=replace(x,spot=x.spot+ds,maturity=x.maturity-day/365)
 iv=brentq(lambda v:put(replace(new,sigma=v))-p+move,.02,.9)
 after=replace(new,sigma=iv);res=put(after)-p+move;maxres=max(maxres,abs(res))
 allocations={f:[] for f in ['spot','sigma','maturity']}
 for order in itertools.permutations(allocations):
  state=x
  for factor in order:
   prev=put(state);state=replace(state,**{factor:getattr(after,factor)});allocations[factor].append(put(state)-prev)
 rows={k:float(np.mean(v)) for k,v in allocations.items()}
 paths.append(dict(elapsed_days=day,spot_change=ds,ending_sigma=iv,sigma_change_points=100*(iv-x.sigma),model_change=put(after)-p,spot_shapley=rows['spot'],sigma_shapley=rows['sigma'],time_shapley=rows['maturity']))
check('inverse_and_decomposition_family',maxres<1e-9 and all(abs(row['spot_shapley']+row['sigma_shapley']+row['time_shapley']+move)<1e-9 for row in paths),{'scenarios':len(paths),'max_root_residual':maxres})
csvout('iso_change_scenarios.csv',paths)
# Exact gross-credit-denominator net targets.
credit=D('65');thresholds=[];valid=True
for f,fee,tick in itertools.product(['.10','.25','.50','.75','.80'],['0','1.10','2.40'],['.01','.05']):
 target=D(f);cost=D(fee);step=D(tick);raw=(credit*(1-target)-cost)/100;ceil=(raw/step).to_integral_value(rounding=ROUND_FLOOR)*step;net=credit-100*ceil-cost
 valid &= net>=credit*target and credit-100*(ceil+step)-cost<credit*target
 thresholds.append(dict(net_target=f,round_trip_fee=fee,tick_scenario=tick,debit_ceiling_unrounded=str(raw),debit_ceiling_tick_valid=str(ceil),net_dollars_if_filled_at_ceiling=str(net)))
check('exact_threshold_family',valid,{'scenarios':len(thresholds),'arithmetic':'Decimal'})
csvout('threshold_scenarios.csv',thresholds)
quotes=[]
for bid,ask in [('.44','.46'),('.35','.55'),('.20','.70'),('.05','.85')]:
 net=credit-100*D(ask)-D('1.10');quotes.append(dict(synthetic_bid=bid,synthetic_ask=ask,synthetic_midpoint=str((D(bid)+D(ask))/2),net_if_fill_at_ask=str(net)))
check('same_midpoint_opposite_net_signs',len({q['synthetic_midpoint'] for q in quotes})==1 and min(D(q['net_if_fill_at_ask']) for q in quotes)<0<max(D(q['net_if_fill_at_ask']) for q in quotes),quotes)
csvout('spread_counterexamples.csv',quotes)
summary={'benchmark_id':'PUB-PUT-IDENT-002','evidence_tier':'STRUCTURAL_SYNTHETIC','historical_samples':0,'inputs':asdict(x),'model_price':p,'model_greeks':greeks(x),'illustrative_comparison_premium':'.65','illustrative_comparison_mark':'.45','model_relative_decline':move,'pure_time_days':brentq(lambda d:put(replace(x,maturity=x.maturity-d/365))-p+move,0,36.999),'pure_spot_increase':brentq(lambda s:put(replace(x,spot=s))-p+move,x.spot,140)-x.spot,'pure_sigma_change_points':100*(brentq(lambda v:put(replace(x,sigma=v))-p+move,.02,x.sigma)-x.sigma),'validation_families':checks,'note':'Fixture is invented and standalone. Comparison premiums do not calibrate the theoretical price. No probability or historical realization is assigned to any path.'}
(ROOT/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
