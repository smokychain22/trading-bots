# Public derivative: source compatibility audit

Source-only derivative; private episode references and unrelated access-interface detail removed. The original source pin, findings and counting limits are unchanged. Raw provenance inventories and compiled bundles are not included.

# Overnight THETA exact-source compatibility audit

Evidence class: SOURCE_AUDIT + STRUCTURAL_SYNTHETIC. Public repository reads and isolated research execution only. No private endpoint, account, broker, database, deployment, merge, or order actions. No publication performed by this audit.

## Frozen identities and ancestry

- Repository: https://github.com/smokychain22/trading-bots
- PR18 head: `48053140baa801da68bebfd6180f6b6f323f6ea8`, open, draft. Branch `dot/theta-h-dte3-5-research-v1`.
- PR API advertised base: `7a87bd240a5487893f8b074961e6eeaeb7450f46`, branch `codex/theta-v4-integration`. This is not the current live base-branch tip and must not be used as its substitute.
- Direct base branch lookup at 2026-10-08T22:45:07.806410Z: `d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba`. Frozen public source for this audit.
- Previously reviewed source `34b630e5814ce179cf958a0e3d70f5ee28da71b3` is an ancestor, six commits behind the frozen source; 24 files changed.
- Current V4 is seven commits ahead of the API-advertised base. PR head and current V4 diverge: V4 has nine exclusive commits, PR has three; common ancestor `2cb0d470f473132e80d44c2a2c051765e525afee`.
- `main` is `bc7ffbd5c87595040d69ce165dbcded52885b893`, an older line, 77 commits behind V4. It is not the relevant current V4 source or deployment evidence.
- No CI rerun, synthetic merge creation, or current merge-check certification occurred. Source compatibility is not merge readiness and is not a deployed-state claim.

Public commit URLs are the source references. Raw API inventories and downloaded source snapshots are deliberately not redistributed in this compact packet.

## Meaningful delta since the previous review

The research-relevant code delta across the six inspected commits is narrow:

1. New `src/lab/date-consistency.ts` exports `researchDteConsistent`.
2. `src/lab/proposal-consumer.ts` calls it before either H or D generator admission. H checks every contract; D checks the chain-level date and DTE. Failure adds `H_DTE_EXPIRATION_INCONSISTENT` or `D_DTE_EXPIRATION_INCONSISTENT` and leaves result null.
3. `tests/dot-date-consistency.test.ts` and consumer tests cover the correction.

Of twenty prior reviewed source/test identities, eighteen are unchanged. The two changed existing files are proposal-consumer and its test. Strategy registry, canonical hashes, contracts/validator, H and D generators, router, runtime policy, exit replay, management frontier, no-roll H lifecycle, recovery experiment and common-horizon contract retain their reviewed identities. Added helper has its own exact hash. The normalized ingestion/canonical frontier and Q/A/C consumer are also unchanged across the six-commit delta.

## Existing H proposal: compatible, with a revised quality boundary

The unchanged artifact SHA-256 is `a3a312f03928006336462249e05c90c24442030bd87f99084be29c1678d80b08`; canonical proposal hash is `d13341a5768535f44019c9aedfbfa2d83c0c9a5aeef465bc0410c5255e468033`; baseline configuration hash remains `cfdded1548790c092f6a24a00512b771780ca338fbc9a2565e860ce670dae9b3`. The current canonical validator was called in the new isolated harness and accepted it. No semantic proposal rewrite is required by this source delta.

Keep the original proposal version and hashes immutable. Add this compatibility/quality receipt separately. The original 78-assertion experiment was NOT rerun and remains historical synthetic evidence under its original pin. The two-case earlier finding is superseded for direct consumer behavior by the new correction, not erased.

Source correction semantics:
- Expiration must be a valid date-only string, decision timestamp a valid offset-bearing datetime, DTE a safe nonnegative integer.
- Expected DTE is expiration UTC midnight minus the decision instant's UTC date at midnight, divided by 86,400,000.
- This is calendar-day arithmetic, not trading sessions, exchange-local dates, hours remaining, or a listing calendar.
- A single inconsistent H member blocks the entire supplied chain, including a member outside the research window. Count these whole-chain data-quality exclusions separately from eligible 2-DTE contracts lost to the challenger. Do not drop the offending member silently and relabel the same snapshot qualified.
- Timezone reference must be explicitly preserved. For 2026-10-05 20:30 EDT, UTC date is October 6: expiration October 9 requires DTE3, not local-date DTE4. This is an after-session reference case, not proof of valid trading-session admission.
- Three-to-five DTE still includes Friday-to-Monday risk. Date consistency alone does not establish a standard listed expiration or event clearance.

## New boundary execution, not repetition

`isolated/boundary-harness.ts` ran once, invoking the existing current canonical consumer thirteen times plus three direct helper cases. All assertions passed. Full inputs and returned receipts are retained separately; this compact derivative reports their bounded result.

Consumer scenarios:
1. Consistent Monday→Thursday DTE3 control accepted.
2. Previously observed supplied-DTE3 / Wednesday-expiration mismatch blocked.
3. Good DTE3 member plus inconsistent out-of-window DTE99 member blocks entire H chain.
4. Good DTE3 member plus consistent DTE2 member evaluates normally with lattice rejection.
5. Friday→Monday DTE3 accepted, confirming weekend exposure remains.
6. Synthetic Saturday calendar expiration accepted by this date boundary. No claim this is a tradable listed contract.
7. OCC-looking contractId with a disagreeing encoded date still accepted by direct research adapter. IMPORTANT: normalized `option-contract.ts` explicitly cross-checks OCC identity, expiration, type, strike and underlying. This negative control isolates adapter responsibility; it is not a normalized-ingestion/Production bypass finding.
8. Fractional DTE blocked.
9. Impossible expiration date blocked.
10. Consistent D chain accepted.
11. Inconsistent D chain blocked.
12. D not blocked by an irrelevant malformed H chain.
13. H not blocked by an irrelevant malformed D chain.

Direct helper cases establish UTC-vs-local reference behavior and DST calendar duration. No P&L, market edge, provider quote qualification, trading-session validity or actual fill inference follows from these tests.

## Reusable canonical boundaries

### Q selection and management

`paper-bootstrap-runtime-policy.ts` labels policy `PAPER_BOOTSTRAP_ENGINEERING`, `BOOTSTRAP_NOT_EMPIRICALLY_OPTIMAL`: Q DTE25–60; absolute put-delta bands [0,.25) and [.25,.5); minimum open interest50, volume10, spread maximum.15; earnings exclusion5 trading sessions, ownership acceptability floor.3; candidate/finalist quote maximum age30 seconds. Signed positive put delta is invalid evidence. Q entry funnel attributes blocker stages; it does not rank, size, decide or relax thresholds.

The broad source lattice permits low-delta puts without requiring an exception to a narrower educational template. Historical admission still requires the deployed source identity, original inputs, complete rejection set and decision receipt. Current constants cannot establish which historical path executed.

The canonical frontier carries collateral/maxProfit/maxLoss and modeled opening costs; `expectedAfterCostEv` remains null. `buildManagementActionFrontier` may retain a feasible passive action when no supported policy/structural selection exists while explicitly reporting `SYSTEM_HOLD_MISSING_EVIDENCE` and `EV_MODEL_NOT_EMPIRICALLY_READY`. A displayed HOLD is not calibrated positive continuation EV. H retains its separate no-roll lifecycle behavior.

### Profit-taking benchmark reuse

`runProfitTakingReplay` supports gross fixed premium targets5/10/15/20/25/30/40/50/60/75/90 percent plus time/DTE/dynamic variants. FIXED_80 is absent from this canonical benchmark. Do not relabel75/90 as80 or add an invalid enum to the proposal. H net50/net80 remains a separately labeled research design unless another canonical supported interface is identified.

Replay requires actual qualified close-ask evidence, fees, adverse slippage, source/receipt/valid-through times and its exact authority enum. A broker mark alone cannot satisfy this. Missing evidence censors a policy path; later evidence cannot repair the earlier unknown. Fixed triggers are gross capture benchmarks; net P&L separately subtracts costs. Do not label Basic indicative or model marks `ALPACA_EXECUTABLE_MARKET` merely to run the schema.

### Q/A/C canonical and H/D shadow interfaces

- H/D: `evaluateDotShadowProposal`, exact existing registry/validator/generators; retain numerical economics and immutable baseline refs.
- Q/A/C: `evaluateDotCanonicalProposal`, sealed T0 replay bundle with integrity hashes, routing/snapshot identity; preserve existing canonical blockers, sizing, ranks and economics. It filters an allowed narrowed DTE window and does not rerank a new invented selector.
- A/C require strict, qualified, PIT-valid account-bound inventory whose stock hash matches the sealed bundle; committed short-call quantity must be known and nonnegative. A recovery stock lattice must remain identical and null-DTE recovery candidates are preserved.
- Entry consumers do not consume plannedHoldingDays or profitTakingChallengers; exit-comparison persistence uses plannedHoldingDays as maximum holding minutes while retaining all policy trials.
- Whole-chain and ledger public source is reusable for lifecycle research only with honest upstream entitlement/ownership/timing inputs. Do not treat a pure mathematical contract as a reconciled broker ledger.

## Reproducibility and side-effect boundary

Twelve unmodified pinned repository modules form the isolated source closure: declarative strategy/runtime policy/router/contracts, H/D research generators/common-horizon/spread economics, replay/target definitions, date helper and proposal consumer. Type-only store/orchestrator imports are erased. Canonical policy constants are reused; no production runtime application, store, HTTP gateway, PostgreSQL pool, provider adapter or broker client is imported. Zod comes from the previously prepared local dependency. Esbuild metadata records every bundled module; external modules are only node:crypto plus the harness's node:assert/strict and node:fs.

Node permission execution allows file reads only in the isolated artifact directory. The harness reads its unchanged synthetic proposal; results go to stdout and shell redirect. No network, child process, worker, database or broker capability is granted to the executed bundle. Compilation is separate local bundling; no package install and no source editing occurred. The separately retained test manifest records source hashes, dependency/tool hashes, bundle inputs, commands and result hashes.

## Source-compatible research recommendations

1. Preserve H proposal identity; pin new historical work to exact consumer/source hash plus baseline and proposal hashes.
2. Require canonical normalization/OCC identity, listing/deliverable/multiplier qualification, PIT quote/session/event evidence before the direct research consumer. Explicitly bind normalized as-of calendar convention to this UTC research boundary; quarantine mismatches rather than correcting labels after observing results.
3. Use the same prequalified opportunity snapshots for2–5 control and3–5 challenger. Report whole-chain quality blocks, contract-level hard rejections, eligible2-DTE opportunity losses and retained economics separately.
4. Register calendar DTE, exchange-session count, hours at risk, weekends/events and expected management opportunities as distinct fields. A narrowed DTE window does not establish lower tail risk.
5. For Q, research filters such as30–45 DTE fit narrowing; changed model/feature/lattice versions or delta bucket rewrites are not silently implemented by current consumer. Novel models and net80 designs remain plain versioned research designs until supported.
6. Private empirical evidence is DATA_NOT_AVAILABLE to this audit. No claims of repaired runtime management DTE, deployed correction, an actual option mark chronology or profitable strategy result.

## Scope boundary

This public derivative contains source and synthetic findings only. No runtime, account, database, order, deployment or actual merge was verified by the audit. The earlier 78-assertion suite was not rerun. The original proposal and hashes remain immutable.

## Addendum: actual consumed Q research-rule surface

Q baseline `theta-conventional` / `1.0.3-research` has configuration hash `4153e834d951a97edef86044d18e0be6ab77534512bc818280db4bf8af5626bb`, captured by read-only canonical registry enumeration; its full snapshot is retained separately.

The consumer is not limited solely to DTE narrowing: `researchRules` is consumed by `qualifyDotProposal`. Numeric GTE/LTE/BETWEEN rules over IV, LIQUIDITY, TREND, MOMENTUM and other registered feature enums are meaningful **snapshot-level gates** when accompanied by genuinely qualified, source-bound, PIT-valid numerical evidence. Every rule must pass before any branch candidates are retained. Rules can gate a full Q snapshot and the existing DTE narrowing can then filter canonical candidates; existing ranks/economics remain unchanged.

Read-set: proposal researchRule.feature/operator/lower/upper; feature evidence feature/value/evidenceId/snapshotId/observedAt/availableAt/validUntil/qualification; routing snapshot and timestamp; decision timestamp; sourceEvidenceIds; exact baseline and unchanged configuration references. Duplicate feature evidence is forbidden. Evidence must be finite and non-null, QUALIFIED, correctly bound, observed no later than availability, available no later than decision and not expired.

Critical limits: one numerical value per feature family across the snapshot, no candidate/contract ID in the feature schema, no units/derivation/calibration specification, no independent verification that a feature's semantic name matches its meaning. LIQUIDITY does not automatically mean every candidate's spread or size; IV does not automatically encode contract-level IV; TREND does not independently calculate causal momentum. The global feature enum is used, not a computed signal implementation. Do not fabricate such evidence or stuff contract-specific values into a snapshot gate. There is no DELTA enum, and changing `deltaResearchBuckets` is explicitly blocked by the consumer. Changed model/feature/lattice-version/management-policy references, option type, soft-feature set and action set are also blocked even where the initial proposal schema validates. Schema-valid is not consumer-supported.

Safe economic-candidate form, pending evidence review: a pre-registered snapshot IV or trend gate with explicit external derivation/units/evidence source contract, unchanged canonical baseline, and optional25–60→30–45 DTE narrowing. Per-contract delta/IV/spread ranking or advanced modeling must remain a plain versioned research design for supported integration, not falsely represented as consumed behavior. No Q proposal was generated in this audit.

Later publication checkpoint: after the frozen initial PR observation, the coordinator verified documentation-only head `b99ee858416d2e21c5f6cfe4cae92e22ddd9aade` with parent48053140. This audit did not recheck its CI and retains48053140 as its independently frozen PR/source context. The later public artifact has a separate publication/CI receipt; this does not change frozen V4 d0b source compatibility.
