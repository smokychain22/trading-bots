# E3 external replication-source recheck

**Decision: NO_NEW_EVIDENCE.** Retain S06 status `CORRECTED_HISTORY_NOT_REPLICATED`. Do not add a new alpha hypothesis, claim another replication, or promote E3/THETA D.

## Exact snapshot and delta

Public repository `vilkovgr/0dte-strategies`, main commit **85a447c4c155b60143a51c0496641e0f0b892321**, latest commit dated2026-08-26T20:20:47Z. API commit history contains21 commits and none after the already-indexed August correction. Prior S06, accessed2026-10-08, explicitly retained this correction and recorded no independent replication; it did not record an exact commit, so byte-for-byte equality to the earlier fetch cannot be proved. The new result is an exact pin and unchanged-evidence assessment, not a newly discovered correction.

[Immutable known issues](https://github.com/vilkovgr/0dte-strategies/blob/85a447c4c155b60143a51c0496641e0f0b892321/KNOWN-ISSUES.md) still says derived prediction parquet and LFS panels are stale, LFS budget exceeded, and paper/docs revision ongoing. This is the maintainer's current source statement, not an independently attempted LFS download. No bulk data was requested.

## Targeted inspection

- **Costs:** corrected code scales fraction-of-spot spreads into percent-of-spot P&L and uses direction×gross−cost, so short-side direction cannot add transaction costs. Net-label training must also be rebuilt when the cost definition changes. Existing model-zoo0.5bp “net” path omits bid-ask costs and cannot serve as realistic net performance. These remain the already-known correction, not fresh evidence. [Correction commit](https://github.com/vilkovgr/0dte-strategies/commit/85a447c4c155b60143a51c0496641e0f0b892321)
- **Small guard:** `cost_units.py` is only2375bytes, MIT-licensed code, and checks mean cost against a broad0.2–50bp plausibility band. Source inspected, not executed. This catches some scale errors; it is not a universal dimensional proof, candidate-by-candidate cost validation or executable-fill model. No new guard commits/tests appeared after August.
- **Same-clock alignment:** conditional protocol selects10:00 quotes, IV/skew/surface inputs and uses lagged realized moments/P&L. Training scaler/model fit on rows strictly before each tested row. These useful source controls are not proof every source observation was available at the stated time: provider first-seen/availability is not established by equal10:00 labels. This clock does not transfer directly to E3's existing same-clock60-minute/midday question.
- **Sample selection:** representative moneyness is chosen before the walk-forward loop from the full supplied panel by highest day/row coverage, then ties by deviation/lexicographic key. It is not selected by realized profit, but future coverage can influence which configuration is retrospectively evaluated. For a prospective test, preregister the configuration or choose it within each training window. Inner joins and dropna further restrict the sample; report excluded dates, and treat shifted previous-row values carefully when dates are missing. This is a bounded source-method caveat, not a newly measured performance effect.
- **Tests:** current test harness has table parity for selected outputs and only exit-code smoke testing for the conditional protocol. A green smoke test does not verify conditional estimates, sample length, timing or economic validity. No external test code was run.

## Data and licensing

Repository LICENSE is MIT. README identifies raw Cboe bars as proprietary and not redistributed; MIT code licensing is not blanket permission for third-party raw data. Tree contains LFS pointers for required option/strategy/moment panels, small summary/configuration CSVs and reference tables. The only explicit tests/fixtures sample is a LaTeX paper fixture, not synchronized option quote episodes. Small summary CSV is a derived result, not a point-in-time sample supporting independent execution replay. No new small, sufficient, appropriately documented sample dataset was established.

Open issue3 reports truncated option/VIX panels and conditional sample mismatch; issue4 offers independent-data gross replication claims without a delivered reproducible panel/tables in the inspected issue body. Both predate the prior S06 review and remain third-party reports, not accepted verification or fresh usable evidence. No outreach was sent.

## Transfer to THETA

Transfer only existing methodological safeguards: explicit currency/spot/percent units; cost sign independent of direction; reconstruct targets after economic-definition changes; train-only configuration selection; matched clocks and complete exclusion accounting; numerical parity instead of smoke-only success. Apply these to THETA's existing canonical per-structural-unit USD candidate costs and synchronized-leg close-feasibility research, without importing the external percent-of-spot thresholds.

No performance transfer: SPXW0DTE cash-settlement evidence does not validate THETA D's7–60DTE equity/ETF options, early assignment, physical-stock lifecycle or stressed close feasibility. The external source does not cure missing THETA executable quotes or empirical episodes. Existing E3 remains research-only and its preregistered null is unchanged.

## Scope and stopping condition

Read-only API/raw-source inspection, nine source/text artifacts plus public metadata; no package install, external source execution, bulk archive/LFS fetch, provider login, paid data, broker action, PR or external comment. Stop this branch of research because no post-S06 correction, qualified sample or independent evidence upgrade was found. Detailed external source hashes and Git blobs are retained separately; the compact package manifest covers the included review report.
