"""New standalone structural identities; no paper dataset or historical return replication.
All prices/deltas/costs/interest values are invented transparent numeric fixtures.
"""
from decimal import Decimal as D
from pathlib import Path
import json
P=Path(__file__).parent
checks=[]
def chk(id,a,b):
    assert a==b,(id,a,b)
    checks.append({'id':id,'actual':str(a),'expected':str(b),'passed':True})
# Premium received is offset by short liability. Spread/fee makes immediate wealth lower.
chk('PREMIUM_LIABILITY_ZERO_INITIAL_WEALTH',D(100)-D(100),D(0))
chk('OPENING_CROSS_AND_FEE',D(100)-D(120)-D(1),D(-21))
# New simple forward A comparison: t0 S90, call95 credit1/share, incremental fee1; no dividend/interest.
cc_rows=[]
for s in map(D,['70','90','95','110']):
    hold=100*(s-90)
    cc=hold+100-1-100*max(s-95,0)
    sell=D(-1) # S0 qualified price same as initial mark; explicit one-dollar sale fee
    gap=cc-hold
    chk('AC_GAP_'+str(s),gap,D(99)-100*max(s-95,0))
    cc_rows.append({'terminal_spot':str(s),'wait_forward_pnl':str(hold),'cc_forward_pnl':str(cc),'sell_forward_pnl':str(sell),'cc_minus_wait':str(gap)})
# Different inherited bases change reported chain PnL equally, not forward contrast.
for inherited_cost in map(D,['9000','10000','12000']):
    wait_chain=D(11000)-inherited_cost
    cc_chain=D(9500)+99-inherited_cost
    chk('BASIS_INVARIANT_GAP_'+str(inherited_cost),cc_chain-wait_chain,D(-1401))
# Lagged-delta accounting identity, three intervals; no trade/hedge inferred.
S=list(map(D,['90','95','88','100']));C=list(map(D,['1','3','.2','5']));deltas=list(map(D,['.3','.5','.2']));b0=D('.7')
components=[]
for i in range(3):
    ds=S[i+1]-S[i];dc=C[i+1]-C[i]
    passive=100*b0*ds;dynamic=100*((1-deltas[i])-b0)*ds;residual=100*(deltas[i]*ds-dc)
    total=100*(ds-dc)
    chk('ATTRIBUTION_IDENTITY_'+str(i),passive+dynamic+residual,total)
    components.append({'interval':i,'passive':str(passive),'dynamic':str(dynamic),'delta_hedged_residual':str(residual),'total_before_costs_dividends_carry':str(total)})
chk('ATTRIBUTION_PATH_TOTAL',sum(D(x['total_before_costs_dividends_carry']) for x in components),D(600))
# Equal quantity Q/D; short put100 credit2, protective put95 costs.50.
# Q opening fees1 ->199 net; D opening fees2 ->148 net; no additional exercise fees fixture.
qd=[]
for s in map(D,['0','80','94','94.49','95','110']):
    shortloss=100*max(100-s,0);longpayoff=100*max(95-s,0)
    q=D(199)-shortloss;d=D(148)-shortloss+longpayoff
    chk('QD_HEDGE_INCREMENT_'+str(s),d-q,longpayoff-D(51))
    qd.append({'terminal_spot':str(s),'Q_pnl':str(q),'D_pnl':str(d),'D_minus_Q':str(d-q)})
chk('QD_AT_BOUNDARY',D(100)*(95-D('94.49'))-51,D(0))
# Reserve is not interest. If both reserved and unreserved cash earn the same rate, incremental income is zero.
reserved=D(9500);rate=D('.04');days=D(30)
chk('RESERVE_RELEASE_WITH_SAME_YIELD',reserved*rate*days/365-reserved*rate*days/365,D(0))
receipt={'classification':'STRUCTURAL_SYNTHETIC_ALGEBRA_ONLY','academic_history_reproduced':False,'historical_observations':0,'source_performance_numbers_imported':False,'checks':checks,'passed':len(checks),'AC_forward_rows':cc_rows,'lagged_delta_components':components,'QD_equal_quantity_rows':qd,'scope':'New algebra/control fixtures only; no existing33 lifecycle assertions or10 source checks rerun.'}
(P/'algebra_receipt_v1.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'passed':len(checks),'academic_history_reproduced':False,'historical_observations':0}))
