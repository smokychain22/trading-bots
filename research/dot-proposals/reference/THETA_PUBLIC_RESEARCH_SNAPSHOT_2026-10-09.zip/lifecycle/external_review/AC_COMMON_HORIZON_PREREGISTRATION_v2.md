# AC-RECOVERY-COMMON-HORIZON-20261009-v2

Controlling version2. Supersedes v1 only for the clarifications recorded below; v1 is preserved unchanged. No economic endpoint, candidate rule, source evidence or algebra result has changed.

Status: RESEARCH_DESIGN_ONLY; evidence currently STRUCTURAL_SYNTHETIC. Source reading is documented separately in PRIMARY_SOURCE_REVIEW_v1.md. No empirical superiority or decision rule is calibrated. This document is not an executable proposal or request to enable a route.

## A. Question, units and target population

Among already-assigned, verified settled stock lots at an eligible management decision, does writing one specified covered call improve after-cost common-horizon wealth relative to holding those same shares or selling them? This is a conditional post-assignment question, not evidence that the preceding put-selection rule works. Past put losses remain in whole-chain reporting but cannot be used twice as a forward cost.

Primary t0 is the first canonical eligible management decision after assignment receipt and settled ownership reconciliation, rather than a retrospectively favorable recovery date. Use one primary decision per assigned lot; subsequent management decisions require a separately labeled longitudinal analysis.

Unit: one immutable chain/lot-decision, normalized to a standard100-share lot and one corresponding call only when the actual standard deliverable permits it. Keep actual quantity for primary dollars. A contract with adjusted delivery, incomplete lot mapping, unknown settlement or unresolved call/share claim is not admitted. All existing hard gates, event controls, portfolio limits and source capabilities remain unchanged.

Common clock: decision time t0; T is the close of the twentieth scheduled exchange trading session after t0, fixed using the scheduled exchange calendar known at t0. Missing quotes, strategy ineligibility or later data gaps never move T; they produce missing/unresolved labels at that fixed horizon. Any exchange-calendar revision is recorded separately and does not silently reschedule the preregistered endpoint. Retain calendar hours and overnight/weekend exposure separately. The call candidate must have expiry no later than T under the preregistered eligible set. No rewritten call after expiry/call-away in this first experiment. Labels are available only when the actual settlement/entitlement evidence has arrived after T; a nominal T+2-session review is an administrative checkpoint, not proof all records are complete. Do not shorten the cash arm's horizon at its early sale.

Same starting marked account NAV and stock lot for all arms. Starting NAV convention is fixed across arms. Actual liquidation prices and costs enter each arm's cash ledger, so crossing the spread is not erased by using the same initial mark.

## B. Arms and invariant treatment

1. RECOVERY_WAIT: retain stock through T, with mandatory inherited risk actions still enforced. Actual entitled dividends plus marked retained stock enter wealth.
2. SELL_STOCK: hypothetical qualified sale at the decision, after stock spread/fees; proceeds held as cash through T. Primary comparison gives no assumed excess redeployment benefit. Apply only a verified cash interest schedule; otherwise carry is UNKNOWN for empirical labels and zero only in explicitly marked sensitivity scenarios.
3. SELL_CC: identical owned lot plus one fixed, preselected call, with strike/maturity determined using only t0 inputs and existing research eligibility. Include premiums, short liability or close debit, fees, any mandatory close failures, actual/qualified modeled assignment, changed dividends and resulting stock/cash state. Early assignment is an outcome, not an action selected with foresight.

Freeze this deliberately simple research candidate rule before holdout: among contracts admitted by all existing gates, retain standard calls with7–30 calendar DTE and expiry no later than T; choose the latest such expiry and then the strike closest to1.05×the qualified t0 spot. Break equal strike-distance ties toward the higher strike, then by contract ID. This is an arbitrary transparent baseline, not an optimized recommendation. If no eligible call remains, retain the decision with SELL_CC_UNAVAILABLE; do not invent a strike, quote or fallback. Source C has a1–60 DTE lattice; this narrower candidate-level research rule needs a reviewed adapter and is not a supported snapshot-level canonical proposal field. No delta eligibility field or policy enum is added. Historical option quotes do not identify all counterfactual fills or assignment allocations. Tag those labels MODEL_BASED_ESTIMATE or NOT_IDENTIFIABLE; never ACTUAL_FILL solely because the underlying path is historical.

Secondary C-stage experiment starts with an already-open covered call: compare HOLD_CC (including potential call-away) with CLOSE_CC and continued stock holding over the same T. SELL_STOCK is unavailable while shares are encumbered unless the call is actually resolved first. ROLL_CC is excluded from this first design and would require a separate version/cost/path specification. No change to H no-roll research.

## C. Economic endpoint and checks

For each arm a, terminal wealth is cash + proven receivables + marked retained shares + marked long options − short-option liabilities. Deduct each actual or explicitly modeled fee once. Use unadjusted stock prices with separately proven dividends; never add dividends to a total-return-adjusted series again. Pending obligations, unsettled sale/assignment proceeds and capital release are separate state fields. Initial NAV is identical across arms.

Primary contrast: W_CC(T)−W_WAIT(T), in dollars per original lot. Secondary contrast: W_CC(T)−W_SELL(T). Also report every arm's total chain PnL from the initial put, and forward change from the recovery decision. Changing past acquisition basis while all current assets/cashflows are identical must not change forward action ranking; it changes historical chain reporting.

Report stock movement, option cashflows, dividends, financing and fees as separate components. Report opportunity gap W_WAIT−W_CC separately from actual PnL. A positive stock upside-truncation diagnostic is max(unconstrained stock value minus delivered-stock value,0), with quantity and horizon stated. It is not another realized loss to subtract. The complete opportunity gap can differ due to premiums, dividends, costs and timing/carry.

Safety/co-primary descriptive outputs: residual share/option quantities; maximum required funding; capital dollar-hours; negative wealth tail; mandatory-close failure; realized/estimated/unresolved fractions; dividend uncertainty; and unexpected exposure from assignment. Call buyback alone does not free the stock's capital. Share coverage uses the union of unique lot/share claims, preventing overlap double reservation and duplicate call coverage.

Taxes are EXCLUDED. No jurisdiction, basis elections, holding period, qualified-dividend status or tax rate is inferred. Pretax superiority is not after-tax superiority. Tax-sensitive implementation remains outside this experiment unless separately supplied and approved.

## D. Diagnostic attribution, not an executable hedge strategy

For an interval with n owned shares and exactly n-share call coverage, let dS be unadjusted stock change, dC per-share call value change, delta be the call delta available before the interval, and b0 a fixed entry-known stock-equivalent exposure fraction. Ignoring carry/dividends/fees momentarily:

- Passive stock component: n b0 dS
- Time-varying stock component: n[(1−delta)−b0]dS
- Delta-hedged option residual: n[delta dS−dC]
- Their sum is exactly n(dS−dC)

Add actual dividend, financing and cost components separately. Split intervals at changes in share/call quantities, fills, assignment and corporate actions. A missing delta makes this diagnostic incomplete, not wealth unknown if actual cash/share values are available. Never fill delta from a later observation or full-sample mean.

This identity does not prove the residual is a paid volatility premium. IV revaluation, jumps, hedge error, model misspecification and carry can contribute. Separate Greeks are descriptive only when point-in-time inputs and the model are available. Discrete delta changes are not themselves an instruction to hedge; an actual hedge strategy would add turnover, funding, rounding and execution constraints and needs its own approval.

As a descriptive risk comparator, a static entry-delta-matched stock/cash portfolio can test whether apparent volatility reduction merely reflects less equity exposure. It is not a new THETA action or broker instruction, and no full-sample fitted beta may define its past allocation. Report results separately from the three authorized action concepts.

## E. Q/D hedge-financing companion, not a collar transplant

Freeze the same short put, quantity, expiry and horizon. Q holds that cash-secured short; D adds one valid lower-strike protective put per short. Let L0 be paid long-put premium dollars, fL incremental long-leg lifecycle costs, LT its long-put value at the common horizon, including a qualified mark if still open at T or realized proceeds/payoff if resolved, and ΔI verified financing difference. Then, while the comparison preserves the same short exposure and settlements:

W_D(T)−W_Q(T) = LT−L0−fL+ΔI.

An unresolved or unqualified long-put horizon value is UNKNOWN, never zero merely because it has not been sold or expired. A positive spread entry credit does not erase L0. In the zero-payoff state, the hedge's increment is negative after cost. In a sufficiently adverse state, protection can dominate. Neither state proves expected superiority. The primary arm assumes no speculative redeployment benefit; if collateral earns the same rate while reserved and unreserved, reserve reduction alone creates no interest windfall.

Separate sizing experiments:
- Same short quantity/full account capital: identifies incremental hedge economics and remaining cash.
- Same maximum-loss budget: changes quantity and therefore market exposure, fees and funding; label as a different experiment.

Don't compare returns on width collateral for D with returns on strike collateral for Q and call the difference alpha. Use total-account wealth plus separately reported capital-time. Reuse the prior residual-topology tests if protection is removed or assignment separates settlements; the simple difference identity must then include actual liquidation and funding cashflows, not assumed terminal offsets. Old papers' margin parameters are not current account permissions or reserves.

## F. Falsifiers and analysis lock

Reject a proposed superiority claim if it:
- Uses only premiums or completed calls while excluding stock losses or failed exits
- Uses full-sample delta/beta to set past decisions
- Counts an assignment notification as contemporaneously known before receipt
- Credits a dividend without entitled quantity, or uses receipt-time shares
- Credits interest automatically when collateral is released, without the actual rate/eligibility
- Treats lower beta or a different denominator as independent alpha
- Counts overlapping chains, policy arms or repeated receipts as independent samples
- Labels counterfactual fills as observed, or resolves a path from a stale/missing quote
- Deletes severe/no-bid states using a liquidity screen after the outcome is known

Lock one call rule, one primary contrast (W_CC−W_WAIT) and one secondary contrast (W_CC−W_SELL) before holdout. The secondary contrast is descriptive/exploratory unless a separate multiplicity-controlled confirmatory analysis is preregistered; it cannot substitute for a failed primary contrast. Analyze chronological blocks; keep all decisions from a chain in one split, with label-maturity embargo through final reconciliation. Cluster uncertainty by overlapping market dates and issuer/event, reporting sensitivity to block lengths. Include trend, sharp decline/rebound and dividend windows without choosing regimes retrospectively from favorable outcomes. Do not annualize short fixtures.

Performance admission requires sourced paths, complete or explicitly bounded missing outcomes, and uncertainty narrow enough for a prespecified economic minimum improvement and maximum tolerated risk. Those decision thresholds belong to the owner/governance; they are not inferred from academic statistics. If thresholds are absent, report estimates descriptively without selection. No fixed raw trade count substitutes for independent risk-event coverage.

## G. Existing-interface handoff

Continue using WholeChainComponents, whole-chain evidence status/provenance, buildRecoveryCoveredCallExperiment and buildWholeChainOutcomeRow. Preserve BENCHMARK_CASHFLOW/MODEL_BASED_ESTIMATE for modeled outcomes and UNKNOWN dividend gates. Extend an existing research evidence adapter only after separate authorization. Do not create a second ledger/PnL engine, add unsupported canonical policy enums or promote snapshot-level filters into per-lot rules. No Production change or publication is requested.

## Version2 change receipt

1. SectionF now agrees with SectionC: CC−WAIT is the single primary contrast; CC−SELL is secondary.
2. T uses fixed scheduled exchange sessions known at t0. Data absence or strategy eligibility cannot move the horizon.

3. SectionE clarifies that LT includes a qualified mark for an open long put at T; unresolved value is UNKNOWN rather than zero.

Version1 remains available as historical provenance and is non-controlling. The21 algebra checks are unchanged and were not rerun or recounted for this text clarification. Primary-literature review remains author-verified; targeted independent static review of these design clarifications is requested separately.
