# Covered-call recovery and hedge financing: critical source review v1

Reviewed 2026-10-09 PKT. Three primary research papers were checked. Their empirical results are **SOURCE_REPORTED_NOT_REPRODUCED**. The accompanying algebra is **STRUCTURAL_SYNTHETIC**, with no invented historical price observations. These sources motivate tests; none validates THETA or authorizes a portfolio change.

Novelty check: the stable research index returned no literal matches for Israelov, Nielsen, Santa-Clara, Saretto or Collar Strategies. This establishes no obvious named duplicate, not exhaustive bibliographic uniqueness. Earlier OIC mechanics and Bondarenko PUT evidence are retained and not recycled as new work.

## 1. Israelov and Nielsen, Covered Calls Uncovered (2015)

Primary: [author-hosted Financial Analysts Journal paper](https://www.aqr.com/-/media/AQR/Documents/Insights/Journal-Article/Covered-Calls-Uncovered.pdf), 71(6),44–57; inspected decomposition, table notes and endnotes.

The study decomposes index overwriting into passive equity, dynamic equity and delta-hedged option exposure. Its attribution baseline uses full-sample average delta. Note9 identifies an expiry-interval convention caused by unavailable intraday data. These are important limits on direct point-in-time replication. Commercial interest is disclosed. No broker-specific execution-cost model was established here.

Our research implication: use a frozen entry/training-only delta baseline; report attribution residuals and execution separately. Do not convert descriptive decomposition into a causal recovery signal. Existing-stock American options require entitlement and settlement evidence beyond an index study. No paper returns, Sharpe ratios or risk contributions have been independently reproduced.

## 2. Israelov and Klein, Risk and Return of Equity Index Collar Strategies (2016)

Primary: [author-hosted Journal of Alternative Investments paper](https://www.aqr.com/-/media/AQR/Documents/Journal-Articles/Risk-and-Return.pdf?sc_lang=en), Summer2016; inspected construction and attribution sections, Exhibits2,6–7.

The paper distinguishes upfront premium financing from economic cost. Its CLL example buys quarterly puts and sells monthly calls; the authors report it is materially net-debit, not a literal zero-premium collar. The historical summary and shorter attribution windows differ. Both authors are affiliated with AQR; this is not independent corroboration of the first paper's methodology.

Our inference: neither that collar's poor relative history nor its financing convention proves every same-expiry THETA D spread is unattractive. A contractually valuable loss limit can be worth paying for under a binding risk constraint, even with lower expected wealth. Reject the shortcut that a positive opening credit makes purchased protection free. Reproduce matched per-contract economics before changing risk-budget sizing; keep net cash, exposure, tail loss and funding separate. No historical result was reproduced.

## 3. Santa-Clara and Saretto, Option Strategies: Good Deals and Margin Calls

Primary full text inspected: [UCLA-hosted November2004 working-paper version](https://www.anderson.ucla.edu/documents/areas/fac/finance/santa_clara_option.pdf), data section and transaction-cost/margin sections. The [NOVA author-institution record](https://novaresearch.unl.pt/en/publications/option-strategies-good-deals-and-margin-calls/) verifies a later2009 Journal of Financial Markets publication; its results are not silently substituted for this draft.

The inspected draft uses1985–2001 futures-option data and1996–2002 index-option quotes. It shows how spreads, constrained funding and forced liquidation can alter seemingly attractive short-option outcomes. Its historical margin simulations apply then-current formulas and acknowledge unavailable CME SPAN reconstruction; they are not current broker rules. The economic mechanism is useful; numerical effect sizes and the draft's mispricing interpretation are not adopted.

Our inference: separate fully funded Q, intact D and post-assignment liquidity. A cash-secured put is not the paper's leveraged naked-option portfolio. Retain complete funding/close paths and a zero-redeployment-credit baseline. No current margin, cost schedule or return calibration follows from this source, and no original dataset or backtest was reproduced.

## What the papers do and do not establish

These are primary research, not three independent modern tests of this user's strategy. Two share authorship/methodology; the third has different instruments, era and financing assumptions. Accessible full text does not supply redistribution rights to the underlying datasets. No open replication package was verified. Data rights, source quotes, corporate actions, actual fills and current broker rules remain missing.

The narrow decision is to save the following common-horizon study as a research candidate. It is INCONCLUSIVE on economic superiority. No performance promotion follows from this literature review.

## Why premium-income statistics can mislead (independent accounting analysis)

Receiving a call premium creates a matching short-option liability. Before spreads/fees, opening cash alone is not new wealth. Subsequent profit depends on the liability's change and the shares' value. Reporting repeated credits while omitting a depreciated stock lot confuses a cash receipt with recovery. Dividing credits by option premium or a small margin reserve instead of whole-account capital changes the question.

A winning-call percentage can rise when stocks fall, because calls expire worthless while stock losses persist. A severe loss may coexist with many premium receipts. A rebound can repair stock wealth while a low-strike call limits participation. Closing and rewriting a call for a net credit can extend duration, fees and encumbrance without improving terminal wealth. No-roll and roll comparisons must be separately preregistered, with one chain rather than one trade counted per roll.

For a standard one-call-per100-shares position, local stock exposure is approximately100×(1−call delta). It is neither constantly100shares nor universally50shares. Delta is model-dependent and can change rapidly; a time-series regression beta is not the same quantity. A delta-hedged accounting residual can contain IV changes, jumps, discretization, model errors and carry. Labeling the entire residual an earned volatility premium would assume what the study must test.

## Source-reported versus reproduced evidence

- Source-reported history: read critically, not independently replicated; no source return table imported into THETA results.
- Reproduced here: exact algebra and bounded invented values for premium/liability accounting, forward-versus-chain comparison, lagged-delta attribution and Q/D protection costs.
- Not reproduced: source samples, benchmark NAV conventions, return moments, hedge turnover, queue outcomes, margin calls or statistical significance.
- Review search/read access is distinct from data-license and execution entitlement. No paid data, broker calls, accounts, repository edits or publication.
