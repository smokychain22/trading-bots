"""Bounded synthetic algebraic cross-checks. No source implementation is tested."""
from decimal import Decimal as D
from itertools import product
from pathlib import Path
import json
out=Path(__file__).parent
# Each grid row is an algebraic input, never an independently sampled market episode.
rows=[]
for p in [D(0),D('.1'),D('.25'),D('.5'),D(1)]:
    e50=(1-p)*100+p*(-152); e80=(1-p)*160+p*(-304)
    assert e80-e50 == 60-212*p
    rows.append({'hypothetical_stress_weight':str(p),'net50_weighted_pnl':str(e50),'net80_weighted_pnl':str(e80),'gap80minus50':str(e80-e50)})
# Protection-removal identity: cash benefit versus payoff forfeited.
dgrid=[]
for s,r in product(map(D,['0','70','80','94','95','100','110']),range(3)):
    q=D(2); width=D(5); short=(D(100)-s).max(0); long=(D(95)-s).max(0)
    intact=D(196)-q*100*short+q*100*long
    residual=D(196)+D(r)*39-q*100*short+(q-r)*100*long
    assert residual-intact == D(r)*(39-100*long)
    assert intact >= D(-804)
    if s < D('94.61') and r: assert residual < intact
    dgrid.append({'terminal_spot':str(s),'longs_removed':r,'intact_pnl':str(intact),'remaining_topology_pnl':str(residual)})
# Event_time determines rights. availableAt determines whether the decision can know them.
# Explicit entitlement is supplied, never estimated from a simplistic strike/extrinsic rule.
agrid=[]
for entitled,late,duplicate in product([False,True],[False,True],[False,True]):
    events=[('premium',D(100)),('close_fee',D(-1)),('dividend',D(100) if entitled else D(0))]
    if duplicate: events.append(events[-1])
    unique=dict(events)
    total=sum(unique.values())
    assert total == D(99)+(100 if entitled else 0)
    state='UNKNOWN_PENDING_RECONCILIATION' if late else 'KNOWN'
    agrid.append({'entitlement':entitled,'late_receipt':late,'duplicated_delivery':duplicate,'cash_total':str(total),'decision_information_state':state})
# Deliberately wrong arithmetic/state assumptions must be killed by independent fixture truths.
mutants=[
 ('H_target_hit_is_complete',100,-152),
 ('H_release_all_at_first_fill',480000,1200000),
 ('H_divide_remaining_capture_by_remaining_credit',D(50)/99,D(50)/198),
 ('D_original_bound_after_long_removed',-402,-1863),
 ('D_reject_means_short_gone',0,1),
 ('D_release_all_after_one_package_fill',0,500),
 ('AC_stale_snapshot_earns_dividend',100,0),
 ('AC_call_premium_is_chain_pnl',99,-204),
 ('AC_subtract_lost_upside_twice',-1704,-204),
 ('AC_duplicate_assignment_receipt',19000,9500),
 ('AC_close_call_frees_stock_capital',0,10000),
]
for name,bad,truth in mutants: assert bad != truth,name
result={'classification':'STRUCTURAL_SYNTHETIC','scope':'ALGEBRAIC_GRID_AND_DELIBERATE_MUTANTS_NOT_REPO_TESTS','H_sensitivity_rows':rows,'H_equal_weight_boundary_exact':'15/53; unestimated mixture, not empirical probability','D_topology_rows':dgrid,'AC_entitlement_rows':agrid,'mutants_killed':[x[0] for x in mutants],'mutants_total':len(mutants),'historical_episodes':0,'source_functions_executed':False,'grid_rows_are_not_sample_size':True}
(out/'sensitivity_and_mutations_receipt_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'H_sensitivity_rows':len(rows),'D_topology_rows':len(dgrid),'AC_entitlement_rows':len(agrid),'deliberate_mutants_killed':len(mutants)}))
