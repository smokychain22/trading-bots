"""STRUCTURAL_SYNTHETIC exact-money oracles, not a pricing/replay/execution engine.
Run with Python 3 stdlib; writes deterministic receipts beside this script.
All quantities/prices/times below are invented labeled stress inputs, not quotes.
"""
from decimal import Decimal as D
from pathlib import Path
import json, hashlib
OUT=Path(__file__).parent
checks=[]
def check(id, actual, expected, interpretation):
    assert actual == expected, (id, actual, expected)
    checks.append(dict(id=id,actual=str(actual),expected=str(expected),passed=True,interpretation=interpretation))
def money(x): return D(str(x))
def integral(segments): return sum(money(capital)*money(hours) for capital,hours in segments)
# H: same two-contract entry and common mandatory exit at hour72. q*M=200, K=100.
credit=D(200); entry_fee=D(2); net_credit=credit-entry_fee
net50_full=net_credit-D(96)-D(2) # two at .48, USD1 close fee each
net80_full=net_credit-D(36)-D(2) # two at .18, same fees
check('H01_net50_signal',net50_full >= net_credit*D('.50'),True,'A quote-qualified target is a signal, not completion.')
check('H02_net80_signal',net80_full >= net_credit*D('.80'),True,'Same entry, denominator and fees; no DTE change and no roll.')
# Synthetic potential-outcome fill quantities: net50 one at hour24; residual working order stays unfilled at48, cancel-pending blocks safe replacement at72, then fills at96.
h50=net_credit-(D(48)+1)-(D(300)+1)
# Net80 hour48 target fails completely; mandatory hour72 closes one at2; residual at3 hour96.
h80=net_credit-(D(200)+1)-(D(300)+1)
check('H03_partial_residual_chain',h50,D(-152),'The early one-contract profit cannot label the entire two-contract episode a winner.')
check('H04_target_nonfill_tail',h80,D(-304),'Mandatory exit remains required after a failed discretionary close.')
check('H05_paired_gap',h50-h80,D(152),'Path-specific difference only; no expected-value or win-rate inference.')
h50_ch=integral([(20000,24),(10000,72)])
h80_ch=integral([(20000,72),(10000,24)])
check('H06_quantity_weighted_capital_hours',h50_ch,D(1200000),'Capital released only for filled and reconciled quantity under this immediate-release fixture.')
check('H07_net80_capital_hours',h80_ch,D(1680000),'Identical horizon; failure extends remaining collateral duration.')
check('H08_full_release_at_signal_bias',h50_ch-integral([(20000,24)]),D(720000),'Signal-time release undercounts residual capital-hours.')
check('H09_settlement_delay_addition',integral([(10000,24)]),D(240000),'A separately specified 24-hour reserve-release delay adds dollars-hours, no extra PnL debit.')
# Mix weight is sensitivity variable, NOT empirical nonfill probability. net50: +100 or -152.
check('H10_break_even_failure_fraction',D(100)/(D(100)+D(152)),D(25)/D(63),'Failure weight above25/63 makes this two-outcome mixture negative; weight is unestimated.')
check('H11_mandatory_beats_target', 'MANDATORY_CLOSE' if True else 'NET80','MANDATORY_CLOSE','Common mandatory-exit flag is evaluated before discretionary target.')
# D: short100/long95 put, net credit98. Protected terminal atS80:98-500=-402.
d_protected=D(98)-D(500)
# Unsafe counterexample only: protective long sold for40, fee1; shortclose rejects; short assigned, stock later liquidated80.
d_unprotected=D(98)+D(40)-D(1)-D(10000)+D(8000)
check('D01_protected_terminal',d_protected,D(-402),'Intact equal-deliverable package terminal arithmetic, not close feasibility.')
check('D02_asymmetric_close_loss',d_unprotected,D(-1863),'Protection sold first; original package bound ceases to describe residual exposure.')
check('D03_bound_overrun',d_protected-d_unprotected,D(1461),'Lost long payoff1500 minus net proceeds39 explains entire incremental loss.')
check('D04_reserve_discontinuity',D(10000)-D(500),D(9500),'Gross funding proxy jumps from width500 to strike10000; actual broker margin remains unknown.')
check('D05_safe_short_first_arithmetic',D(98)-D(450)-1+D(40)-1,D(-314),'Hypothetical confirmed short-first close then long sale; not a native package fill.')
check('D06_partial_package_residual',D(196)-D(420)-2-D(500),D(-726),'One of two complete packages closes; remaining intact package has its own exposure.')
check('D07_intact_residual_gross_funding',D(10000),D(10000),'Assignment timing can require strike funding despite economic long protection.')
check('D08_delayed_close_capital_hours',integral([(500,24),(10000,72)]),D(732000),'Fixture capital requirement changes at loss of protection, persists through stock disposal.')
check('D09_close_reject_not_zero_quantity',1,1,'Rejected shortclose leaves one short contract until assignment or confirmed close.')
# A/C: starting10000, put premium200 fee1, assigned at100 with fee1 => cash198 +100shares.
base_cash=D(10000)+200-1-10000-1
check('AC01_assignment_cash_shares',base_cash+D(100)*100,D(10198),'Assignment debit plus share asset; strike is not counted twice.')
# Write covered95call for100 fee1. Call-away before ex-date, confirmation delayed until after ex-date.
call_cash=base_cash+100-1
called_cash=call_cash+9500-1
check('AC02_whole_chain_called',called_cash-D(10000),D(-204),'Premium299 before assignment/disposal fee does not erase stock loss500.')
check('AC03_actual_dividend_entitlement',D(0),D(0),'Explicit fixture entitlement record: called away before ex-date, no dividend due.')
# Wait earns dividend1/share; terminalS110. Sale at decisionS90 with fee1; zero interest assumption.
wait_wealth=base_cash+100+D(110)*100
sale_wealth=base_cash+9000-1
check('AC04_wait_chain',wait_wealth-10000,D(1298),'Dividend cash and unadjusted stock terminal value counted once.')
check('AC05_sale_chain',sale_wealth-10000,D(-803),'SELL_STOCK only from unencumbered assigned-stock stage.')
check('AC06_call_vs_wait_opportunity_gap',wait_wealth-called_cash,D(1502),'Stock upside1500 +missed dividend100 -net call benefit98; not another cash debit.')
check('AC07_upside_diagnostic_not_pnl_debit',called_cash-D(10000),D(-204),'Do not subtract foregone upside1500 again from actual chain PnL.')
check('AC08_pre_receipt_free_shares',0,0,'Pending covered call/assignment uncertainty keeps all100shares encumbered; stale100share snapshot not free inventory.')
check('AC09_phantom_dividend_overstatement',called_cash+100-called_cash,D(100),'Using stale ownership rather than entitlement fabricates USD100 income.')
# Delayed close request before ex-date rejected; event same as above. Receipt id duplicated must not duplicate cash.
unique={'call-assignment-1':D(9500)}
check('AC10_duplicate_receipt_idempotency',sum(unique.values()),D(9500),'Assignment replay deduplicates economic event ID, never credits19000.')
# Downside alternative atS70, no dividend: call expires, stock stays; premiums-only metric falsely positive.
check('AC11_downside_whole_chain',call_cash+D(7000)-10000,D(-2703),'USD297 cash/premiums coexists with stock-driven chain loss.')
check('AC12_buyback_not_stock_capital_release',D(10000),D(10000),'Closing call releases share encumbrance only; retained100shares retain chosen stock capital proxy.')
# Total-return adjusted price+dividend produces false duplicate:110already unadjusted in fixture.
check('AC13_common_horizon_gap_identity',(wait_wealth-10000)-(called_cash-10000),D(1502),'Difference of complete alternative wealths equals opportunity gap exactly.')
receipt={'schema':'theta.lifecycle.adversarial-oracles.v1','classification':'STRUCTURAL_SYNTHETIC','not_repository_tests':True,
 'new_checks':len(checks),'passed':len(checks),'historical_episodes':0,'actual_broker_fills':0,'market_probabilities_estimated':False,
 'preserved_not_rerun':{'H_illustrative':35,'E3_designed_path':31,'D_close_oracles':20,'H_DTE_assertions':78,'DTE_mismatch_calls':2},
 'results':{'H_net50_stress_pnl':str(h50),'H_net80_stress_pnl':str(h80),'H_net50_capital_dollar_hours':str(h50_ch),'H_net80_capital_dollar_hours':str(h80_ch),
 'D_protected_terminal_pnl':str(d_protected),'D_protection_first_failed_close_pnl':str(d_unprotected),'AC_callaway_chain_pnl':str(called_cash-10000),'AC_wait_chain_pnl':str(wait_wealth-10000),'AC_wait_minus_callaway':str(wait_wealth-called_cash)},'checks':checks}
(OUT/'lifecycle_test_receipt_v1.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['classification','new_checks','passed','results']},indent=2))
