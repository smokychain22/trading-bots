# Independent H / D / A-C lifecycle review addendum

Reviewed 2026-10-08 UTC. Scope: arithmetic, target definitions, stock/cash/dividend identities, residual topology, evidence-gate claims and output-count scope in `LIFECYCLE_RESEARCH_DESIGNS_v1.md` and its receipts. Research only. This adds no historical observations, actual fills, probability estimate, trading authority or Production change.

## Verdict

The H, D and A/C examples have consistent cash arithmetic. The no-promotion and no-actual-fill qualifications are appropriate. Two real specification ambiguities were found and corrected by the author in a separate amendment: overlapping share claims must be unioned rather than blindly added, and D long-sale proceeds must be explicitly per removed contract. Neither is a demonstrated Production defect.

The ten pure-source characterization checks reproduce independently, including the crucial dividend UNKNOWN barrier. The other original fixture/sensitivity suites and earlier 78-test suite were not rerun.

## H: original net-credit denominator is internally consistent

The H lifecycle experiment uses original net opening credit C−F0 as its denominator, fixed for the whole original filled quantity. Its formula includes confirmed close debits/fees plus liquidation of the entire remaining position, so a partial close does not reset the target to a favorable subset.

For the invented two-contract example, C=200, F0=2 and full-close fees=2:

| Definition | NET50 per-share maximum debit | NET80 per-share maximum debit |
|---|---:|---:|
| Net P&L divided by original net opening credit 198 | 0.485 | 0.188 |
| Net P&L divided by original gross credit 200 | 0.480 | 0.180 |

The latter is the separate gross-credit-denominator convention used in the generic put threshold packages. The H values must stay on the former convention. At equal one-cent quote ticks both round-down ceilings happen to match, which can hide the semantic difference in this particular fixture. Mixed partial-fill prices can still distinguish the definitions. Neither convention should be relabeled as the other.

The reported 100 and 160 full-close P&Ls qualify for the 99 and 158.4 net-denominator targets. They are slightly beyond the threshold, which is valid. The stress-path P&Ls −152 and −304, paired gap 152, capital integrals 1,200,000 and 1,680,000 dollar-hours, and hypothetical mixture boundary 15/53 are correct. They describe supplied potential-outcome paths, not observed comparative execution outcomes or estimated fill probabilities. Arm-dependent queues need an explicitly coupled execution model before causal policy ranking.

The parent additionally identified the existing H continuation handoff's original-filled-net-credit convention. This review independently verifies the lifecycle formula and the cross-package difference; it does not independently re-audit that upstream handoff index.

## D: the intact bound is not a bound on a changed position

The intact single spread terminal P&L −402, protection-first/short-close-rejected path −1,863, difference 1,461, hypothetical short-first close −314, two-package partial-close result −726 and stated capital integral 732,000 dollar-hours are arithmetically correct under their explicit fee/terminal assumptions.

Removing a long changes payoff topology. With q original spreads and r removed longs, the difference from the intact position is:

r × [per-removed-contract net sale proceeds − multiplier × max(long strike − terminal spot, 0)].

If proceeds are instead supplied as an aggregate for all removed longs, multiply only the forfeited payoff term by r. The initial text was ambiguous; the author now explicitly defines Lnet per removed long contract. The existing grid had always used that interpretation and needs no numerical correction.

A standard residual short put has finite terminal downside for a nonnegative underlying. In the two-contract zero-spot example, the residual P&L is −19,726 rather than unbounded. The original intact-spread floor −804 is inapplicable after both longs have been sold. Width and strike figures are stated collateral/funding proxies, not verified broker buying power or attainable liquidation limits. Gross assignment funding can differ from economic terminal net exposure even for an intact package.

## A/C: no cash/stock/dividend double-counting in the reported examples

Independent reconstruction of signed cash flows plus retained terminal stock reproduces:
- WAIT terminal wealth 11,298 and chain P&L +1,298
- SELL_STOCK terminal wealth 9,197 and chain P&L −803
- CALL_AWAY terminal wealth 9,796 and chain P&L −204
- WAIT minus CALL_AWAY opportunity gap 1,502

The call-away proceeds remove the stock, assignment cash is debited once, fees are counted once, and the call-away arm's dividend is explicitly zero. WAIT adds proven dividend cash to an unadjusted terminal stock price. The opportunity gap is a comparison of already-complete wealth paths, not another debit to −204. The downside retained-stock example −2,703 and source partial-disposal example +546 are also consistent.

The review found a separate share-reservation specification defect: the original additive expression could subtract an existing covered-call claim and the same call's pending assignment claim twice. A 100-share lot with both 100-share records would produce −100 under naive subtraction, despite only 100 unique shares being claimed. This is an invalid reservation count, not evidence of extra available stock.

The author amended the design to subtract the unique lot/share claim union; the example correctly leaves zero free shares. An overlapping assignment continues/replaces the same claim. If identity or overlap is unresolvable, available inventory remains UNKNOWN/unavailable. The amendment is preserved separately in `review_amendment_v1.json`, with its own two control assertions; the original 33/10 counts were not increased. The reviewer retained pre-amendment and amended snapshots for traceability.

## Dividend source gate: positive fail-closed evidence

The reviewed source bytes match the recorded hashes for commit d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba's supplied files. Static inspection confirms:
- `postgres-whole-chain-components-repository.ts`'s dividend producer returns UNKNOWN with `DIVIDEND_COVERAGE_UNPROVEN_NO_ACTIVE_INGESTION_WRITER`, even when it can calculate a partial amount.
- `componentsFromEvidence` requires dividend evidence and returns null components with a `dividends:UNKNOWN` blocker before certifying complete components.

The reviewer reran the ten pure-source checks once in an isolated directory. UNKNOWN amount 0 and UNKNOWN amount 100 both remain blocked, and the complete receipt reproduces bit-for-bit.

The lower-level ledger consumer's acceptance of supplied stale/duplicate dividend rows is a deliberately malformed-input characterization. It does not establish upstream reachability, an actual stored duplicate, cash paid to an account, or a Production overstatement. Conversely, this one reviewed guard does not prove every runtime path is safe. The database, provider, broker, deployed SHA and runtime call graph were not exercised. Keep this narrower positive gate finding in every consolidated summary.

## Count and validation language

The 33 original checks are hand-constructed arithmetic/state fixtures. Some are constant control assertions, such as selecting a literal mandatory branch or asserting a supplied quantity; they do not execute the real policy, order lifecycle or reconciliation implementation. The 34 grid rows are 5 H, 21 D and 8 A/C scenarios. The “11 mutants” are hard-coded wrong-versus-right arithmetic/state inequalities, not executable source mutations. These are useful explanatory counterexamples but must not be described as mutation-test coverage of THETA.

The ten imported-source checks provide stronger, precisely scoped function characterization; SC07–SC08 intentionally succeed when the pure consumer accepts malformed rows. Passing those tests certifies reproduction of that behavior, not dividend entitlement correctness. All counts remain separate from earlier suites and from the author's two amendment assertions. No independent market sample exists here.

## Receipt and reproducibility

The reviewer reran only the ten pure-source characterization checks. Original fixture and grid suites were not rerun in this review. Full source-provenance and review records are retained separately; this compact package includes the selected synthetic arithmetic scripts and receipts only. The amended share-claim convention and per-contract proceeds definition control.
