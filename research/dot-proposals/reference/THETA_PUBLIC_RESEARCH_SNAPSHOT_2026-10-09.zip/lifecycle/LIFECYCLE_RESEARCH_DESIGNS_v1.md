# THETA H / D / A-C lifecycle research designs v1

Evidence: **STRUCTURAL_SYNTHETIC only**. Prepared 2026-10-09 PKT. No historical option episodes, actual fills, probability estimates, expected return claims, broker access, Production edits, or publication. These are versioned research designs, not executable Dot proposals. No validator-passing assertion is made.

## Executive findings

1. **H: target-trigger-to-completion selection bias.** The distinct extension is the *joint distribution* of target signals, quantity-weighted completion and adverse price moves, not another target formula, priority regression or DTE check. A net target can be reached before a partial fill leaves the losing residual exposed. Dropping these failures conditions evaluation on a favorable execution outcome.
2. **D: protection removal creates a discontinuous residual funding requirement.** A partial package fill and a partial leg fill are economically different. Selling a protective long before buying back the short converts the remaining exposure. Applying the original spread maximum loss to that remaining position is invalid. This extends prior cap/close-feasibility tests with exact topology-dependent loss decomposition.
3. **A/C: two-clock dividend entitlement and share encumbrance.** Economic assignment can precede receipt of its confirmation. The decision cannot use unseen confirmation, while final wealth must use actual entitlement, not the stale share snapshot at receipt. This extends prior basis/common-horizon wiring with delayed-information and duplicate-delivery challenges.

All prior 35 H illustrative, 31 E3 designed-path, 20 D close oracles, 78 H DTE assertions and 2 DTE mismatch calls remain separate and are not rerun/recounted. Some familiar accounting identities are necessary controls in this new path fixture, not newly discovered mechanisms. The 33 fixture checks and 34 algebraic grid rows are not a market sample or independent evidence of success. Eleven deliberately wrong arithmetic/state assumptions are rejected; these are not mutations of repository code.

## 1. H-COMPLETION-SELECTION-20261009-v1

### Matched design

Freeze the exact eligible entry, actual original quantity, strike, multiplier, fees, collateral rules, all hard gates, mandatory exits and horizon. Compare NET50 and NET80 with no roll. This does not alter the separate 2–5 versus 3–5 calendar-DTE proposal. Retain gross50 as its named source benchmark if desired, never relabel it net50. Calendar-DTE validity and source's current whole-chain mismatch gates must pass before admission; this suite does not retest them.

Let C be aggregate original opening credit, F0 opening fees, q0 original filled contracts. The full residual valuation at time t is

N(t) = C − F0 − sum(confirmed close debits and close fees through t) − estimated liquidation debit and incremental fees for the remaining contracts.

NETx signals only when N(t) ≥ x(C−F0), with known positive denominator. Do not shrink the original denominator after a partial close. A signal is not a filled trade. Mandatory-close applicability is shared across arms and takes precedence; a failed mandatory close retains the obligation and exposure without creating authority to place an order. Unknown risk/quote evidence produces a typed unresolved state, never inferred HOLD or zero risk.

### Bounded episode (invented, not quotes)

- At hour 0 sell two standard puts, strike100, multiplier100, $1/share, aggregate opening fees$2. Net credit$198; gross strike collateral$20,000.
- At hour24 ask$0.48, $1 close fee/contract. Net50 full-close estimate$100 qualifies. Fixture fills one only, remainder still open in a working limit order.
- At hour48 ask$0.18. Net80 full-close estimate$160 qualifies but its close request is rejected with zero fill; the net50 residual working order also receives no fill. No fill likelihood is inferred from a displayed quote.
- Shared mandatory-close deadline hour72. Net50 residual is cancel-pending, so its mandatory reprice cannot safely create another active close until cancellation is reconciled; net80 has no working target order after rejection and closes one at$2 plus$1 fee. Final residuals close at hour96 at$3 plus$1 fee.
- Final net50 PnL −$152; net80 −$304. Both stop with no position. Same-entry, same-horizon difference$152 favors net50 in these specified potential-outcome paths only. Their queue/cancel trajectories are explicit arm-dependent stress assumptions, not identified causal fill effects or a shared-capacity simulator. A real comparison must estimate or couple execution uncertainty rather than assume these paths are observed together.
- Capital dollar-hours with immediate reconciled release: net50=20,000×24+10,000×72=1,200,000; net80=20,000×72+10,000×24=1,680,000. An extra stated 24-hour release lag adds240,000 for one residual contract. Broker reserve mechanics are not claimed.
- Releasing all collateral at first signal undercounts net50 by720,000 dollar-hours. Additional capital-time is a diagnostic. Do not deduct it as a PnL cost unless an independently specified financing cost is actually applied once.

### Falsification and identification

A second idealized gentle path completes net50 at$100 and net80 at$160. If the stress path has hypothetical weight p, the paired NET80−NET50 difference is 60−212p, switching sign at p=15/53. This is a sensitivity boundary, not an estimated probability or preferred policy. The stress frequency, fill-response correlation and opportunity value are all NOT_ESTIMABLE without qualified paths.

Record every eligible entry and every arm's signals, order statuses, fills, residual inventory and releases. Report separate counts for target-hit, close-requested, partial, completed, mandatory-close failure and unresolved. Do not compare only successful closers. Paired means require both arm labels; if one is unresolved, retain paired censoring and report informative-missingness sensitivity, not complete-case superiority. Counterfactual fills require an explicit defensible execution model and uncertainty; real fills under one policy do not identify the other policy's queue outcome.

Primary endpoint: common-horizon net wealth difference, including residual valuation/assignment and costs. Safety endpoints: mandatory-close noncompletion, residual exposure-hours, maximum required capital, worst observed loss, and tail conditional loss under a preregistered definition. Capital efficiency is PnL divided by time-integrated capital with unit specified, never annualized from this short fixture.

## 2. D-RESIDUAL-TOPOLOGY-20261009-v1

Entry: one put credit spread, short100/long95, same deliverable and expiry, multiplier100, gross credit100, opening fees2. Both legs owned as specified; D source admission stays7–60 DTE. At terminal S=80 an intact spread has PnL98−500=−402 before any additional settlement fees. This terminal identity does not establish route availability, acceptable price, execution or gross assignment funding.

Counterexample: at hour24 a hypothetical unsafe close sells the long for40 with fee1; short buyback is rejected. The short later assigns at100, creating100 shares and a10,000 cash debit. Shares liquidate at80. Final PnL98+40−1−10,000+8,000=−1,863. Loss beyond the intact comparison is1,461, exactly foregone long payoff1,500 less net long-sale proceeds39. No unbounded-loss claim: a fully cash-secured short put still has finite downside at zero. This is a prohibited-risk counterexample, not advice to leg out.

The collateral proxy switches from width500 to strike10,000 after loss of protection; difference9,500. Capital dollar-hours for24hours at500 and72hours at10,000 is732,000. Actual broker buying power, settlement, automatic exercise, exercise funding and option deliverables must be separately verified. Even the intact spread may face gross assignment funding before offsets settle.

Control A: hypothetical confirmed short-first close at450+1fee, then long sale40−1fee yields−314. It is another assumed execution path, not the original terminal bound or proof a route permits it. Control B: two initial packages, one complete package closes for420+2fees; second remains intact through terminal debit500:196−422−500=−726. This preserves the remaining package's hedge, unlike unequal leg quantities.

For q packages and r protective long contracts removed at net proceeds Lnet per removed contract, remaining topology PnL minus intact PnL is r[Lnet−M max(Klong−S,0)]. The21-row finite grid verifies this identity across seven spot levels and r=0,1,2. It does not estimate frequency.

Required outcomes: residual short/long quantities by contract ID; hedge coverage; gross assignment funding; native parent and leg execution identities; route cap; fill or reject timestamps; minimum contingent cash; liquidation/settlement timing; stock inventory after assignments. Validate full-close feasibility at entry and later mandatory windows; keep `CLOSE_NOT_DEMONSTRATED` until completion evidence. Parent order ACKNOWLEDGED and CANCELED are not zero exposure. A risk budget breach cannot be fixed by inventing a permitted fill or weakening caps. Never transfer an intact-spread terminal limit to residual naked exposure.

Falsifier: any source adapter reports zero remaining risk, full capital release or original package loss cap after unequal protective quantities. Exact adapter/runtime status is unverified; do not assert this bug exists in Production.

## 3. AC-TWO-CLOCK-ENTITLEMENT-20261009-v1

Track event effective time separately from received/availableAt time. Ex-date records are schedules, not proof of cash entitlement. Use broker/clearing entitlement and cash records for final labels; as-of research inputs must use only known records. Pending assignment or an unreconciled snapshot is unknown ownership, not free settled inventory.

Bounded whole chain starts with10,000 cash. Put credit200, fee1; assignment100shares at100, fee1. Cash198 plus100shares. Three alternatives at assigned-stock decision S90:

- RECOVERY_WAIT: retain100 shares, receive a separately proven100 dividend, terminal unadjusted S110. Wealth11,298; chain PnL+1,298.
- SELL_STOCK: sell at90, fee1, no dividend, no reinvestment/interest. Wealth9,197; chain PnL−803. This decision is before a covered call, so stock is unencumbered.
- SELL_CC: sell95call for100, fee1; fixture early assignment before ex-date transfers all100shares for9,500, fee1. Confirmation is received after ex-date. Explicit entitlement record says dividend0. Wealth9,796; chain PnL−204. Failed prior call-close request does not undo assignment or entitle dividends. No new covered call may rely on a stale100share snapshot.

At the shared horizon, wait minus call-away wealth is1,502 = foregone stock upside1,500 + missed dividend100 − net call contribution98. Report this opportunity gap separately; do not subtract it again from actual−204 PnL. A downside alternative with S70, no dividend, call expired and stock retained yields297+7,000−10,000=−2,703, despite positive option cash flows.

Accounting identity: initial cash + unique signed economic cash flows + terminal marked retained assets − open liabilities − initial cash. Assignment stock acquisition is a cash debit and stock asset once; sale proceeds remove shares; fees count once; dividends require entitled quantity. For retained stock use unadjusted terminal price plus actual dividends, or a consistent total-return convention without adding them twice. Do not use dividend-adjusted historical prices for the former identity. Unpaid but proven entitlements need a separately marked receivable, not invented paid cash; unknown receivables leave the label incomplete.

Coverage constraints: free settled shares = verified settled shares minus the count of unique shares in the union of active call encumbrance and unresolved disposal/assignment claims. Claims must be lot/share-ID aligned; an assignment pending for an already encumbering call continues that same claim rather than reserving the shares twice. If claim identity/overlap cannot be reconciled, free inventory is UNKNOWN and unavailable. Only disjoint claims may be added. Lot IDs and assignment economic IDs must be immutable and unique. Re-delivery changes evidence availability, not economic cash flows. A partial assignment must split/dispose only the actual quantity; missing lot or entitlement leaves dividend UNKNOWN.

Falsifier: after delayed assignment notice, an adapter creates a second sale/call claim on the same shares, credits dividend solely from stale shares, deduplicates by receipt time instead of economic event identity, or subtracts both adjusted basis and full original premium from the same wealth identity. Eight two-clock/dedup grid rows verify the hand-calculated fixture, not repository behavior.

## 4. Source-compatible integration, no duplicate engine

Pinned source supplied by source-audit worker: `d0b479f3dfd0a6d9a1e79a699308cab09ed9f1ba`. These files were read locally; deployed SHA and broker state remain unknown.

- `src/research/profit-taking-replay.ts`: reuse original input/provenance/cost fields and existing `runProfitTakingReplay`. Current `FIXED_*` arms are gross benchmarks; `ESTIMATED_EXIT` explicitly has `actualFill=false`. Current schema has no failed-close/partial-fill/assignment ledger and censors unknown paths. Do not inject invented forecast values or route NET50/80 through gross labels. A future separately reviewed adapter must join outcomes from existing ledger evidence while retaining benchmark results unchanged.
- `src/theta/hold-strike-lifecycle.ts`: reuse `assessHoldStrikeLifecycle`, existing no-roll invariant, mandatory deterioration/deadline and expiry-reconciliation facts. This study does not replace its logic or weaken quote/broker/AEGIS gates.
- `src/theta/ledger-contract.ts`: reuse `orderIntentStatus`, `reconciliationState`, option legs, stock lots and partial-close records. Currently `optionPartialCloseSchema` has quantity/residual/PnL/time but no unique economic event ID in this schema; `dividendEventSchema` has lot ID/exDate/amountPerShare. Inspect actual upstream store/import dedup and entitlement guarantees before requesting a change. Schema-level absence does not prove a runtime duplicate exists.
- `src/theta/whole-chain-economics.ts`: reuse `WholeChainComponents` and `computeWholeChainPnl`. It supports partial stock disposal, explicit dividend/fee unknowns, benchmark versus actual cashflow basis, and diagnostic TCA without second subtraction. Our synthetic fixture must use `BENCHMARK_CASHFLOW`, never actual broker claims.
- `src/theta/whole-chain-component-evidence.ts`: reuse explicit KNOWN/KNOWN_ZERO/UNKNOWN and source recordIds/observedAt/asOf. A new dividend entitlement record, if necessary, belongs in evidence assembly with existing provenance, not an alternate PnL engine.
- `src/research/recovery-covered-call-experiment.ts`: reuse `buildRecoveryCoveredCallExperiment`, stage-valid alternatives, common horizon, PARTIAL/CENSORED labels, event/dividend state, capitalDays and lostUpside. It returns `DESCRIPTIVE_NO_RANKING`. Do not add selection authority.
- `src/research/cross-strategy-common-horizon-contract.ts`: reuse common identity/unit and UNKNOWN versus NOT_APPLICABLE typing when reporting cross-strategy diagnostics; don't invent comparability from one known PnL number.

Minimal next Codex research-only change, if separately authorized: add immutable event-effectiveAt/availableAt and economic-event identity/entitled-quantity evidence to the existing import/assembly interface only where absent. Join to existing economics/replay outputs in one test adapter. Confirm mandatory action remains truthfully distinguishable from feasible/filled close. No new independent engine, no Production route, no account operation.

## 5. Empirical packet and stop conditions

Need exact original entry and contract standardness; same-entry policy assignment; all candidate and rejected records; qualified quote-event and receipt clocks; order/parent/leg status and actual quantities; fee evidence; event schedule vintages; reserve-release evidence; assignment/settlement/lot and dividend-entitlement records. License/provider authority is owned by the separate data audit. Do not fetch broker data or claim free quotes are OPRA.

Use chronological blocked OOS with same chain in only one split, label maturity embargo through settlement and common horizon, and date/event clusters for uncertainty. Do not count two policy arms, grid rows or duplicate receipts as independent trades. Prespecify family-wise comparisons before searching target/delay variants. No fixed sample count can certify rare failures; report independent clusters, confidence width, unresolved fraction and failure coverage. Promotion remains blocked until adequate empirical outcome and execution coverage, separately approved by owner. If any mandatory endpoint lacks provenance, use DATA_NOT_AVAILABLE and keep structural results only.

## Reproduction

Run `python3 lifecycle_oracles_v1.py` and `python3 sensitivity_and_mutations_v1.py` in this directory. Both require only Python standard library. Receipts distinguish fixture assertions, grid rows and deliberate arithmetic mutants. Source adapter characterization, if completed, has its own runner and receipt; never combine its count with these standalone checks or earlier work.

## Exact-source characterization completed

`source_contract_characterization_v1.mjs` imported the existing d0b source with Node24, without source edits or DB/provider code. Ten checks passed separately from the33 standalone fixture assertions. Whole-chain and A/C experiment functions reproduce−204; changing TCA diagnostics leaves cash PnL unchanged; unknown dividends produce unknown whole-chain PnL; partial sale/retained inventory computes546 correctly.

Two deliberately malformed upstream-evidence probes characterize the pure `ledger-contract.ts` consumer: a supplied dividend row referencing a lot disposed before its ex-date still contributes100; repeating the same row contributes200. The consumer assumes valid entitled, unique rows. These probes do not demonstrate that the actual producer, importer, database or runtime can supply them. Required follow-up is inspect entitlement-quantity and uniqueness guarantees at the producer/import boundary, then add narrowly scoped adapter tests if needed. Do not change Production based on this lower-level characterization.

These fixtures treat early assignment as an explicit hypothetical event. They do not infer exercise certainty from dividend exceeding extrinsic value, and do not estimate assignment probability. The stock path between S90 decision and pre-ex-date call-away is allowed to rise above95; a1-dollar option premium and later assignment are separate observations in the invented path. Ex-date cash in the WAIT arm is a proven entitlement paid by the common horizon under the fixture.

Current canonical researchRules are snapshot-level scalars, so these event/lot-level conditions cannot be represented merely as new `researchRules`. Do not submit them as a canonical Dot proposal, add unsupported policy enums, or apply chain-specific research to all candidates through one snapshot flag. A future reviewed existing-ledger adapter is needed; this handoff requests no implementation authority.

## Upstream qualification: reviewed fail-closed evidence path

Further exact d0b source reading narrows the malformed-dividend characterization. `postgres-whole-chain-components-repository.ts` lines374–382 always returns `UNKNOWN` for dividend evidence, with reason `DIVIDEND_COVERAGE_UNPROVEN_NO_ACTIVE_INGESTION_WRITER`, even when a partial amount can be summed. Its query uses created_at/ex_date cutoffs, but does not claim proven entitlement coverage. `componentsFromEvidence` requires dividends and blocks `dividends:UNKNOWN`. SC09 and SC10 execute that exact assembler with UNKNOWN amount0 and100; both return components=null and the blocker. Thus this reviewed path does not certify the malformed raw-ledger outputs as complete economic outcomes. This is positive guard evidence, not a demonstrated runtime cash overstatement. Database/runtime execution remains untested.

`alpaca-corporate-action-evidence.ts` already deduplicates repeated provider identities within a read, rejects conflicting duplicates, persists positive schedule observations with conflict protection, keeps providerKnownAt=null, and reports negativeCoverageQualified=false. Its cash-dividend schedule observations are not dividend cash entitlements. Do not conflate this schedule deduplication with missing stock-lot entitlement evidence. No provider call or persistence function was invoked.

`research/whole-chain-outcome-builder.ts` already wraps canonical whole-chain math and capital-days, retains censored rows and labels resolved benchmark cashflows MODEL_BASED_ESTIMATE. Reuse it where appropriate rather than adding another accounting/materialization engine. The next bounded source task is to specify a reviewed entitlement evidence producer and adapt existing importer/assembler tests. No such implementation is authorized by this packet.
